import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Паттерны URL, которые не требуют проверки аутентификации на клиенте
const publicPaths = [
  '/',
  '/blog(.*)',
  '/api/(.*)',
  '/admin$', // Страница логина в админ-панель
]

export function middleware(request: NextRequest) {
  // Проверяем, является ли URL путем админ-панели
  const isAdminPath = request.nextUrl.pathname.startsWith('/admin/dashboard')

  // Если это не путь админ-панели или это публичный путь, пропускаем
  if (!isAdminPath || publicPaths.some(path =>
    new RegExp(`^${path}$`).test(request.nextUrl.pathname)
  )) {
    return NextResponse.next()
  }

  // Для путей админ-панели мы не делаем серверной проверки
  // Вместо этого проверка аутентификации происходит на клиенте
  // в компоненте AuthCheck
  // В реальном проекте здесь должна быть проверка токена или сессии
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Путь / является публичным, поэтому не требует проверки
     * Все пути /admin/dashboard/* требуют проверки аутентификации на клиенте
     */
    '/',
    '/admin',
    '/admin/(.*)',
  ],
}
