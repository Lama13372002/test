'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard,
  FileText,
  Map,
  Car,
  Star,
  Phone,
  MessageSquare,
  Settings
} from 'lucide-react'

interface SidebarItem {
  title: string
  href: string
  icon: React.ReactNode
}

export default function AdminSidebar() {
  const pathname = usePathname()

  const sidebarItems: SidebarItem[] = [
    {
      title: 'Панель управления',
      href: '/admin/dashboard',
      icon: <LayoutDashboard size={20} />,
    },
    {
      title: 'Редактирование подвала',
      href: '/admin/dashboard/footer',
      icon: <FileText size={20} />,
    },
    {
      title: 'Маршруты',
      href: '/admin/dashboard/routes',
      icon: <Map size={20} />,
    },
    {
      title: 'Автомобили',
      href: '/admin/dashboard/vehicles',
      icon: <Car size={20} />,
    },
    {
      title: 'Отзывы',
      href: '/admin/dashboard/reviews',
      icon: <Star size={20} />,
    },
    {
      title: 'Контакты',
      href: '/admin/dashboard/contacts',
      icon: <Phone size={20} />,
    },
    {
      title: 'Блог',
      href: '/admin/dashboard/blog',
      icon: <MessageSquare size={20} />,
    },
    {
      title: 'Настройки',
      href: '/admin/dashboard/settings',
      icon: <Settings size={20} />,
    },
  ]

  return (
    <aside className="w-64 bg-white shadow h-screen">
      <div className="py-6 px-4">
        <ul className="space-y-2">
          {sidebarItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={`flex items-center p-3 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <span className={`${isActive ? 'text-blue-600' : 'text-gray-500'} mr-3`}>
                    {item.icon}
                  </span>
                  <span className="font-medium">{item.title}</span>
                  {isActive && (
                    <span className="ml-auto w-1.5 h-6 rounded-full bg-blue-600" />
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </div>
    </aside>
  )
}
