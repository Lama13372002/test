'use client'

import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Settings, LogOut, Home } from 'lucide-react'

export default function AdminNavbar() {
  const router = useRouter()

  const handleLogout = () => {
    // Удаляем флаг авторизации
    localStorage.removeItem('adminAuthenticated')
    // Перенаправляем на страницу входа
    router.push('/admin')
  }

  return (
    <nav className="bg-white shadow">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link href="/admin/dashboard" className="flex items-center">
              <span className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-indigo-600">
                RoyalTransfer
              </span>
              <span className="ml-2 text-xs font-semibold text-gray-500">АДМИН-ПАНЕЛЬ</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center text-gray-500 hover:text-gray-700" target="_blank" rel="noopener noreferrer">
              <Home size={18} className="mr-1" />
              <span className="text-sm">Сайт</span>
            </Link>

            <Link href="/admin/dashboard" className="flex items-center text-gray-500 hover:text-gray-700">
              <Settings size={18} className="mr-1" />
              <span className="text-sm">Настройки</span>
            </Link>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="flex items-center text-gray-500 hover:text-gray-700"
            >
              <LogOut size={18} className="mr-1" />
              <span className="text-sm">Выход</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
