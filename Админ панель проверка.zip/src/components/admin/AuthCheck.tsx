'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

interface AuthCheckProps {
  children: React.ReactNode
}

export default function AuthCheck({ children }: AuthCheckProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Проверяем наличие флага авторизации
    const adminAuthenticated = localStorage.getItem('adminAuthenticated')

    if (adminAuthenticated !== 'true') {
      // Если пользователь не авторизован, перенаправляем на страницу входа
      router.push('/admin')
    } else {
      setIsAuthenticated(true)
    }

    setIsLoading(false)
  }, [router])

  // Показываем пустой экран во время проверки
  if (isLoading) {
    return <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
    </div>
  }

  // Если пользователь авторизован, показываем содержимое
  return isAuthenticated ? <>{children}</> : null
}
