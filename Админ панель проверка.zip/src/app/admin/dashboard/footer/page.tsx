'use client'

import { useEffect, useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'

interface FooterFormData {
  companyName: string
  companyDesc: string
  address: string
  phone: string
  email: string
  workHours: string
  instagramUrl: string
  telegramUrl: string
  whatsappUrl: string
}

export default function FooterEditPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState<FooterFormData>({
    companyName: '',
    companyDesc: '',
    address: '',
    phone: '',
    email: '',
    workHours: '',
    instagramUrl: '',
    telegramUrl: '',
    whatsappUrl: '',
  })

  useEffect(() => {
    // Загружаем данные подвала при монтировании компонента
    fetch('/api/footer')
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch footer data')
        }
        return response.json()
      })
      .then(data => {
        setFormData({
          companyName: data.companyName || '',
          companyDesc: data.companyDesc || '',
          address: data.address || '',
          phone: data.phone || '',
          email: data.email || '',
          workHours: data.workHours || '',
          instagramUrl: data.instagramUrl || '',
          telegramUrl: data.telegramUrl || '',
          whatsappUrl: data.whatsappUrl || '',
        })
        setLoading(false)
      })
      .catch(error => {
        console.error('Error fetching footer data:', error)
        toast.error('Ошибка при загрузке данных')
        setLoading(false)
      })
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)

    try {
      const response = await fetch('/api/footer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error('Failed to update footer data')
      }

      toast.success('Данные успешно сохранены')
    } catch (error) {
      console.error('Error saving footer data:', error)
      toast.error('Ошибка при сохранении данных')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Редактирование подвала</h1>
        <p className="text-gray-500">
          Измените информацию, которая отображается в подвале на всех страницах сайта
        </p>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Название компании */}
            <div className="space-y-2">
              <label htmlFor="companyName" className="text-sm font-medium text-gray-700">
                Название компании
              </label>
              <Input
                id="companyName"
                name="companyName"
                value={formData.companyName}
                onChange={handleInputChange}
                required
              />
            </div>

            {/* Адрес */}
            <div className="space-y-2">
              <label htmlFor="address" className="text-sm font-medium text-gray-700">
                Адрес
              </label>
              <Input
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                required
              />
            </div>

            {/* Описание компании */}
            <div className="space-y-2 md:col-span-2">
              <label htmlFor="companyDesc" className="text-sm font-medium text-gray-700">
                Описание компании
              </label>
              <Textarea
                id="companyDesc"
                name="companyDesc"
                value={formData.companyDesc}
                onChange={handleInputChange}
                rows={3}
                required
              />
            </div>

            {/* Телефон */}
            <div className="space-y-2">
              <label htmlFor="phone" className="text-sm font-medium text-gray-700">
                Телефон
              </label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                required
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-medium text-gray-700">
                Email
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </div>

            {/* Рабочие часы */}
            <div className="space-y-2 md:col-span-2">
              <label htmlFor="workHours" className="text-sm font-medium text-gray-700">
                Рабочие часы
                <span className="ml-1 text-xs text-gray-400">(используйте Enter для переноса строки)</span>
              </label>
              <Textarea
                id="workHours"
                name="workHours"
                value={formData.workHours}
                onChange={handleInputChange}
                rows={2}
                required
              />
            </div>

            {/* Instagram URL */}
            <div className="space-y-2">
              <label htmlFor="instagramUrl" className="text-sm font-medium text-gray-700">
                Ссылка на Instagram
              </label>
              <Input
                id="instagramUrl"
                name="instagramUrl"
                value={formData.instagramUrl}
                onChange={handleInputChange}
                placeholder="https://instagram.com/username"
              />
            </div>

            {/* Telegram URL */}
            <div className="space-y-2">
              <label htmlFor="telegramUrl" className="text-sm font-medium text-gray-700">
                Ссылка на Telegram
              </label>
              <Input
                id="telegramUrl"
                name="telegramUrl"
                value={formData.telegramUrl}
                onChange={handleInputChange}
                placeholder="https://t.me/username"
              />
            </div>

            {/* WhatsApp URL */}
            <div className="space-y-2">
              <label htmlFor="whatsappUrl" className="text-sm font-medium text-gray-700">
                Ссылка на WhatsApp
              </label>
              <Input
                id="whatsappUrl"
                name="whatsappUrl"
                value={formData.whatsappUrl}
                onChange={handleInputChange}
                placeholder="https://wa.me/79001234567"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              type="submit"
              className="bg-blue-500 hover:bg-blue-600"
              disabled={saving}
            >
              {saving ? 'Сохранение...' : 'Сохранить изменения'}
            </Button>
          </div>
        </form>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-amber-800 mb-2">Обратите внимание</h2>
        <p className="text-amber-700">
          Изменения в подвале будут отображаться на всех страницах сайта, включая главную страницу и блог.
        </p>
      </div>
    </div>
  )
}
