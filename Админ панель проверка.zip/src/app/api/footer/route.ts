import { NextResponse } from 'next/server'
import { getFooterData, updateFooterData } from '@/lib/footer'

// GET: Получение данных футера
export async function GET() {
  try {
    const footerData = await getFooterData()
    return NextResponse.json(footerData)
  } catch (error) {
    console.error('Error fetching footer data:', error)
    return NextResponse.json(
      { error: 'Failed to fetch footer data' },
      { status: 500 }
    )
  }
}

// POST: Обновление данных футера
export async function POST(request: Request) {
  try {
    const data = await request.json()
    const updatedFooter = await updateFooterData(data)
    return NextResponse.json(updatedFooter)
  } catch (error) {
    console.error('Error updating footer data:', error)
    return NextResponse.json(
      { error: 'Failed to update footer data' },
      { status: 500 }
    )
  }
}
