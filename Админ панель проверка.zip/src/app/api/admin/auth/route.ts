import { NextResponse } from 'next/server'
import { validateAdminCredentials, createAdminIfNotExists } from '@/lib/auth'

// Инициализация: создаем администратора, если он не существует
createAdminIfNotExists().catch(console.error)

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json()

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      )
    }

    const isValid = await validateAdminCredentials(username, password)

    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // В реальном приложении здесь бы генерировали JWT или сессионный токен
    // Для простоты примера просто вернем успешный ответ
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Authentication error:', error)
    return NextResponse.json(
      { error: 'Authentication failed' },
      { status: 500 }
    )
  }
}
