import { compare, hash } from 'bcrypt'
import prisma from './prisma'

// Хэширование пароля
export async function hashPassword(password: string): Promise<string> {
  return hash(password, 10)
}

// Сравнение пароля с хэшем
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return compare(password, hashedPassword)
}

// Проверка, существует ли администратор
export async function doesAdminExist(): Promise<boolean> {
  const adminCount = await prisma.admin.count()
  return adminCount > 0
}

// Создание администратора, если он не существует
export async function createAdminIfNotExists(): Promise<void> {
  const adminExists = await doesAdminExist()

  if (!adminExists) {
    const username = process.env.ADMIN_USERNAME || 'admin'
    const password = process.env.ADMIN_PASSWORD || 'admin123'

    await prisma.admin.create({
      data: {
        username,
        password: await hashPassword(password),
      },
    })

    console.log('Admin user created')
  }
}

// Проверка учетных данных администратора
export async function validateAdminCredentials(username: string, password: string): Promise<boolean> {
  const admin = await prisma.admin.findUnique({
    where: { username },
  })

  if (!admin) {
    return false
  }

  return verifyPassword(password, admin.password)
}
