import prisma from './prisma'

// Получение данных футера
export async function getFooterData() {
  // Получаем первую запись или создаем новую, если она не существует
  let footerData = await prisma.footerData.findFirst()

  if (!footerData) {
    footerData = await prisma.footerData.create({
      data: {
        companyName: 'RoyalTransfer',
        companyDesc: 'Комфортные трансферы из Калининграда в города Европы. Безопасность, комфорт и пунктуальность.',
        address: 'г. Калининград, ул. Примерная, д. 123',
        phone: '+7 (900) 000-00-00',
        email: 'info@royaltransfer.ru',
        workHours: 'Пн-Вс: 24/7\nРаботаем без выходных',
        instagramUrl: '#',
        telegramUrl: '#',
        whatsappUrl: '#',
      },
    })
  }

  return footerData
}

// Обновление данных футера
export async function updateFooterData(data: {
  companyName?: string
  companyDesc?: string
  address?: string
  phone?: string
  email?: string
  workHours?: string
  instagramUrl?: string
  telegramUrl?: string
  whatsappUrl?: string
}) {
  const footerData = await getFooterData()

  return prisma.footerData.update({
    where: {
      id: footerData.id,
    },
    data,
  })
}
