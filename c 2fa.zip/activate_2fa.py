import base64
import hashlib
import hmac
import secrets
import time
import sqlite3
import sys

def generate_totp_secret():
    """Generate a random secret for TOTP"""
    return base64.b32encode(secrets.token_bytes(20)).decode('utf-8')

def generate_current_totp(secret):
    """Generate the current TOTP code for a secret"""
    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    # Decode the base32 secret
    secret_bytes = base64.b32decode(secret.upper().encode('utf-8'))

    # Compute HMAC
    counter_bytes = intervals_no.to_bytes(8, byteorder='big')
    h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

    # Get offset
    offset = h[-1] & 0x0F

    # Get 4 bytes at the offset
    truncated_hash = h[offset:offset+4]

    # Convert to an integer and get only 6 digits
    code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
    code = code % 1000000

    # Zero pad to 6 digits
    code_str = str(code).zfill(6)

    return code_str

def update_user_2fa(username):
    """Enable 2FA for a specific user by username"""
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Check if user exists
    cursor.execute("SELECT id FROM users WHERE login = ?", (username,))
    user = cursor.fetchone()

    if not user:
        print(f"Error: User '{username}' does not exist")
        conn.close()
        return False

    user_id = user[0]

    # Generate a new secret
    secret = generate_totp_secret()

    # Update the user with 2FA enabled
    cursor.execute("UPDATE users SET twofa_secret = ?, twofa_enabled = 1 WHERE id = ?",
                  (secret, user_id))
    conn.commit()

    print(f"2FA has been enabled for user '{username}' (ID: {user_id})")
    print(f"Secret key: {secret}")
    print(f"Current TOTP code: {generate_current_totp(secret)}")
    print(f"TOTP URI: otpauth://totp/App:{username}?secret={secret}&issuer=App")
    print("\nTo use this with an authenticator app:")
    print("1. Open your authenticator app (Google Authenticator, Microsoft Authenticator, Authy, etc.)")
    print("2. Add a new account manually")
    print("3. Enter the secret key above")
    print("4. Use the 6-digit code from the app when logging in")

    conn.close()
    return True

def list_users():
    """List all users in the database"""
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, login, twofa_enabled FROM users")
    users = cursor.fetchall()

    if not users:
        print("No users found in the database")
    else:
        print("\nExisting users:")
        print("ID  | Username | 2FA Status")
        print("----+---------+-----------")
        for user in users:
            status = "Enabled" if user[2] else "Disabled"
            print(f"{user[0]:<3} | {user[1]:<7} | {status}")

    conn.close()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 activate_2fa.py [username]")
        print("   or: python3 activate_2fa.py --list")
        sys.exit(1)

    if sys.argv[1] == "--list":
        list_users()
    else:
        username = sys.argv[1]
        update_user_2fa(username)
