import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app/app_router.dart';
import 'app/themes.dart';
import 'core/services/notification_service.dart';
import 'core/services/storage_service.dart';
import 'data/repositories/vehicle_repository.dart';
import 'data/repositories/service_center_repository.dart';
import 'presentation/blocs/auth/auth_bloc.dart';
import 'presentation/blocs/theme/theme_bloc.dart';
import 'presentation/blocs/vehicle/vehicle_bloc.dart';

Future<void> main() async {
  // Сохраняем splash screen пока инициализируем приложение
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  // Инициализация Hive для локального хранения
  await Hive.initFlutter();

  // Регистрация адаптеров
  // await Hive.registerAdapter(VehicleAdapter());
  // await Hive.registerAdapter(MaintenanceAdapter());

  // Инициализация сервисов
  final storageService = await StorageService.initialize();
  final notificationService = await NotificationService.initialize();

  // Задаем ориентацию экрана
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Настройка системных цветов status bar
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
    ),
  );

  // Удаляем splash screen
  FlutterNativeSplash.remove();

  runApp(MyApp(
    storageService: storageService,
    notificationService: notificationService,
  ));
}

class MyApp extends StatelessWidget {
  final StorageService storageService;
  final NotificationService notificationService;

  const MyApp({
    Key? key,
    required this.storageService,
    required this.notificationService,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ThemeBloc>(
          create: (context) => ThemeBloc(
            isDarkMode: storageService.getThemeMode(),
          ),
        ),
        BlocProvider<AuthBloc>(
          create: (context) => AuthBloc(
            storageService: storageService,
          ),
        ),
        BlocProvider<VehicleBloc>(
          create: (context) => VehicleBloc(
            repository: VehicleRepository(storageService),
          ),
        ),
      ],
      child: BlocBuilder<ThemeBloc, ThemeState>(
        builder: (context, state) {
          return MaterialApp(
            title: 'AutoDoc',
            debugShowCheckedModeBanner: false,
            theme: AppThemes.lightTheme,
            darkTheme: AppThemes.darkTheme,
            themeMode: state.isDarkMode ? ThemeMode.dark : ThemeMode.light,
            onGenerateRoute: AppRouter.onGenerateRoute,
            initialRoute: AppRouter.splash,
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [
              Locale('ru', ''),
              Locale('en', ''),
            ],
          );
        },
      ),
    );
  }
}
