import 'package:flutter/material.dart';

import '../presentation/screens/splash/splash_screen.dart';
import '../presentation/screens/onboarding/onboarding_screen.dart';
import '../presentation/screens/auth/login_screen.dart';
import '../presentation/screens/auth/register_screen.dart';
import '../presentation/screens/home/home_screen.dart';
import '../presentation/screens/vehicle/add_vehicle_screen.dart';
import '../presentation/screens/vehicle/vehicle_details_screen.dart';
import '../presentation/screens/maintenance/maintenance_list_screen.dart';
import '../presentation/screens/maintenance/add_maintenance_screen.dart';
import '../presentation/screens/diagnostics/diagnostics_screen.dart';
import '../presentation/screens/map/service_map_screen.dart';
import '../presentation/screens/chat/chat_screen.dart';
import '../presentation/screens/profile/profile_screen.dart';
import '../presentation/screens/settings/settings_screen.dart';

class AppRouter {
  // Константы маршрутов
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String addVehicle = '/add-vehicle';
  static const String vehicleDetails = '/vehicle-details';
  static const String maintenanceList = '/maintenance-list';
  static const String addMaintenance = '/add-maintenance';
  static const String diagnostics = '/diagnostics';
  static const String serviceMap = '/service-map';
  static const String chat = '/chat';
  static const String profile = '/profile';
  static const String settings = '/settings';

  // Функция генерации маршрутов
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const SplashScreen());

      case onboarding:
        return MaterialPageRoute(builder: (_) => const OnboardingScreen());

      case login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());

      case register:
        return MaterialPageRoute(builder: (_) => const RegisterScreen());

      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case addVehicle:
        return MaterialPageRoute(builder: (_) => const AddVehicleScreen());

      case vehicleDetails:
        final vehicleId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => VehicleDetailsScreen(vehicleId: vehicleId),
        );

      case maintenanceList:
        final vehicleId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => MaintenanceListScreen(vehicleId: vehicleId),
        );

      case addMaintenance:
        final vehicleId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => AddMaintenanceScreen(vehicleId: vehicleId),
        );

      case diagnostics:
        return MaterialPageRoute(builder: (_) => const DiagnosticsScreen());

      case serviceMap:
        return MaterialPageRoute(builder: (_) => const ServiceMapScreen());

      case chat:
        return MaterialPageRoute(builder: (_) => const ChatScreen());

      case profile:
        return MaterialPageRoute(builder: (_) => const ProfileScreen());

      case settings:
        return MaterialPageRoute(builder: (_) => const SettingsScreen());

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('Маршрут ${settings.name} не найден'),
            ),
          ),
        );
    }
  }

  // Переход с анимацией
  static Route<dynamic> createRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;

        var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var offsetAnimation = animation.drive(tween);

        return SlideTransition(position: offsetAnimation, child: child);
      },
    );
  }
}
