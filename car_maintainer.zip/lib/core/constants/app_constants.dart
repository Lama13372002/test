class AppConstants {
  // Запрет на создание экземпляра класса
  AppConstants._();

  // Общие константы
  static const String appName = 'AutoDoc';
  static const String appVersion = '1.0.0';

  // Ключи для хранения
  static const String themeKey = 'theme_key';
  static const String languageKey = 'language_key';
  static const String userKey = 'user_key';
  static const String tokenKey = 'token_key';
  static const String firstLaunchKey = 'first_launch_key';
  static const String vehiclesKey = 'vehicles_key';
  static const String notificationsKey = 'notifications_key';

  // Регулярные выражения для валидации
  static final RegExp emailRegExp = RegExp(
    r'^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+',
  );
  static final RegExp passwordRegExp = RegExp(
    r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$',
  );

  // API константы
  static const String baseUrl = 'https://api.autodoc.app';
  static const String googleMapsApiKey = 'YOUR_GOOGLE_MAPS_API_KEY';
  static const String chatGptApiKey = 'YOUR_CHATGPT_API_KEY';

  // Пути к ассетам
  static const String imagesPath = 'assets/images/';
  static const String iconsPath = 'assets/icons/';
  static const String animationsPath = 'assets/animations/';

  // Анимации
  static const String splashAnimation = 'assets/animations/splash_animation.json';
  static const String loadingAnimation = 'assets/animations/loading_animation.json';
  static const String successAnimation = 'assets/animations/success_animation.json';
  static const String errorAnimation = 'assets/animations/error_animation.json';
  static const String emptyAnimation = 'assets/animations/empty_animation.json';

  // Типы обслуживания
  static const List<String> maintenanceTypes = [
    'Замена масла',
    'Замена фильтров',
    'Замена тормозных колодок',
    'Замена ремня ГРМ',
    'Замена шин',
    'Диагностика',
    'Техническое обслуживание',
    'Другое',
  ];

  // Категории диагностики
  static const List<String> diagnosticCategories = [
    'Двигатель',
    'Трансмиссия',
    'Подвеска',
    'Электрика',
    'Кузов',
    'Шины',
    'Тормоза',
    'Топливная система',
    'Система охлаждения',
  ];

  // Типы сервисных центров
  static const List<String> serviceTypes = [
    'Официальный дилер',
    'Сервисный центр',
    'Шиномонтаж',
    'Автомойка',
    'Заправка',
  ];

  // Интервалы обслуживания (км)
  static const int oilChangeInterval = 10000;
  static const int airFilterInterval = 15000;
  static const int brakeFluidInterval = 30000;
  static const int brakePadsInterval = 30000;
  static const int timingBeltInterval = 60000;
  static const int sparkPlugsInterval = 30000;
  static const int coolantInterval = 60000;
  static const int transmissionOilInterval = 60000;

  // Интервалы обслуживания (месяцы)
  static const int oilChangeMonths = 12;
  static const int airFilterMonths = 12;
  static const int brakeFluidMonths = 24;
  static const int brakePadsMonths = 24;
  static const int timingBeltMonths = 60;
  static const int sparkPlugsMonths = 24;
  static const int coolantMonths = 24;
  static const int transmissionOilMonths = 36;

  // Размеры анимаций
  static const double smallAnimationSize = 100.0;
  static const double mediumAnimationSize = 150.0;
  static const double largeAnimationSize = 200.0;

  // Тайминги
  static const int splashDuration = 3000; // милисекунды
  static const int toastDuration = 3000; // милисекунды
  static const int animationDuration = 300; // милисекунды
  static const int apiTimeout = 30000; // милисекунды

  // Пагинация
  static const int pageSize = 20;
}
