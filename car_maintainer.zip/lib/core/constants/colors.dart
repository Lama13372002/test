import 'package:flutter/material.dart';

class AppColors {
  // Запрет на создание экземпляра класса
  AppColors._();

  // Основные цвета приложения
  static const Color primary = Color(0xFF0066CC);       // Основной синий
  static const Color secondary = Color(0xFF34C759);     // Зеленый для акцентов
  static const Color tertiary = Color(0xFFFF9500);      // Оранжевый для предупреждений

  // Текстовые цвета
  static const Color darkText = Color(0xFF1A1A1A);      // Темный текст
  static const Color lightText = Color(0xFFF5F5F5);     // Светлый текст

  // Фоновые цвета
  static const Color lightBackground = Color(0xFFF7F8FA); // Светлый фон
  static const Color darkBackground = Color(0xFF121212);  // Темный фон

  // Цвета состояний
  static const Color error = Color(0xFFFF3B30);         // Ошибка
  static const Color warning = Color(0xFFFF9500);       // Предупреждение
  static const Color success = Color(0xFF34C759);       // Успех
  static const Color info = Color(0xFF5AC8FA);          // Информация

  // Цвета состояний автомобиля
  static const Color excellent = Color(0xFF34C759);     // Отличное состояние
  static const Color good = Color(0xFF5AC8FA);          // Хорошее состояние
  static const Color warning50 = Color(0xFFFF9F0A);     // Требует внимания
  static const Color critical = Color(0xFFFF453A);      // Критическое состояние

  // Серые оттенки
  static const Color grey = Color(0xFF8E8E93);          // Стандартный серый
  static const Color lightGrey = Color(0xFFE5E5EA);     // Светло-серый
  static const Color darkGrey = Color(0xFF636366);      // Темно-серый

  // Цвета для уведомлений
  static const Color notificationBackground = Color(0xFFFFFFFF);
  static const Color notificationBorder = Color(0xFFE5E5EA);

  // Цвета категорий обслуживания
  static const Color engineCategory = Color(0xFFFF9F0A);      // Двигатель
  static const Color transmissionCategory = Color(0xFF5856D6); // Трансмиссия
  static const Color suspensionCategory = Color(0xFF34C759);   // Подвеска
  static const Color electricalCategory = Color(0xFF5AC8FA);   // Электрика
  static const Color bodyCategory = Color(0xFFAF52DE);         // Кузов
  static const Color tiresCategory = Color(0xFFFF2D55);        // Шины
  static const Color brakeCategory = Color(0xFFFF3824);        // Тормоза
  static const Color fuelCategory = Color(0xFF007AFF);         // Топливная система
  static const Color coolingCategory = Color(0xFF64D2FF);      // Система охлаждения
  static const Color regularCategory = Color(0xFF8E8E93);      // Регулярное обслуживание

  // Цвета типов сервисных центров на карте
  static const Color officialDealerMarker = Color(0xFF007AFF);  // Официальный дилер
  static const Color serviceCenterMarker = Color(0xFF34C759);   // Сервисный центр
  static const Color tireServiceMarker = Color(0xFFFF9500);     // Шиномонтаж
  static const Color carWashMarker = Color(0xFF5AC8FA);         // Автомойка
  static const Color gasStationMarker = Color(0xFFFF2D55);      // Заправка
}
