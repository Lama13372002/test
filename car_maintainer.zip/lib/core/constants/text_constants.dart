class AppTexts {
  // Запрет на создание экземпляра класса
  AppTexts._();

  // Общие текстовые константы
  static const String appName = 'AutoDoc';

  // Сообщения об ошибках
  static const String errorTitle = 'Ошибка';
  static const String errorGeneral = 'Что-то пошло не так. Пожалуйста, попробуйте снова.';
  static const String errorConnection = 'Ошибка подключения. Проверьте интернет-соединение.';
  static const String errorTimeout = 'Превышено время ожидания запроса. Пожалуйста, попробуйте снова.';
  static const String errorAuth = 'Ошибка авторизации. Пожалуйста, войдите снова.';
  static const String errorValidation = 'Проверьте правильность введенных данных.';
  static const String errorEmptyFields = 'Пожалуйста, заполните все обязательные поля.';
  static const String errorInvalidEmail = 'Неверный формат email.';
  static const String errorShortPassword = 'Пароль должен содержать не менее 8 символов.';
  static const String errorPasswordMatch = 'Пароли не совпадают.';
  static const String errorInvalidMileage = 'Неверный пробег.';
  static const String errorLocationPermission = 'Для работы с картой необходимо разрешение на определение местоположения.';

  // Успешные сообщения
  static const String successTitle = 'Успешно';
  static const String successRegister = 'Регистрация прошла успешно!';
  static const String successLogin = 'Вход выполнен успешно!';
  static const String successAddVehicle = 'Автомобиль успешно добавлен!';
  static const String successUpdateVehicle = 'Информация об автомобиле обновлена!';
  static const String successAddMaintenance = 'Обслуживание успешно добавлено!';
  static const String successUpdateMaintenance = 'Информация об обслуживании обновлена!';
  static const String successDeleteVehicle = 'Автомобиль удален!';
  static const String successDeleteMaintenance = 'Запись об обслуживании удалена!';
  static const String successSetReminder = 'Напоминание установлено!';
  static const String successUpdateProfile = 'Профиль успешно обновлен!';

  // Экран запуска (Splash)
  static const String splashTagline = 'Заботьтесь о своём автомобиле с нами';

  // Экран приветствия (Onboarding)
  static const String onboardingTitle1 = 'Следите за вашим автомобилем';
  static const String onboardingDesc1 = 'Добавляйте информацию о своих автомобилях и отслеживайте их состояние';

  static const String onboardingTitle2 = 'Получайте уведомления';
  static const String onboardingDesc2 = 'Не пропустите важные события обслуживания и ремонта вашего автомобиля';

  static const String onboardingTitle3 = 'Диагностика проблем';
  static const String onboardingDesc3 = 'Введите симптомы и получите возможные причины и решения проблем';

  static const String onboardingTitle4 = 'Найдите ближайшие СТО';
  static const String onboardingDesc4 = 'Находите ближайшие автосервисы на карте с отзывами и рейтингами';

  static const String skip = 'Пропустить';
  static const String next = 'Далее';
  static const String start = 'Начать';

  // Экраны авторизации
  static const String loginTitle = 'Вход';
  static const String registerTitle = 'Регистрация';
  static const String email = 'Email';
  static const String password = 'Пароль';
  static const String confirmPassword = 'Подтвердите пароль';
  static const String name = 'Имя';
  static const String forgotPassword = 'Забыли пароль?';
  static const String loginButton = 'Войти';
  static const String registerButton = 'Зарегистрироваться';
  static const String noAccount = 'Нет аккаунта? ';
  static const String haveAccount = 'Уже есть аккаунт? ';
  static const String resetPassword = 'Сбросить пароль';
  static const String continueWithoutAccount = 'Продолжить без аккаунта';

  // Экран главной
  static const String homeTitle = 'Мои автомобили';
  static const String noVehicles = 'У вас пока нет добавленных автомобилей';
  static const String addFirstVehicle = 'Добавьте свой первый автомобиль';
  static const String addVehicle = 'Добавить автомобиль';
  static const String upcomingMaintenance = 'Ближайшее обслуживание';
  static const String viewAll = 'Все';
  static const String daysLeft = 'дней осталось';
  static const String kmLeft = 'км осталось';

  // Экран автомобиля
  static const String vehicleDetailsTitle = 'Данные автомобиля';
  static const String brand = 'Марка';
  static const String model = 'Модель';
  static const String year = 'Год выпуска';
  static const String licensePlate = 'Гос. номер';
  static const String vin = 'VIN';
  static const String mileage = 'Пробег (км)';
  static const String lastServiceDate = 'Дата последнего ТО';
  static const String fuelType = 'Тип топлива';
  static const String transmission = 'Трансмиссия';
  static const String engineVolume = 'Объем двигателя';
  static const String driveType = 'Привод';
  static const String color = 'Цвет';
  static const String notes = 'Примечания';
  static const String saveVehicle = 'Сохранить';
  static const String updateVehicle = 'Обновить';
  static const String deleteVehicle = 'Удалить автомобиль';
  static const String confirmDeleteVehicle = 'Вы уверены, что хотите удалить этот автомобиль?';
  static const String generalInfo = 'Общая информация';
  static const String technicalInfo = 'Техническая информация';
  static const String additionalInfo = 'Дополнительная информация';

  // Экраны обслуживания
  static const String maintenanceTitle = 'История обслуживания';
  static const String noMaintenance = 'История обслуживания пуста';
  static const String addMaintenance = 'Добавить обслуживание';
  static const String maintenanceType = 'Тип обслуживания';
  static const String maintenanceDate = 'Дата';
  static const String maintenanceMileage = 'Пробег (км)';
  static const String maintenanceCost = 'Стоимость (руб)';
  static const String maintenanceNotes = 'Комментарии';
  static const String maintenanceParts = 'Запчасти';
  static const String maintenanceReminder = 'Установить напоминание';
  static const String reminderDate = 'Дата напоминания';
  static const String reminderMileage = 'Пробег для напоминания';
  static const String saveMaintenance = 'Сохранить';
  static const String updateMaintenance = 'Обновить';
  static const String deleteMaintenance = 'Удалить';
  static const String oil = 'Масло';
  static const String oilFilter = 'Масляный фильтр';
  static const String airFilter = 'Воздушный фильтр';
  static const String fuelFilter = 'Топливный фильтр';
  static const String sparkPlugs = 'Свечи зажигания';
  static const String brakePads = 'Тормозные колодки';
  static const String brakeDiscs = 'Тормозные диски';
  static const String timingBelt = 'Ремень ГРМ';

  // Экран диагностики
  static const String diagnosticsTitle = 'Диагностика';
  static const String selectCategory = 'Выберите категорию';
  static const String enterSymptoms = 'Опишите симптомы';
  static const String diagnoseButton = 'Диагностировать';
  static const String possibleCauses = 'Возможные причины';
  static const String recommendedActions = 'Рекомендуемые действия';
  static const String askChatbot = 'Спросить бота';
  static const String symptomsHint = 'Например: "Машина не заводится" или "Странный шум при торможении"';

  // Экран карты сервисов
  static const String mapTitle = 'Карта сервисов';
  static const String searchService = 'Найти сервис';
  static const String filterServices = 'Фильтр';
  static const String nearbyServices = 'Ближайшие сервисы';
  static const String distance = 'Расстояние';
  static const String rating = 'Рейтинг';
  static const String openNow = 'Открыто сейчас';
  static const String directions = 'Маршрут';
  static const String callService = 'Позвонить';
  static const String serviceWebsite = 'Веб-сайт';
  static const String reviews = 'Отзывы';

  // Экран чата с механиком/ботом
  static const String chatTitle = 'Чат с механиком';
  static const String chatPlaceholder = 'Введите ваш вопрос...';
  static const String sendButton = 'Отправить';
  static const String chatBot = 'АвтоДок Бот';
  static const String chatWelcome = 'Здравствуйте! Я виртуальный автомеханик. Чем могу помочь?';
  static const String askGptTitle = 'Спросить AI помощника';

  // Экран профиля
  static const String profileTitle = 'Профиль';
  static const String editProfile = 'Редактировать профиль';
  static const String notificationsSettings = 'Настройки уведомлений';
  static const String language = 'Язык';
  static const String darkMode = 'Темная тема';
  static const String logout = 'Выйти';
  static const String confirmLogout = 'Вы уверены, что хотите выйти?';
  static const String deleteAccount = 'Удалить аккаунт';
  static const String confirmDeleteAccount = 'Вы уверены, что хотите удалить свой аккаунт? Это действие нельзя отменить.';
  static const String yesDelete = 'Да, удалить';

  // Общие кнопки и действия
  static const String ok = 'ОК';
  static const String cancel = 'Отмена';
  static const String yes = 'Да';
  static const String no = 'Нет';
  static const String save = 'Сохранить';
  static const String edit = 'Редактировать';
  static const String delete = 'Удалить';
  static const String search = 'Поиск';
  static const String filter = 'Фильтр';
  static const String reset = 'Сбросить';
  static const String apply = 'Применить';
  static const String select = 'Выбрать';
  static const String back = 'Назад';
  static const String more = 'Подробнее';

  // Категории и типы
  static const String engine = 'Двигатель';
  static const String transmission = 'Трансмиссия';
  static const String suspension = 'Подвеска';
  static const String electrical = 'Электрика';
  static const String body = 'Кузов';
  static const String tires = 'Шины';
  static const String brakes = 'Тормоза';
  static const String fuel = 'Топливная система';
  static const String cooling = 'Система охлаждения';
  static const String regular = 'Регулярное обслуживание';

  // Нижняя навигация
  static const String navHome = 'Главная';
  static const String navMaintenance = 'Обслуживание';
  static const String navDiagnostics = 'Диагностика';
  static const String navMap = 'Карта';
  static const String navChat = 'Чат';

  // Уведомления
  static const String notificationTitle = 'AutoDoc';
  static const String notificationOilChange = 'Пора заменить масло в вашем автомобиле';
  static const String notificationGeneralService = 'Запланированное ТО для вашего автомобиля';
  static const String notificationMileage = 'Достигнут пробег для проведения обслуживания';
}
