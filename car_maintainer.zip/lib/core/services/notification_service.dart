import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

import '../constants/text_constants.dart';
import '../../data/models/notification_model.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  // Приватный конструктор для синглтона
  NotificationService._();

  // Инициализация сервиса
  static Future<NotificationService> initialize() async {
    final instance = NotificationService._();
    await instance._init();
    return instance;
  }

  // Инициализация плагина уведомлений
  Future<void> _init() async {
    // Инициализация временных зон
    tz_data.initializeTimeZones();

    // Настройки для Android
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    // Настройки для iOS
    final DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings(
      requestSoundPermission: true,
      requestBadgePermission: true,
      requestAlertPermission: true,
      onDidReceiveLocalNotification: _onDidReceiveLocalNotification,
    );

    // Общие настройки
    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    // Инициализируем плагин с настройками
    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
    );

    // Запрашиваем разрешения для iOS
    if (Platform.isIOS) {
      await _flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
    }

    // Запрашиваем разрешения для Android 13+
    if (Platform.isAndroid) {
      await _flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestPermission();
    }
  }

  // Обработчик уведомлений для iOS 9 и ниже
  void _onDidReceiveLocalNotification(
    int id,
    String? title,
    String? body,
    String? payload,
  ) {
    debugPrint('Received notification: $id - $title - $body - $payload');
  }

  // Обработчик уведомлений
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    debugPrint('Notification clicked: ${response.payload}');
    // Здесь будет логика навигации к нужному экрану по payload
  }

  // Проверка разрешений
  Future<bool> checkPermissions() async {
    if (Platform.isAndroid) {
      final bool? granted = await _flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.areNotificationsEnabled();
      return granted ?? false;
    } else if (Platform.isIOS) {
      final bool? granted = await _flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
      return granted ?? false;
    }
    return false;
  }

  // Отображение локального уведомления немедленно
  Future<void> showNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'autodoc_channel',
      'AutoDoc Notifications',
      channelDescription: 'Канал для уведомлений приложения AutoDoc',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: true,
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _flutterLocalNotificationsPlugin.show(
      DateTime.now().millisecond,
      title,
      body,
      details,
      payload: payload,
    );
  }

  // Запланировать уведомление
  Future<int> scheduleNotification({
    required String title,
    required String body,
    required DateTime scheduledDate,
    String? payload,
  }) async {
    // Генерируем уникальный ID для уведомления
    int notificationId = DateTime.now().millisecond;

    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'autodoc_scheduled_channel',
      'AutoDoc Scheduled Notifications',
      channelDescription: 'Канал для запланированных уведомлений AutoDoc',
      importance: Importance.max,
      priority: Priority.high,
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails();

    const NotificationDetails details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    // Планируем уведомление
    await _flutterLocalNotificationsPlugin.zonedSchedule(
      notificationId,
      title,
      body,
      tz.TZDateTime.from(scheduledDate, tz.local),
      details,
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: payload,
    );

    return notificationId;
  }

  // Создать напоминание обслуживания
  Future<int> scheduleMaintenanceReminder(NotificationModel notification) async {
    String title = AppTexts.notificationTitle;
    String body;

    // Определяем текст в зависимости от типа уведомления
    switch (notification.type) {
      case 'oil_change':
        body = AppTexts.notificationOilChange;
        break;
      case 'mileage':
        body = AppTexts.notificationMileage;
        break;
      default:
        body = AppTexts.notificationGeneralService;
    }

    // Добавляем имя автомобиля, если указано
    if (notification.vehicleName != null) {
      body += ' ${notification.vehicleName}';
    }

    // Планируем уведомление
    return scheduleNotification(
      title: title,
      body: body,
      scheduledDate: notification.scheduledDate,
      payload: 'vehicle_${notification.vehicleId}',
    );
  }

  // Отмена конкретного уведомления
  Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  // Отмена всех уведомлений
  Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }
}
