import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../constants/app_constants.dart';
import '../../data/models/user_model.dart';
import '../../data/models/vehicle_model.dart';
import '../../data/models/maintenance_model.dart';
import '../../data/models/notification_model.dart';

class StorageService {
  late SharedPreferences _prefs;
  late Box _vehiclesBox;
  late Box _maintenanceBox;
  late Box _notificationsBox;

  // Приватный конструктор для синглтона
  StorageService._();

  // Инициализация сервиса
  static Future<StorageService> initialize() async {
    final instance = StorageService._();

    // Инициализация SharedPreferences
    instance._prefs = await SharedPreferences.getInstance();

    // Открытие боксов Hive
    instance._vehiclesBox = await Hive.openBox('vehicles');
    instance._maintenanceBox = await Hive.openBox('maintenance');
    instance._notificationsBox = await Hive.openBox('notifications');

    return instance;
  }

  // Методы для работы с темой
  bool getThemeMode() {
    return _prefs.getBool(AppConstants.themeKey) ?? false;
  }

  Future<void> setThemeMode(bool isDarkMode) async {
    await _prefs.setBool(AppConstants.themeKey, isDarkMode);
  }

  // Методы для работы с языком
  String getLanguage() {
    return _prefs.getString(AppConstants.languageKey) ?? 'ru';
  }

  Future<void> setLanguage(String languageCode) async {
    await _prefs.setString(AppConstants.languageKey, languageCode);
  }

  // Методы для работы с пользователем
  UserModel? getUser() {
    final userString = _prefs.getString(AppConstants.userKey);
    if (userString == null) return null;

    final userMap = jsonDecode(userString) as Map<String, dynamic>;
    return UserModel.fromJson(userMap);
  }

  Future<void> setUser(UserModel user) async {
    final userString = jsonEncode(user.toJson());
    await _prefs.setString(AppConstants.userKey, userString);
  }

  Future<void> clearUser() async {
    await _prefs.remove(AppConstants.userKey);
    await _prefs.remove(AppConstants.tokenKey);
  }

  // Методы для работы с токеном
  String? getToken() {
    return _prefs.getString(AppConstants.tokenKey);
  }

  Future<void> setToken(String token) async {
    await _prefs.setString(AppConstants.tokenKey, token);
  }

  // Методы для работы с первым запуском
  bool isFirstLaunch() {
    return _prefs.getBool(AppConstants.firstLaunchKey) ?? true;
  }

  Future<void> setFirstLaunch(bool isFirst) async {
    await _prefs.setBool(AppConstants.firstLaunchKey, isFirst);
  }

  // Методы для работы с автомобилями
  List<VehicleModel> getVehicles() {
    final vehicles = <VehicleModel>[];

    for (final key in _vehiclesBox.keys) {
      final vehicleMap = _vehiclesBox.get(key) as Map<dynamic, dynamic>;
      final vehicleModel = VehicleModel.fromJson(
        Map<String, dynamic>.from(vehicleMap),
      );
      vehicles.add(vehicleModel);
    }

    return vehicles;
  }

  Future<void> addVehicle(VehicleModel vehicle) async {
    await _vehiclesBox.put(vehicle.id, vehicle.toJson());
  }

  Future<void> updateVehicle(VehicleModel vehicle) async {
    await _vehiclesBox.put(vehicle.id, vehicle.toJson());
  }

  Future<void> deleteVehicle(String id) async {
    await _vehiclesBox.delete(id);

    // Удаляем соответствующие записи обслуживания
    final maintenanceKeys = _maintenanceBox.keys.where((key) {
      final maintenanceMap = _maintenanceBox.get(key) as Map<dynamic, dynamic>;
      return maintenanceMap['vehicleId'] == id;
    }).toList();

    for (final key in maintenanceKeys) {
      await _maintenanceBox.delete(key);
    }

    // Удаляем соответствующие уведомления
    final notificationKeys = _notificationsBox.keys.where((key) {
      final notificationMap = _notificationsBox.get(key) as Map<dynamic, dynamic>;
      return notificationMap['vehicleId'] == id;
    }).toList();

    for (final key in notificationKeys) {
      await _notificationsBox.delete(key);
    }
  }

  VehicleModel? getVehicleById(String id) {
    if (!_vehiclesBox.containsKey(id)) return null;

    final vehicleMap = _vehiclesBox.get(id) as Map<dynamic, dynamic>;
    return VehicleModel.fromJson(Map<String, dynamic>.from(vehicleMap));
  }

  // Методы для работы с обслуживанием
  List<MaintenanceModel> getMaintenanceByVehicleId(String vehicleId) {
    final maintenance = <MaintenanceModel>[];

    for (final key in _maintenanceBox.keys) {
      final maintenanceMap = _maintenanceBox.get(key) as Map<dynamic, dynamic>;

      if (maintenanceMap['vehicleId'] == vehicleId) {
        final maintenanceModel = MaintenanceModel.fromJson(
          Map<String, dynamic>.from(maintenanceMap),
        );
        maintenance.add(maintenanceModel);
      }
    }

    // Сортировка по дате (от новых к старым)
    maintenance.sort((a, b) => b.date.compareTo(a.date));

    return maintenance;
  }

  Future<void> addMaintenance(MaintenanceModel maintenance) async {
    await _maintenanceBox.put(maintenance.id, maintenance.toJson());

    // Обновляем последнюю дату обслуживания и пробег в автомобиле
    final vehicle = getVehicleById(maintenance.vehicleId);
    if (vehicle != null) {
      final updatedVehicle = vehicle.copyWith(
        lastServiceDate: maintenance.date,
        mileage: maintenance.mileage,
      );
      await updateVehicle(updatedVehicle);
    }
  }

  Future<void> updateMaintenance(MaintenanceModel maintenance) async {
    await _maintenanceBox.put(maintenance.id, maintenance.toJson());
  }

  Future<void> deleteMaintenance(String id) async {
    await _maintenanceBox.delete(id);
  }

  // Методы для работы с уведомлениями
  List<NotificationModel> getNotifications() {
    final notifications = <NotificationModel>[];

    for (final key in _notificationsBox.keys) {
      final notificationMap = _notificationsBox.get(key) as Map<dynamic, dynamic>;
      final notificationModel = NotificationModel.fromJson(
        Map<String, dynamic>.from(notificationMap),
      );
      notifications.add(notificationModel);
    }

    // Сортировка по дате (от новых к старым)
    notifications.sort((a, b) => a.scheduledDate.compareTo(b.scheduledDate));

    return notifications;
  }

  List<NotificationModel> getVehicleNotifications(String vehicleId) {
    return getNotifications()
        .where((notification) => notification.vehicleId == vehicleId)
        .toList();
  }

  Future<void> addNotification(NotificationModel notification) async {
    await _notificationsBox.put(notification.id, notification.toJson());
  }

  Future<void> updateNotification(NotificationModel notification) async {
    await _notificationsBox.put(notification.id, notification.toJson());
  }

  Future<void> deleteNotification(String id) async {
    await _notificationsBox.delete(id);
  }

  Future<void> clearAll() async {
    await _prefs.clear();
    await _vehiclesBox.clear();
    await _maintenanceBox.clear();
    await _notificationsBox.clear();
  }
}
