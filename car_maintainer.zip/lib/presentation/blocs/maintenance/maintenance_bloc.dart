import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/services/storage_service.dart';
import '../../../core/services/notification_service.dart';
import '../../../data/repositories/maintenance_repository.dart';
import '../../../data/models/maintenance_model.dart';

// События
abstract class MaintenanceEvent extends Equatable {
  const MaintenanceEvent();

  @override
  List<Object?> get props => [];
}

class MaintenanceFetched extends MaintenanceEvent {
  final String vehicleId;

  const MaintenanceFetched(this.vehicleId);

  @override
  List<Object?> get props => [vehicleId];
}

class MaintenanceAdded extends MaintenanceEvent {
  final MaintenanceModel maintenance;

  const MaintenanceAdded(this.maintenance);

  @override
  List<Object?> get props => [maintenance];
}

class MaintenanceUpdated extends MaintenanceEvent {
  final MaintenanceModel maintenance;

  const MaintenanceUpdated(this.maintenance);

  @override
  List<Object?> get props => [maintenance];
}

class MaintenanceDeleted extends MaintenanceEvent {
  final String id;
  final String vehicleId;

  const MaintenanceDeleted({
    required this.id,
    required this.vehicleId,
  });

  @override
  List<Object?> get props => [id, vehicleId];
}

class MaintenanceNotificationsChecked extends MaintenanceEvent {
  final String vehicleId;
  final int newMileage;

  const MaintenanceNotificationsChecked({
    required this.vehicleId,
    required this.newMileage,
  });

  @override
  List<Object?> get props => [vehicleId, newMileage];
}

// Состояния
abstract class MaintenanceState extends Equatable {
  const MaintenanceState();

  @override
  List<Object?> get props => [];
}

class MaintenanceInitial extends MaintenanceState {
  const MaintenanceInitial();
}

class MaintenanceLoading extends MaintenanceState {
  const MaintenanceLoading();
}

class MaintenanceLoaded extends MaintenanceState {
  final List<MaintenanceModel> maintenanceList;
  final MaintenanceModel? selectedMaintenance;

  const MaintenanceLoaded({
    required this.maintenanceList,
    this.selectedMaintenance,
  });

  @override
  List<Object?> get props => [maintenanceList, selectedMaintenance];

  MaintenanceLoaded copyWith({
    List<MaintenanceModel>? maintenanceList,
    MaintenanceModel? selectedMaintenance,
  }) {
    return MaintenanceLoaded(
      maintenanceList: maintenanceList ?? this.maintenanceList,
      selectedMaintenance: selectedMaintenance ?? this.selectedMaintenance,
    );
  }
}

class MaintenanceError extends MaintenanceState {
  final String message;

  const MaintenanceError(this.message);

  @override
  List<Object?> get props => [message];
}

// Блок
class MaintenanceBloc extends Bloc<MaintenanceEvent, MaintenanceState> {
  final MaintenanceRepository repository;

  MaintenanceBloc({
    required StorageService storageService,
    required NotificationService notificationService,
  }) : repository = MaintenanceRepository(storageService, notificationService),
       super(const MaintenanceInitial()) {
    on<MaintenanceFetched>(_onMaintenanceFetched);
    on<MaintenanceAdded>(_onMaintenanceAdded);
    on<MaintenanceUpdated>(_onMaintenanceUpdated);
    on<MaintenanceDeleted>(_onMaintenanceDeleted);
    on<MaintenanceNotificationsChecked>(_onMaintenanceNotificationsChecked);
  }

  Future<void> _onMaintenanceFetched(
    MaintenanceFetched event,
    Emitter<MaintenanceState> emit,
  ) async {
    emit(const MaintenanceLoading());

    try {
      final maintenanceList = repository.getMaintenanceHistory(event.vehicleId);

      emit(MaintenanceLoaded(maintenanceList: maintenanceList));
    } catch (e) {
      emit(MaintenanceError(e.toString()));
    }
  }

  Future<void> _onMaintenanceAdded(
    MaintenanceAdded event,
    Emitter<MaintenanceState> emit,
  ) async {
    if (state is MaintenanceLoaded) {
      emit(const MaintenanceLoading());

      try {
        await repository.addMaintenance(event.maintenance);

        final maintenanceList =
            repository.getMaintenanceHistory(event.maintenance.vehicleId);

        emit(MaintenanceLoaded(
          maintenanceList: maintenanceList,
          selectedMaintenance: event.maintenance,
        ));
      } catch (e) {
        emit(MaintenanceError(e.toString()));
      }
    }
  }

  Future<void> _onMaintenanceUpdated(
    MaintenanceUpdated event,
    Emitter<MaintenanceState> emit,
  ) async {
    if (state is MaintenanceLoaded) {
      emit(const MaintenanceLoading());

      try {
        await repository.updateMaintenance(event.maintenance);

        final maintenanceList =
            repository.getMaintenanceHistory(event.maintenance.vehicleId);

        emit(MaintenanceLoaded(
          maintenanceList: maintenanceList,
          selectedMaintenance: event.maintenance,
        ));
      } catch (e) {
        emit(MaintenanceError(e.toString()));
      }
    }
  }

  Future<void> _onMaintenanceDeleted(
    MaintenanceDeleted event,
    Emitter<MaintenanceState> emit,
  ) async {
    if (state is MaintenanceLoaded) {
      emit(const MaintenanceLoading());

      try {
        await repository.deleteMaintenance(event.id);

        final maintenanceList =
            repository.getMaintenanceHistory(event.vehicleId);

        emit(MaintenanceLoaded(maintenanceList: maintenanceList));
      } catch (e) {
        emit(MaintenanceError(e.toString()));
      }
    }
  }

  Future<void> _onMaintenanceNotificationsChecked(
    MaintenanceNotificationsChecked event,
    Emitter<MaintenanceState> emit,
  ) async {
    try {
      await repository.checkMileageNotifications(
        event.vehicleId,
        event.newMileage,
      );

      // Не обновляем состояние, так как это просто проверка уведомлений
    } catch (e) {
      // Игнорируем ошибки при проверке уведомлений
    }
  }
}
