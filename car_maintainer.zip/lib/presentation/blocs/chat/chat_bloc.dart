import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/repositories/chat_repository.dart';
import '../../../data/models/chat_message_model.dart';

// События
abstract class ChatEvent extends Equatable {
  const ChatEvent();

  @override
  List<Object?> get props => [];
}

class ChatHistoryFetched extends ChatEvent {
  const ChatHistoryFetched();
}

class ChatMessageSent extends ChatEvent {
  final String text;

  const ChatMessageSent(this.text);

  @override
  List<Object?> get props => [text];
}

class ChatHistoryCleared extends ChatEvent {
  const ChatHistoryCleared();
}

// Состояния
abstract class ChatState extends Equatable {
  const ChatState();

  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {
  const ChatInitial();
}

class ChatLoading extends ChatState {
  const ChatLoading();
}

class ChatLoaded extends ChatState {
  final ChatConversationModel conversation;
  final bool isReplying;

  const ChatLoaded({
    required this.conversation,
    this.isReplying = false,
  });

  @override
  List<Object?> get props => [conversation, isReplying];

  ChatLoaded copyWith({
    ChatConversationModel? conversation,
    bool? isReplying,
  }) {
    return ChatLoaded(
      conversation: conversation ?? this.conversation,
      isReplying: isReplying ?? this.isReplying,
    );
  }
}

class ChatError extends ChatState {
  final String message;

  const ChatError(this.message);

  @override
  List<Object?> get props => [message];
}

// Блок
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ChatRepository repository;

  ChatBloc() :
    repository = ChatRepository(),
    super(const ChatInitial()) {
    on<ChatHistoryFetched>(_onChatHistoryFetched);
    on<ChatMessageSent>(_onChatMessageSent);
    on<ChatHistoryCleared>(_onChatHistoryCleared);
  }

  Future<void> _onChatHistoryFetched(
    ChatHistoryFetched event,
    Emitter<ChatState> emit,
  ) async {
    emit(const ChatLoading());

    try {
      final conversation = await repository.getChatHistory();
      emit(ChatLoaded(conversation: conversation));
    } catch (e) {
      emit(ChatError(e.toString()));
    }
  }

  Future<void> _onChatMessageSent(
    ChatMessageSent event,
    Emitter<ChatState> emit,
  ) async {
    if (state is ChatLoaded) {
      final currentState = state as ChatLoaded;

      // Обновляем состояние, показывая индикатор ответа
      emit(currentState.copyWith(isReplying: true));

      try {
        // Получаем ответ на сообщение
        final botResponse = await repository.sendMessage(event.text);

        // Получаем обновленную историю
        final conversation = await repository.getChatHistory();

        emit(ChatLoaded(conversation: conversation));
      } catch (e) {
        emit(ChatError(e.toString()));
      }
    }
  }

  Future<void> _onChatHistoryCleared(
    ChatHistoryCleared event,
    Emitter<ChatState> emit,
  ) async {
    emit(const ChatLoading());

    try {
      final conversation = await repository.clearChatHistory();
      emit(ChatLoaded(conversation: conversation));
    } catch (e) {
      emit(ChatError(e.toString()));
    }
  }
}
