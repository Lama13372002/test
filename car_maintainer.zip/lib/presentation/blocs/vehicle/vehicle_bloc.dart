import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/repositories/vehicle_repository.dart';
import '../../../data/models/vehicle_model.dart';

// События
abstract class VehicleEvent extends Equatable {
  const VehicleEvent();

  @override
  List<Object?> get props => [];
}

class VehiclesFetched extends VehicleEvent {
  const VehiclesFetched();
}

class VehicleAdded extends VehicleEvent {
  final VehicleModel vehicle;

  const VehicleAdded(this.vehicle);

  @override
  List<Object?> get props => [vehicle];
}

class VehicleUpdated extends VehicleEvent {
  final VehicleModel vehicle;

  const VehicleUpdated(this.vehicle);

  @override
  List<Object?> get props => [vehicle];
}

class VehicleDeleted extends VehicleEvent {
  final String id;

  const VehicleDeleted(this.id);

  @override
  List<Object?> get props => [id];
}

class VehicleMileageUpdated extends VehicleEvent {
  final String id;
  final int newMileage;

  const VehicleMileageUpdated({
    required this.id,
    required this.newMileage,
  });

  @override
  List<Object?> get props => [id, newMileage];
}

// Состояния
abstract class VehicleState extends Equatable {
  const VehicleState();

  @override
  List<Object?> get props => [];
}

class VehicleInitial extends VehicleState {
  const VehicleInitial();
}

class VehicleLoading extends VehicleState {
  const VehicleLoading();
}

class VehicleLoaded extends VehicleState {
  final List<VehicleModel> vehicles;
  final VehicleModel? selectedVehicle;

  const VehicleLoaded({
    required this.vehicles,
    this.selectedVehicle,
  });

  @override
  List<Object?> get props => [vehicles, selectedVehicle];

  VehicleLoaded copyWith({
    List<VehicleModel>? vehicles,
    VehicleModel? selectedVehicle,
  }) {
    return VehicleLoaded(
      vehicles: vehicles ?? this.vehicles,
      selectedVehicle: selectedVehicle ?? this.selectedVehicle,
    );
  }
}

class VehicleError extends VehicleState {
  final String message;

  const VehicleError(this.message);

  @override
  List<Object?> get props => [message];
}

// Блок
class VehicleBloc extends Bloc<VehicleEvent, VehicleState> {
  final VehicleRepository repository;

  VehicleBloc({required this.repository}) : super(const VehicleInitial()) {
    on<VehiclesFetched>(_onVehiclesFetched);
    on<VehicleAdded>(_onVehicleAdded);
    on<VehicleUpdated>(_onVehicleUpdated);
    on<VehicleDeleted>(_onVehicleDeleted);
    on<VehicleMileageUpdated>(_onVehicleMileageUpdated);
  }

  Future<void> _onVehiclesFetched(
    VehiclesFetched event,
    Emitter<VehicleState> emit,
  ) async {
    emit(const VehicleLoading());

    try {
      final vehicles = repository.getVehicles();

      // Сортируем автомобили по году выпуска (от новых к старым)
      vehicles.sort((a, b) => b.year.compareTo(a.year));

      emit(VehicleLoaded(vehicles: vehicles));
    } catch (e) {
      emit(VehicleError(e.toString()));
    }
  }

  Future<void> _onVehicleAdded(
    VehicleAdded event,
    Emitter<VehicleState> emit,
  ) async {
    if (state is VehicleLoaded) {
      emit(const VehicleLoading());

      try {
        await repository.addVehicle(event.vehicle);

        final vehicles = repository.getVehicles();
        vehicles.sort((a, b) => b.year.compareTo(a.year));

        emit(VehicleLoaded(
          vehicles: vehicles,
          selectedVehicle: event.vehicle,
        ));
      } catch (e) {
        emit(VehicleError(e.toString()));
      }
    }
  }

  Future<void> _onVehicleUpdated(
    VehicleUpdated event,
    Emitter<VehicleState> emit,
  ) async {
    if (state is VehicleLoaded) {
      emit(const VehicleLoading());

      try {
        await repository.updateVehicle(event.vehicle);

        final vehicles = repository.getVehicles();
        vehicles.sort((a, b) => b.year.compareTo(a.year));

        emit(VehicleLoaded(
          vehicles: vehicles,
          selectedVehicle: event.vehicle,
        ));
      } catch (e) {
        emit(VehicleError(e.toString()));
      }
    }
  }

  Future<void> _onVehicleDeleted(
    VehicleDeleted event,
    Emitter<VehicleState> emit,
  ) async {
    if (state is VehicleLoaded) {
      emit(const VehicleLoading());

      try {
        await repository.deleteVehicle(event.id);

        final vehicles = repository.getVehicles();
        vehicles.sort((a, b) => b.year.compareTo(a.year));

        emit(VehicleLoaded(vehicles: vehicles));
      } catch (e) {
        emit(VehicleError(e.toString()));
      }
    }
  }

  Future<void> _onVehicleMileageUpdated(
    VehicleMileageUpdated event,
    Emitter<VehicleState> emit,
  ) async {
    if (state is VehicleLoaded) {
      emit(const VehicleLoading());

      try {
        await repository.updateMileage(event.id, event.newMileage);

        final vehicles = repository.getVehicles();
        vehicles.sort((a, b) => b.year.compareTo(a.year));

        final updatedVehicle = repository.getVehicleById(event.id);

        emit(VehicleLoaded(
          vehicles: vehicles,
          selectedVehicle: updatedVehicle,
        ));
      } catch (e) {
        emit(VehicleError(e.toString()));
      }
    }
  }
}
