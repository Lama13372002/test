import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/services/storage_service.dart';

// События
abstract class ThemeEvent extends Equatable {
  const ThemeEvent();

  @override
  List<Object?> get props => [];
}

class ThemeChanged extends ThemeEvent {
  final bool isDarkMode;

  const ThemeChanged({required this.isDarkMode});

  @override
  List<Object?> get props => [isDarkMode];
}

class ThemeToggled extends ThemeEvent {
  const ThemeToggled();
}

// Состояния
class ThemeState extends Equatable {
  final bool isDarkMode;

  const ThemeState({required this.isDarkMode});

  @override
  List<Object?> get props => [isDarkMode];
}

// Блок
class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  final StorageService? _storageService;

  ThemeBloc({
    required bool isDarkMode,
    StorageService? storageService,
  }) : _storageService = storageService,
       super(ThemeState(isDarkMode: isDarkMode)) {
    on<ThemeChanged>(_onThemeChanged);
    on<ThemeToggled>(_onThemeToggled);
  }

  Future<void> _onThemeChanged(
    ThemeChanged event,
    Emitter<ThemeState> emit,
  ) async {
    // Сохраняем выбранную тему
    if (_storageService != null) {
      await _storageService!.setThemeMode(event.isDarkMode);
    }

    emit(ThemeState(isDarkMode: event.isDarkMode));
  }

  Future<void> _onThemeToggled(
    ThemeToggled event,
    Emitter<ThemeState> emit,
  ) async {
    final newTheme = !state.isDarkMode;

    // Сохраняем выбранную тему
    if (_storageService != null) {
      await _storageService!.setThemeMode(newTheme);
    }

    emit(ThemeState(isDarkMode: newTheme));
  }
}
