import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/repositories/diagnostic_repository.dart';
import '../../../data/models/diagnostic_model.dart';

// События
abstract class DiagnosticEvent extends Equatable {
  const DiagnosticEvent();

  @override
  List<Object?> get props => [];
}

class DiagnosticHistoryFetched extends DiagnosticEvent {
  const DiagnosticHistoryFetched();
}

class DiagnosticQuerySubmitted extends DiagnosticEvent {
  final String category;
  final String symptomDescription;

  const DiagnosticQuerySubmitted({
    required this.category,
    required this.symptomDescription,
  });

  @override
  List<Object?> get props => [category, symptomDescription];
}

class DiagnosticHistoryCleared extends DiagnosticEvent {
  const DiagnosticHistoryCleared();
}

class DiagnosticCommonProblemsFetched extends DiagnosticEvent {
  final String category;

  const DiagnosticCommonProblemsFetched(this.category);

  @override
  List<Object?> get props => [category];
}

// Состояния
abstract class DiagnosticState extends Equatable {
  const DiagnosticState();

  @override
  List<Object?> get props => [];
}

class DiagnosticInitial extends DiagnosticState {
  const DiagnosticInitial();
}

class DiagnosticLoading extends DiagnosticState {
  const DiagnosticLoading();
}

class DiagnosticHistoryLoaded extends DiagnosticState {
  final List<DiagnosticQueryModel> history;

  const DiagnosticHistoryLoaded(this.history);

  @override
  List<Object?> get props => [history];
}

class DiagnosticResultsLoaded extends DiagnosticState {
  final DiagnosticQueryModel query;

  const DiagnosticResultsLoaded(this.query);

  @override
  List<Object?> get props => [query];
}

class DiagnosticCommonProblemsLoaded extends DiagnosticState {
  final String category;
  final List<String> commonProblems;

  const DiagnosticCommonProblemsLoaded({
    required this.category,
    required this.commonProblems,
  });

  @override
  List<Object?> get props => [category, commonProblems];
}

class DiagnosticError extends DiagnosticState {
  final String message;

  const DiagnosticError(this.message);

  @override
  List<Object?> get props => [message];
}

// Блок
class DiagnosticBloc extends Bloc<DiagnosticEvent, DiagnosticState> {
  final DiagnosticRepository repository;

  DiagnosticBloc() :
    repository = DiagnosticRepository(),
    super(const DiagnosticInitial()) {
    on<DiagnosticHistoryFetched>(_onDiagnosticHistoryFetched);
    on<DiagnosticQuerySubmitted>(_onDiagnosticQuerySubmitted);
    on<DiagnosticHistoryCleared>(_onDiagnosticHistoryCleared);
    on<DiagnosticCommonProblemsFetched>(_onDiagnosticCommonProblemsFetched);
  }

  Future<void> _onDiagnosticHistoryFetched(
    DiagnosticHistoryFetched event,
    Emitter<DiagnosticState> emit,
  ) async {
    emit(const DiagnosticLoading());

    try {
      final history = await repository.getDiagnosticHistory();
      emit(DiagnosticHistoryLoaded(history));
    } catch (e) {
      emit(DiagnosticError(e.toString()));
    }
  }

  Future<void> _onDiagnosticQuerySubmitted(
    DiagnosticQuerySubmitted event,
    Emitter<DiagnosticState> emit,
  ) async {
    emit(const DiagnosticLoading());

    try {
      // Получаем результаты диагностики
      final results = await repository.diagnoseBySymptomsLocal(
        event.category,
        event.symptomDescription,
      );

      // Создаем новый запрос
      final query = DiagnosticQueryModel.create(
        category: event.category,
        description: event.symptomDescription,
        results: results,
      );

      // Сохраняем запрос в историю
      await repository.saveDiagnosticQuery(query);

      emit(DiagnosticResultsLoaded(query));
    } catch (e) {
      emit(DiagnosticError(e.toString()));
    }
  }

  Future<void> _onDiagnosticHistoryCleared(
    DiagnosticHistoryCleared event,
    Emitter<DiagnosticState> emit,
  ) async {
    emit(const DiagnosticLoading());

    try {
      await repository.clearDiagnosticHistory();
      emit(const DiagnosticHistoryLoaded([]));
    } catch (e) {
      emit(DiagnosticError(e.toString()));
    }
  }

  void _onDiagnosticCommonProblemsFetched(
    DiagnosticCommonProblemsFetched event,
    Emitter<DiagnosticState> emit,
  ) {
    emit(const DiagnosticLoading());

    try {
      final commonProblems = repository.getCommonProblems(event.category);

      emit(DiagnosticCommonProblemsLoaded(
        category: event.category,
        commonProblems: commonProblems,
      ));
    } catch (e) {
      emit(DiagnosticError(e.toString()));
    }
  }
}
