import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:geolocator/geolocator.dart';

import '../../../data/repositories/service_center_repository.dart';
import '../../../data/models/service_center_model.dart';

// События
abstract class ServiceMapEvent extends Equatable {
  const ServiceMapEvent();

  @override
  List<Object?> get props => [];
}

class ServiceMapInitialized extends ServiceMapEvent {
  const ServiceMapInitialized();
}

class ServiceMapServicesFetched extends ServiceMapEvent {
  const ServiceMapServicesFetched();
}

class ServiceMapFilterByType extends ServiceMapEvent {
  final String type;

  const ServiceMapFilterByType(this.type);

  @override
  List<Object?> get props => [type];
}

class ServiceMapSearchByName extends ServiceMapEvent {
  final String query;

  const ServiceMapSearchByName(this.query);

  @override
  List<Object?> get props => [query];
}

class ServiceMapFilterByDistance extends ServiceMapEvent {
  final double maxDistance; // в километрах

  const ServiceMapFilterByDistance(this.maxDistance);

  @override
  List<Object?> get props => [maxDistance];
}

class ServiceMapReviewAdded extends ServiceMapEvent {
  final String serviceCenterId;
  final String authorName;
  final double rating;
  final String text;

  const ServiceMapReviewAdded({
    required this.serviceCenterId,
    required this.authorName,
    required this.rating,
    required this.text,
  });

  @override
  List<Object?> get props => [serviceCenterId, authorName, rating, text];
}

// Состояния
abstract class ServiceMapState extends Equatable {
  const ServiceMapState();

  @override
  List<Object?> get props => [];
}

class ServiceMapInitial extends ServiceMapState {
  const ServiceMapInitial();
}

class ServiceMapLoading extends ServiceMapState {
  const ServiceMapLoading();
}

class ServiceMapLocationPermissionDenied extends ServiceMapState {
  final String message;

  const ServiceMapLocationPermissionDenied(this.message);

  @override
  List<Object?> get props => [message];
}

class ServiceMapLoaded extends ServiceMapState {
  final List<ServiceCenterModel> serviceCenters;
  final ServiceCenterModel? selectedServiceCenter;
  final Position? currentPosition;

  const ServiceMapLoaded({
    required this.serviceCenters,
    this.selectedServiceCenter,
    this.currentPosition,
  });

  @override
  List<Object?> get props => [serviceCenters, selectedServiceCenter, currentPosition];

  ServiceMapLoaded copyWith({
    List<ServiceCenterModel>? serviceCenters,
    ServiceCenterModel? selectedServiceCenter,
    Position? currentPosition,
  }) {
    return ServiceMapLoaded(
      serviceCenters: serviceCenters ?? this.serviceCenters,
      selectedServiceCenter: selectedServiceCenter ?? this.selectedServiceCenter,
      currentPosition: currentPosition ?? this.currentPosition,
    );
  }
}

class ServiceMapError extends ServiceMapState {
  final String message;

  const ServiceMapError(this.message);

  @override
  List<Object?> get props => [message];
}

// Блок
class ServiceMapBloc extends Bloc<ServiceMapEvent, ServiceMapState> {
  final ServiceCenterRepository repository;

  ServiceMapBloc() :
    repository = ServiceCenterRepository(),
    super(const ServiceMapInitial()) {
    on<ServiceMapInitialized>(_onServiceMapInitialized);
    on<ServiceMapServicesFetched>(_onServiceMapServicesFetched);
    on<ServiceMapFilterByType>(_onServiceMapFilterByType);
    on<ServiceMapSearchByName>(_onServiceMapSearchByName);
    on<ServiceMapFilterByDistance>(_onServiceMapFilterByDistance);
    on<ServiceMapReviewAdded>(_onServiceMapReviewAdded);
  }

  Future<void> _onServiceMapInitialized(
    ServiceMapInitialized event,
    Emitter<ServiceMapState> emit,
  ) async {
    emit(const ServiceMapLoading());

    try {
      final serviceCenters = await repository.getServiceCenters();

      emit(ServiceMapLoaded(serviceCenters: serviceCenters));
    } catch (e) {
      if (e.toString().contains('геолокац')) {
        emit(ServiceMapLocationPermissionDenied(e.toString()));
      } else {
        emit(ServiceMapError(e.toString()));
      }
    }
  }

  Future<void> _onServiceMapServicesFetched(
    ServiceMapServicesFetched event,
    Emitter<ServiceMapState> emit,
  ) async {
    emit(const ServiceMapLoading());

    try {
      final serviceCenters = await repository.getServiceCenters();

      emit(ServiceMapLoaded(serviceCenters: serviceCenters));
    } catch (e) {
      emit(ServiceMapError(e.toString()));
    }
  }

  Future<void> _onServiceMapFilterByType(
    ServiceMapFilterByType event,
    Emitter<ServiceMapState> emit,
  ) async {
    if (state is ServiceMapLoaded) {
      emit(const ServiceMapLoading());

      try {
        final filteredCenters = await repository.searchServiceCentersByType(event.type);

        emit(ServiceMapLoaded(
          serviceCenters: filteredCenters,
          currentPosition: (state as ServiceMapLoaded).currentPosition,
        ));
      } catch (e) {
        emit(ServiceMapError(e.toString()));
      }
    }
  }

  Future<void> _onServiceMapSearchByName(
    ServiceMapSearchByName event,
    Emitter<ServiceMapState> emit,
  ) async {
    if (state is ServiceMapLoaded) {
      emit(const ServiceMapLoading());

      try {
        final searchResults = await repository.searchServiceCentersByName(event.query);

        emit(ServiceMapLoaded(
          serviceCenters: searchResults,
          currentPosition: (state as ServiceMapLoaded).currentPosition,
        ));
      } catch (e) {
        emit(ServiceMapError(e.toString()));
      }
    }
  }

  Future<void> _onServiceMapFilterByDistance(
    ServiceMapFilterByDistance event,
    Emitter<ServiceMapState> emit,
  ) async {
    if (state is ServiceMapLoaded) {
      emit(const ServiceMapLoading());

      try {
        final nearbyCenters = await repository.getNearbyServiceCenters(event.maxDistance);

        emit(ServiceMapLoaded(
          serviceCenters: nearbyCenters,
          currentPosition: (state as ServiceMapLoaded).currentPosition,
        ));
      } catch (e) {
        emit(ServiceMapError(e.toString()));
      }
    }
  }

  Future<void> _onServiceMapReviewAdded(
    ServiceMapReviewAdded event,
    Emitter<ServiceMapState> emit,
  ) async {
    if (state is ServiceMapLoaded) {
      final currentState = state as ServiceMapLoaded;

      try {
        await repository.addReview(
          event.serviceCenterId,
          event.authorName,
          event.rating,
          event.text,
        );

        // Обновляем список сервисных центров
        final updatedCenters = await repository.getServiceCenters();

        // Находим обновленный сервисный центр
        final updatedCenter = updatedCenters.firstWhere(
          (center) => center.id == event.serviceCenterId,
        );

        emit(ServiceMapLoaded(
          serviceCenters: updatedCenters,
          selectedServiceCenter: updatedCenter,
          currentPosition: currentState.currentPosition,
        ));
      } catch (e) {
        emit(ServiceMapError(e.toString()));
      }
    }
  }
}
