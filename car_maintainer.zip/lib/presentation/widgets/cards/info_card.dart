import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';

enum InfoCardType {
  primary,
  success,
  warning,
  error,
  info,
}

class InfoCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData? icon;
  final InfoCardType type;
  final VoidCallback? onTap;
  final Widget? trailing;
  final bool hasShadow;
  final double borderRadius;
  final EdgeInsets padding;

  const InfoCard({
    Key? key,
    required this.title,
    this.subtitle,
    this.icon,
    this.type = InfoCardType.primary,
    this.onTap,
    this.trailing,
    this.hasShadow = true,
    this.borderRadius = 16.0,
    this.padding = const EdgeInsets.all(16.0),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Определяем цвета в зависимости от типа карточки
    Color backgroundColor;
    Color iconColor;
    Color borderColor;

    switch (type) {
      case InfoCardType.primary:
        backgroundColor = theme.brightness == Brightness.dark
            ? AppColors.primary.withOpacity(0.15)
            : AppColors.primary.withOpacity(0.08);
        iconColor = AppColors.primary;
        borderColor = AppColors.primary.withOpacity(0.3);
        break;

      case InfoCardType.success:
        backgroundColor = theme.brightness == Brightness.dark
            ? AppColors.success.withOpacity(0.15)
            : AppColors.success.withOpacity(0.08);
        iconColor = AppColors.success;
        borderColor = AppColors.success.withOpacity(0.3);
        break;

      case InfoCardType.warning:
        backgroundColor = theme.brightness == Brightness.dark
            ? AppColors.warning.withOpacity(0.15)
            : AppColors.warning.withOpacity(0.08);
        iconColor = AppColors.warning;
        borderColor = AppColors.warning.withOpacity(0.3);
        break;

      case InfoCardType.error:
        backgroundColor = theme.brightness == Brightness.dark
            ? AppColors.error.withOpacity(0.15)
            : AppColors.error.withOpacity(0.08);
        iconColor = AppColors.error;
        borderColor = AppColors.error.withOpacity(0.3);
        break;

      case InfoCardType.info:
        backgroundColor = theme.brightness == Brightness.dark
            ? AppColors.info.withOpacity(0.15)
            : AppColors.info.withOpacity(0.08);
        iconColor = AppColors.info;
        borderColor = AppColors.info.withOpacity(0.3);
        break;
    }

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(borderRadius),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(borderRadius),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: borderColor,
              width: 1.0,
            ),
            boxShadow: hasShadow
                ? [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Row(
            children: [
              if (icon != null) ...[
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(borderRadius / 2),
                  ),
                  child: Icon(
                    icon,
                    color: iconColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        subtitle!,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (trailing != null) ...[
                const SizedBox(width: 16),
                trailing!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
