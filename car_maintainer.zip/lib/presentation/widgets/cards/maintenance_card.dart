import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/constants/colors.dart';
import '../../../data/models/maintenance_model.dart';

class MaintenanceCard extends StatelessWidget {
  final MaintenanceModel maintenance;
  final VoidCallback onTap;
  final VoidCallback? onDelete;

  const MaintenanceCard({
    Key? key,
    required this.maintenance,
    required this.onTap,
    this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final numberFormatter = NumberFormat('#,###', 'ru');
    final dateFormatter = DateFormat('dd.MM.yyyy');

    // Выбираем цвет в зависимости от типа обслуживания
    Color categoryColor;
    IconData categoryIcon;

    switch (maintenance.type) {
      case 'Замена масла':
        categoryColor = AppColors.engineCategory;
        categoryIcon = Icons.opacity;
        break;
      case 'Замена фильтров':
        categoryColor = AppColors.fuelCategory;
        categoryIcon = Icons.filter_alt_outlined;
        break;
      case 'Замена тормозных колодок':
        categoryColor = AppColors.brakeCategory;
        categoryIcon = Icons.brake_alert;
        break;
      case 'Замена ремня ГРМ':
        categoryColor = AppColors.engineCategory;
        categoryIcon = Icons.settings;
        break;
      case 'Замена шин':
        categoryColor = AppColors.tiresCategory;
        categoryIcon = Icons.tire_repair;
        break;
      case 'Диагностика':
        categoryColor = AppColors.electricalCategory;
        categoryIcon = Icons.cable;
        break;
      case 'Техническое обслуживание':
        categoryColor = AppColors.regularCategory;
        categoryIcon = Icons.build_outlined;
        break;
      default:
        categoryColor = AppColors.grey;
        categoryIcon = Icons.build_outlined;
    }

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Верхняя часть с типом и датой
              Row(
                children: [
                  // Иконка типа обслуживания
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: categoryColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      categoryIcon,
                      color: categoryColor,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Тип обслуживания
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          maintenance.type,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          dateFormatter.format(maintenance.date),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Кнопка удаления, если предоставлена
                  if (onDelete != null)
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: AppColors.error),
                      onPressed: onDelete,
                      tooltip: 'Удалить',
                    ),
                ],
              ),

              const Divider(height: 24),

              // Нижняя часть с дополнительной информацией
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Пробег
                  _buildInfoItem(
                    context,
                    Icons.speed_outlined,
                    '${numberFormatter.format(maintenance.mileage)} км',
                  ),

                  // Стоимость (если указана)
                  if (maintenance.cost != null)
                    _buildInfoItem(
                      context,
                      Icons.attach_money,
                      '${maintenance.cost!.toStringAsFixed(0)} ₽',
                    ),

                  // Сервисный центр (если указан)
                  if (maintenance.serviceCenter != null)
                    _buildInfoItem(
                      context,
                      Icons.store,
                      maintenance.serviceCenter!,
                      maxWidth: 120,
                    ),

                  // Напоминание (если установлено)
                  if (maintenance.reminderDate != null)
                    _buildInfoItem(
                      context,
                      Icons.notification_important_outlined,
                      dateFormatter.format(maintenance.reminderDate!),
                    ),
                ],
              ),

              // Дополнительные заметки (если есть)
              if (maintenance.notes != null && maintenance.notes!.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(
                  maintenance.notes!,
                  style: theme.textTheme.bodyMedium,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // Вспомогательный метод для создания элемента информации
  Widget _buildInfoItem(
    BuildContext context,
    IconData icon,
    String text, {
    double maxWidth = 100,
  }) {
    final theme = Theme.of(context);

    return Container(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 16,
            color: theme.textTheme.bodyMedium?.color?.withOpacity(0.6),
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              text,
              style: theme.textTheme.bodyMedium,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
