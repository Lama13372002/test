import 'package:flutter/material.dart';

import '../../../core/constants/colors.dart';

enum AppButtonType {
  primary,
  secondary,
  outlined,
  text,
  danger,
}

class AppButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final AppButtonType type;
  final IconData? icon;
  final bool isLoading;
  final bool isFullWidth;
  final bool isDisabled;
  final double? width;
  final double? height;
  final EdgeInsets? padding;
  final double borderRadius;

  const AppButton({
    Key? key,
    required this.text,
    required this.onPressed,
    this.type = AppButtonType.primary,
    this.icon,
    this.isLoading = false,
    this.isFullWidth = false,
    this.isDisabled = false,
    this.width,
    this.height,
    this.padding,
    this.borderRadius = 12.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    Color backgroundColor;
    Color textColor;
    Color borderColor;

    // Настраиваем цвета в зависимости от типа кнопки
    switch (type) {
      case AppButtonType.primary:
        backgroundColor = AppColors.primary;
        textColor = Colors.white;
        borderColor = Colors.transparent;
        break;

      case AppButtonType.secondary:
        backgroundColor = AppColors.secondary;
        textColor = Colors.white;
        borderColor = Colors.transparent;
        break;

      case AppButtonType.outlined:
        backgroundColor = Colors.transparent;
        textColor = AppColors.primary;
        borderColor = AppColors.primary;
        break;

      case AppButtonType.text:
        backgroundColor = Colors.transparent;
        textColor = AppColors.primary;
        borderColor = Colors.transparent;
        break;

      case AppButtonType.danger:
        backgroundColor = AppColors.error;
        textColor = Colors.white;
        borderColor = Colors.transparent;
        break;
    }

    // Если кнопка отключена, осветляем цвета
    if (isDisabled) {
      backgroundColor = backgroundColor.withOpacity(0.5);
      textColor = textColor.withOpacity(0.7);
      borderColor = borderColor.withOpacity(0.5);
    }

    // Общий стиль
    final ButtonStyle buttonStyle = ButtonStyle(
      backgroundColor: MaterialStateProperty.all(backgroundColor),
      foregroundColor: MaterialStateProperty.all(textColor),
      overlayColor: MaterialStateProperty.resolveWith<Color>(
        (Set<MaterialState> states) {
          if (states.contains(MaterialState.pressed)) {
            return textColor.withOpacity(0.1);
          }
          return Colors.transparent;
        },
      ),
      side: MaterialStateProperty.all(
        BorderSide(
          color: borderColor,
          width: type == AppButtonType.outlined ? 1.0 : 0.0,
        ),
      ),
      padding: MaterialStateProperty.all(
        padding ??
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      ),
      shape: MaterialStateProperty.all(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
        ),
      ),
      minimumSize: MaterialStateProperty.all(
        Size(width ?? (isFullWidth ? double.infinity : 0), height ?? 0),
      ),
      elevation: MaterialStateProperty.all(
        type == AppButtonType.text || type == AppButtonType.outlined ? 0 : 0,
      ),
    );

    // Создаем содержимое кнопки
    Widget content = Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (isLoading)
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(textColor),
              ),
            ),
          )
        else if (icon != null)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Icon(icon, size: 18),
          ),
        Flexible(
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: theme.textTheme.labelLarge?.copyWith(
              color: textColor,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );

    // Оборачиваем в контейнер, если кнопка должна быть полной ширины
    if (isFullWidth) {
      content = Container(
        width: double.infinity,
        alignment: Alignment.center,
        child: content,
      );
    }

    // Возвращаем соответствующий тип кнопки
    return ElevatedButton(
      onPressed: isDisabled || isLoading ? null : onPressed,
      style: buttonStyle,
      child: content,
    );
  }
}
