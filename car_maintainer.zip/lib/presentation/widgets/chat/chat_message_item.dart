import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/constants/colors.dart';
import '../../../data/models/chat_message_model.dart';

class ChatMessageItem extends StatelessWidget {
  final ChatMessageModel message;

  const ChatMessageItem({
    Key? key,
    required this.message,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isUserMessage = message.sender == MessageSender.user;
    final isSystemMessage = message.sender == MessageSender.system;

    // Определяем фон и цвет для сообщения
    Color backgroundColor;
    Color textColor;
    CrossAxisAlignment alignment;

    if (isSystemMessage) {
      backgroundColor = theme.brightness == Brightness.dark
          ? Colors.grey.shade800
          : Colors.grey.shade200;
      textColor = theme.textTheme.bodyMedium!.color!;
      alignment = CrossAxisAlignment.center;
    } else if (isUserMessage) {
      backgroundColor = AppColors.primary;
      textColor = Colors.white;
      alignment = CrossAxisAlignment.end;
    } else {
      backgroundColor = theme.brightness == Brightness.dark
          ? Colors.grey.shade800
          : Colors.grey.shade200;
      textColor = theme.textTheme.bodyMedium!.color!;
      alignment = CrossAxisAlignment.start;
    }

    // Форматирование времени
    final timeFormat = DateFormat('HH:mm');
    final timeString = timeFormat.format(message.timestamp);

    // Отображаем системные сообщения по-особому
    if (isSystemMessage) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: backgroundColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  message.text,
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontStyle: FontStyle.italic,
                    color: textColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    // Основной контейнер сообщения
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Column(
        crossAxisAlignment: alignment,
        children: [
          // Аватар и имя отправителя (для сообщений от бота)
          if (!isUserMessage)
            Row(
              children: [
                const CircleAvatar(
                  radius: 16,
                  backgroundColor: AppColors.primary,
                  child: Icon(
                    Icons.build,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Автомеханик',
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

          // Сообщение с текстом
          Container(
            margin: EdgeInsets.only(
              top: !isUserMessage ? 4 : 0,
              right: isUserMessage ? 0 : 48,
              left: isUserMessage ? 48 : 0,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(16).copyWith(
                bottomRight: isUserMessage ? const Radius.circular(4) : null,
                bottomLeft: !isUserMessage ? const Radius.circular(4) : null,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Текст сообщения
                Text(
                  message.text,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: textColor,
                  ),
                ),

                // Время отправки
                Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      timeString,
                      style: theme.textTheme.bodySmall?.copyWith(
                        fontSize: 10,
                        color: isUserMessage
                            ? Colors.white.withOpacity(0.7)
                            : textColor.withOpacity(0.7),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
