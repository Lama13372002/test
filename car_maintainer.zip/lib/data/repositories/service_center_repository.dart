import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:uuid/uuid.dart';

import '../models/service_center_model.dart';
import '../../core/constants/app_constants.dart';

class ServiceCenterRepository {
  // Demo data
  final List<ServiceCenterModel> _demoServiceCenters = [
    ServiceCenterModel(
      id: '1',
      name: 'Автосервис "Мастер"',
      address: 'ул. Ленина, 123',
      latitude: 55.7558,
      longitude: 37.6173,
      type: 'Сервисный центр',
      phone: '+7 (999) 123-45-67',
      website: 'https://autoservice-master.ru',
      rating: 4.7,
      services: [
        'Замена масла',
        'Диагностика',
        'Ремонт двигателя',
        'Ремонт подвески',
        'Шиномонтаж',
      ],
    ),
    ServiceCenterModel(
      id: '2',
      name: 'Официальный дилер Toyota',
      address: 'ул. Автомобильная, 45',
      latitude: 55.7512,
      longitude: 37.6184,
      type: 'Официальный дилер',
      phone: '+7 (495) 987-65-43',
      website: 'https://toyota-dealer.ru',
      rating: 4.9,
      services: [
        'Техническое обслуживание',
        'Гарантийный ремонт',
        'Диагностика',
        'Ремонт АКПП',
        'Продажа запчастей',
      ],
    ),
    ServiceCenterModel(
      id: '3',
      name: 'Шиномонтаж "Колесо"',
      address: 'пр. Мира, 78',
      latitude: 55.7601,
      longitude: 37.6125,
      type: 'Шиномонтаж',
      phone: '+7 (999) 555-44-33',
      rating: 4.5,
      services: [
        'Шиномонтаж',
        'Балансировка',
        'Ремонт шин',
        'Продажа шин',
      ],
    ),
    ServiceCenterModel(
      id: '4',
      name: 'АвтоМойка 24/7',
      address: 'ул. Гагарина, 15',
      latitude: 55.7532,
      longitude: 37.6211,
      type: 'Автомойка',
      phone: '+7 (999) 777-88-99',
      rating: 4.3,
      services: [
        'Мойка кузова',
        'Химчистка салона',
        'Полировка',
      ],
    ),
    ServiceCenterModel(
      id: '5',
      name: 'Автосервис "Гараж"',
      address: 'ул. Профсоюзная, 25',
      latitude: 55.7499,
      longitude: 37.6261,
      type: 'Сервисный центр',
      phone: '+7 (999) 222-33-44',
      rating: 4.2,
      services: [
        'Ремонт двигателя',
        'Ремонт трансмиссии',
        'Диагностика',
        'Ремонт электрики',
      ],
    ),
  ];

  // Получение списка сервисных центров
  Future<List<ServiceCenterModel>> getServiceCenters() async {
    // В реальном приложении здесь будет API-запрос

    // Вычисляем расстояние до каждого сервиса от текущего местоположения
    final position = await _determinePosition();

    final serviceCenters = _demoServiceCenters.map((center) {
      final distance = Geolocator.distanceBetween(
        position.latitude,
        position.longitude,
        center.latitude,
        center.longitude,
      );

      // Добавляем расстояние (в километрах)
      return center.copyWith(
        distance: distance / 1000,
      );
    }).toList();

    // Сортируем по расстоянию
    serviceCenters.sort((a, b) => a.distance!.compareTo(b.distance!));

    return serviceCenters;
  }

  // Получение сервисного центра по ID
  Future<ServiceCenterModel?> getServiceCenterById(String id) async {
    final serviceCenters = await getServiceCenters();
    return serviceCenters.firstWhere((center) => center.id == id);
  }

  // Поиск сервисных центров по типу
  Future<List<ServiceCenterModel>> searchServiceCentersByType(String type) async {
    final serviceCenters = await getServiceCenters();
    return serviceCenters.where((center) => center.type == type).toList();
  }

  // Поиск сервисных центров по названию
  Future<List<ServiceCenterModel>> searchServiceCentersByName(String query) async {
    final serviceCenters = await getServiceCenters();
    return serviceCenters
        .where(
          (center) => center.name.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
  }

  // Поиск ближайших сервисных центров
  Future<List<ServiceCenterModel>> getNearbyServiceCenters(
    double maxDistance, // в километрах
  ) async {
    final serviceCenters = await getServiceCenters();
    return serviceCenters
        .where((center) => center.distance != null && center.distance! <= maxDistance)
        .toList();
  }

  // Добавление отзыва к сервисному центру
  Future<void> addReview(
    String serviceCenterId,
    String authorName,
    double rating,
    String text,
  ) async {
    // В реальном приложении здесь будет API-запрос

    final review = ReviewModel(
      id: const Uuid().v4(),
      authorName: authorName,
      rating: rating,
      text: text,
      date: DateTime.now(),
    );

    // Находим сервисный центр
    final index = _demoServiceCenters.indexWhere((c) => c.id == serviceCenterId);

    if (index != -1) {
      // Клонируем текущие отзывы
      final currentReviews = _demoServiceCenters[index].reviews ?? [];
      final updatedReviews = List<ReviewModel>.from(currentReviews)..add(review);

      // Обновляем рейтинг
      final newRating = updatedReviews.fold<double>(
        0,
        (sum, review) => sum + review.rating,
      ) / updatedReviews.length;

      // Обновляем сервисный центр
      _demoServiceCenters[index] = _demoServiceCenters[index].copyWith(
        reviews: updatedReviews,
        rating: newRating,
      );
    }
  }

  // Определение текущего местоположения
  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Проверяем, включены ли службы геолокации
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Службы геолокации отключены');
    }

    // Проверяем разрешения
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Разрешения на геолокацию отклонены');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
        'Разрешения на геолокацию отклонены навсегда, мы не можем запросить разрешения',
      );
    }

    // Получаем текущее местоположение
    try {
      return await Geolocator.getCurrentPosition();
    } catch (e) {
      // В случае ошибки возвращаем центр Москвы
      return Position(
        latitude: 55.7558,
        longitude: 37.6173,
        timestamp: DateTime.now(),
        accuracy: 0,
        altitude: 0,
        heading: 0,
        speed: 0,
        speedAccuracy: 0,
      );
    }
  }

  // Загрузка сервисных центров из API
  Future<List<ServiceCenterModel>> fetchServiceCentersFromApi() async {
    // Это демо-метод для будущей реализации API
    // В реальном приложении здесь будет запрос на сервер

    try {
      final response = await http.get(
        Uri.parse('${AppConstants.baseUrl}/service-centers'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = json.decode(response.body);
        return jsonData
            .map((json) => ServiceCenterModel.fromJson(json))
            .toList();
      } else {
        return _demoServiceCenters;
      }
    } catch (e) {
      return _demoServiceCenters;
    }
  }
}
