import '../../core/services/storage_service.dart';
import '../models/vehicle_model.dart';
import '../models/maintenance_model.dart';

class VehicleRepository {
  final StorageService _storageService;

  VehicleRepository(this._storageService);

  // Получение всех автомобилей
  List<VehicleModel> getVehicles() {
    return _storageService.getVehicles();
  }

  // Получение автомобиля по ID
  VehicleModel? getVehicleById(String id) {
    return _storageService.getVehicleById(id);
  }

  // Добавление автомобиля
  Future<void> addVehicle(VehicleModel vehicle) async {
    await _storageService.addVehicle(vehicle);
  }

  // Обновление автомобиля
  Future<void> updateVehicle(VehicleModel vehicle) async {
    await _storageService.updateVehicle(vehicle);
  }

  // Удаление автомобиля
  Future<void> deleteVehicle(String id) async {
    await _storageService.deleteVehicle(id);
  }

  // Обновление пробега автомобиля
  Future<void> updateMileage(String id, int newMileage) async {
    final vehicle = _storageService.getVehicleById(id);
    if (vehicle != null) {
      await _storageService.updateVehicle(
        vehicle.copyWith(
          mileage: newMileage,
          updatedAt: DateTime.now(),
        ),
      );
    }
  }

  // Получение истории обслуживания автомобиля
  List<MaintenanceModel> getMaintenanceHistory(String vehicleId) {
    return _storageService.getMaintenanceByVehicleId(vehicleId);
  }

  // Получение ближайших обслуживаний для всех автомобилей
  List<MaintenanceModel> getUpcomingMaintenance() {
    final vehicles = _storageService.getVehicles();
    final upcomingMaintenance = <MaintenanceModel>[];

    for (final vehicle in vehicles) {
      final maintenanceList = _storageService.getMaintenanceByVehicleId(vehicle.id);

      // Фильтруем техобслуживания с напоминаниями
      final withReminders = maintenanceList.where((m) =>
          m.reminderDate != null || m.reminderMileage != null);

      upcomingMaintenance.addAll(withReminders);
    }

    // Сортируем по дате (от ближайших к дальним)
    upcomingMaintenance.sort((a, b) {
      // Если есть дата напоминания, сортируем по ней
      if (a.reminderDate != null && b.reminderDate != null) {
        return a.reminderDate!.compareTo(b.reminderDate!);
      }

      // Если у одного есть дата, а у другого нет
      if (a.reminderDate != null) return -1;
      if (b.reminderDate != null) return 1;

      // Если нет дат, сортируем по пробегу
      if (a.reminderMileage != null && b.reminderMileage != null) {
        return a.reminderMileage!.compareTo(b.reminderMileage!);
      }

      // По умолчанию не меняем порядок
      return 0;
    });

    return upcomingMaintenance;
  }

  // Получение автомобилей, требующих обслуживания
  List<VehicleModel> getVehiclesNeedingService() {
    final now = DateTime.now();
    final thresholdDate = now.add(const Duration(days: 30)); // Ближайшие 30 дней
    final vehicles = _storageService.getVehicles();
    final result = <VehicleModel>[];

    for (final vehicle in vehicles) {
      // Проверяем по последней дате обслуживания
      if (vehicle.lastServiceDate != null) {
        final nextServiceDate = vehicle.lastServiceDate!.add(
          const Duration(days: 365), // Примерно раз в год
        );

        if (nextServiceDate.isBefore(thresholdDate)) {
          result.add(vehicle);
          continue;
        }
      }

      // Проверяем по пробегу
      final nextServiceMileage = vehicle.nextServiceMileage;
      if (nextServiceMileage - vehicle.mileage < 1000) { // Меньше 1000 км до следующего ТО
        result.add(vehicle);
      }
    }

    return result;
  }
}
