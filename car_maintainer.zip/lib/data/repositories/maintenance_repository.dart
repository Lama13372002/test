import '../../core/services/storage_service.dart';
import '../../core/services/notification_service.dart';
import '../models/maintenance_model.dart';
import '../models/notification_model.dart';
import '../models/vehicle_model.dart';

class MaintenanceRepository {
  final StorageService _storageService;
  final NotificationService _notificationService;

  MaintenanceRepository(this._storageService, this._notificationService);

  // Получение истории обслуживания по ID автомобиля
  List<MaintenanceModel> getMaintenanceHistory(String vehicleId) {
    return _storageService.getMaintenanceByVehicleId(vehicleId);
  }

  // Добавление записи об обслуживании
  Future<void> addMaintenance(MaintenanceModel maintenance) async {
    await _storageService.addMaintenance(maintenance);

    // Создаем напоминание, если указана дата или пробег
    if (maintenance.reminderDate != null || maintenance.reminderMileage != null) {
      await _createReminderNotification(maintenance);
    }
  }

  // Обновление записи об обслуживании
  Future<void> updateMaintenance(MaintenanceModel maintenance) async {
    await _storageService.updateMaintenance(maintenance);

    // Обновляем или удаляем напоминания
    final notifications = _storageService.getNotifications();
    final relatedNotifications = notifications.where(
      (n) => n.id.contains(maintenance.id),
    ).toList();

    // Удаляем старые напоминания
    for (final notification in relatedNotifications) {
      await _storageService.deleteNotification(notification.id);
      if (notification.notificationId != null) {
        await _notificationService.cancelNotification(notification.notificationId!);
      }
    }

    // Создаем новое напоминание, если указана дата или пробег
    if (maintenance.reminderDate != null || maintenance.reminderMileage != null) {
      await _createReminderNotification(maintenance);
    }
  }

  // Удаление записи об обслуживании
  Future<void> deleteMaintenance(String id) async {
    await _storageService.deleteMaintenance(id);

    // Удаляем связанные напоминания
    final notifications = _storageService.getNotifications();
    final relatedNotifications = notifications.where(
      (n) => n.id.contains(id),
    ).toList();

    for (final notification in relatedNotifications) {
      await _storageService.deleteNotification(notification.id);
      if (notification.notificationId != null) {
        await _notificationService.cancelNotification(notification.notificationId!);
      }
    }
  }

  // Создание напоминания
  Future<void> _createReminderNotification(MaintenanceModel maintenance) async {
    final vehicle = _storageService.getVehicleById(maintenance.vehicleId);

    if (vehicle == null) return;

    // Если указана дата напоминания
    if (maintenance.reminderDate != null) {
      await _createDateBasedReminder(maintenance, vehicle);
    }

    // Если указан пробег для напоминания
    if (maintenance.reminderMileage != null) {
      await _createMileageBasedReminder(maintenance, vehicle);
    }
  }

  // Создание напоминания по дате
  Future<void> _createDateBasedReminder(
    MaintenanceModel maintenance,
    VehicleModel vehicle,
  ) async {
    // Создаем уведомление
    final notification = NotificationModel.create(
      vehicleId: vehicle.id,
      vehicleName: vehicle.fullName,
      type: maintenance.type == 'Замена масла' ? 'oil_change' : 'general',
      title: 'Напоминание о ТО',
      body: 'Запланировано ${maintenance.type} для ${vehicle.fullName}',
      scheduledDate: maintenance.reminderDate!,
    );

    // Планируем системное уведомление
    final notificationId = await _notificationService.scheduleMaintenanceReminder(notification);

    // Сохраняем уведомление с присвоенным ID
    final updatedNotification = notification.copyWith(
      id: '${maintenance.id}_date',
      notificationId: notificationId,
    );

    await _storageService.addNotification(updatedNotification);
  }

  // Создание напоминания по пробегу
  Future<void> _createMileageBasedReminder(
    MaintenanceModel maintenance,
    VehicleModel vehicle,
  ) async {
    // Вычисляем приблизительную дату достижения указанного пробега
    final mileageDifference = maintenance.reminderMileage! - vehicle.mileage;
    final daysToMileage = _estimateDaysToMileage(mileageDifference);
    final estimatedDate = DateTime.now().add(Duration(days: daysToMileage));

    // Создаем уведомление
    final notification = NotificationModel.create(
      vehicleId: vehicle.id,
      vehicleName: vehicle.fullName,
      type: 'mileage',
      title: 'Напоминание о пробеге',
      body: 'Приближается пробег ${maintenance.reminderMileage} км для ${vehicle.fullName}',
      scheduledDate: estimatedDate,
      scheduledMileage: maintenance.reminderMileage,
    );

    // Планируем системное уведомление
    final notificationId = await _notificationService.scheduleMaintenanceReminder(notification);

    // Сохраняем уведомление с присвоенным ID
    final updatedNotification = notification.copyWith(
      id: '${maintenance.id}_mileage',
      notificationId: notificationId,
    );

    await _storageService.addNotification(updatedNotification);
  }

  // Оценка количества дней до достижения указанного пробега
  // Предполагаем средний пробег 30 км в день
  int _estimateDaysToMileage(int mileageDifference) {
    const averageDailyMileage = 30;
    return (mileageDifference / averageDailyMileage).ceil();
  }

  // Обновление планируемых напоминаний по пробегу при обновлении пробега автомобиля
  Future<void> checkMileageNotifications(String vehicleId, int newMileage) async {
    final notifications = _storageService.getVehicleNotifications(vehicleId);
    final mileageNotifications = notifications.where((n) =>
        n.scheduledMileage != null &&
        n.type == 'mileage' &&
        n.scheduledMileage! <= newMileage);

    for (final notification in mileageNotifications) {
      // Показываем уведомление
      await _notificationService.showNotification(
        title: notification.title,
        body: notification.body,
        payload: 'vehicle_$vehicleId',
      );

      // Удаляем запланированное уведомление
      if (notification.notificationId != null) {
        await _notificationService.cancelNotification(notification.notificationId!);
      }

      // Отмечаем как прочитанное и сохраняем
      final updatedNotification = notification.markAsRead();
      await _storageService.updateNotification(updatedNotification);
    }
  }
}
