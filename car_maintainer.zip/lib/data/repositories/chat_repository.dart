import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/chat_message_model.dart';
import '../../core/constants/app_constants.dart';
import '../../core/constants/text_constants.dart';

class ChatRepository {
  // Ключ для хранения истории чата
  static const String _chatHistoryKey = 'chat_history';

  // Получение истории чата
  Future<ChatConversationModel> getChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final chatJson = prefs.getString(_chatHistoryKey);

    if (chatJson != null) {
      final jsonMap = json.decode(chatJson) as Map<String, dynamic>;
      return ChatConversationModel.fromJson(jsonMap);
    } else {
      // Если истории нет, создаем новую беседу с приветственным сообщением
      final conversation = ChatConversationModel.create(
        title: 'Чат с автомехаником',
        messages: [
          ChatMessageModel.bot(AppTexts.chatWelcome),
        ],
      );

      // Сохраняем новую беседу
      await _saveChatHistory(conversation);

      return conversation;
    }
  }

  // Сохранение истории чата
  Future<void> _saveChatHistory(ChatConversationModel conversation) async {
    final prefs = await SharedPreferences.getInstance();
    final chatJson = json.encode(conversation.toJson());
    await prefs.setString(_chatHistoryKey, chatJson);
  }

  // Очистка истории чата
  Future<ChatConversationModel> clearChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_chatHistoryKey);

    // Создаем новую беседу с приветственным сообщением
    final conversation = ChatConversationModel.create(
      title: 'Чат с автомехаником',
      messages: [
        ChatMessageModel.bot(AppTexts.chatWelcome),
      ],
    );

    // Сохраняем новую беседу
    await _saveChatHistory(conversation);

    return conversation;
  }

  // Отправка сообщения и получение ответа от бота
  Future<ChatMessageModel> sendMessage(String text) async {
    // Получаем текущую беседу
    final conversation = await getChatHistory();

    // Создаем сообщение пользователя
    final userMessage = ChatMessageModel.user(text);

    // Добавляем сообщение пользователя в беседу
    final updatedConversation = conversation.addMessage(userMessage);
    await _saveChatHistory(updatedConversation);

    // Получаем ответ от бота
    final botResponse = await _getBotResponse(text, updatedConversation);

    // Добавляем ответ бота в беседу
    final finalConversation = updatedConversation.addMessage(botResponse);
    await _saveChatHistory(finalConversation);

    return botResponse;
  }

  // Получение ответа от бота
  Future<ChatMessageModel> _getBotResponse(
    String userMessage,
    ChatConversationModel conversation,
  ) async {
    // Пробуем получить ответ от API
    try {
      // Если используем API, то здесь будет запрос к внешнему сервису
      final response = await _getChatGptResponse(userMessage, conversation);
      return response;
    } catch (e) {
      // В случае ошибки используем предопределенные ответы
      return _getLocalBotResponse(userMessage);
    }
  }

  // Получение ответа от ChatGPT API
  Future<ChatMessageModel> _getChatGptResponse(
    String userMessage,
    ChatConversationModel conversation,
  ) async {
    try {
      // Подготавливаем историю сообщений для отправки на API
      final messages = conversation.messages.map((message) {
        final role = message.sender == MessageSender.user ? 'user' : 'assistant';
        return {
          'role': role,
          'content': message.text,
        };
      }).toList();

      // Добавляем системное сообщение в начало
      messages.insert(0, {
        'role': 'system',
        'content': 'Ты виртуальный автомеханик-консультант, который помогает пользователям '
            'с вопросами по обслуживанию и ремонту автомобилей. Давай точные и полезные советы, '
            'но напоминай пользователю, что для сложных проблем лучше обратиться к профессионалам.',
      });

      // Отправляем запрос на ChatGPT API
      final response = await http.post(
        Uri.parse('https://api.openai.com/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppConstants.chatGptApiKey}',
        },
        body: json.encode({
          'model': 'gpt-3.5-turbo',
          'messages': messages,
          'temperature': 0.7,
          'max_tokens': 500,
        }),
      );

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        final botResponseText = jsonResponse['choices'][0]['message']['content'];

        return ChatMessageModel.bot(botResponseText);
      } else {
        // В случае ошибки API возвращаем локальный ответ
        return _getLocalBotResponse(userMessage);
      }
    } catch (e) {
      // В случае сетевой ошибки также возвращаем локальный ответ
      return _getLocalBotResponse(userMessage);
    }
  }

  // Получение локального ответа (без использования API)
  ChatMessageModel _getLocalBotResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();

    // Проверяем ключевые слова в сообщении пользователя
    if (lowerMessage.contains('масл')) {
      return ChatMessageModel.bot(
        'Замена масла - одна из самых важных процедур обслуживания. '
        'Рекомендуется менять масло каждые 7000-10000 км пробега или раз в год. '
        'Используйте масло, рекомендованное производителем вашего автомобиля.',
      );
    } else if (lowerMessage.contains('тормоз')) {
      return ChatMessageModel.bot(
        'Тормозную систему необходимо регулярно проверять. Тормозные колодки обычно '
        'служат 30000-40000 км, а тормозную жидкость рекомендуется менять раз в 2 года. '
        'Если вы слышите скрип при торможении, возможно, колодки изношены.',
      );
    } else if (lowerMessage.contains('аккумулятор') || lowerMessage.contains('батаре')) {
      return ChatMessageModel.bot(
        'Средний срок службы аккумулятора - 3-5 лет. Если автомобиль плохо заводится, '
        'проверьте напряжение аккумулятора. В исправном состоянии оно должно быть около 12.6 В '
        'в покое и 13.7-14.7 В при работающем двигателе.',
      );
    } else if (lowerMessage.contains('шин') || lowerMessage.contains('резин')) {
      return ChatMessageModel.bot(
        'Шины рекомендуется менять каждые 40000-60000 км или когда глубина протектора '
        'достигает 1.6 мм. Не забывайте регулярно проверять давление в шинах и '
        'делать сезонную замену резины.',
      );
    } else if (lowerMessage.contains('привет') || lowerMessage.contains('здравст')) {
      return ChatMessageModel.bot(
        'Здравствуйте! Я виртуальный автомеханик. Чем могу помочь вам с вашим автомобилем?',
      );
    } else if (lowerMessage.contains('спасибо')) {
      return ChatMessageModel.bot(
        'Всегда рад помочь! Если у вас появятся ещё вопросы о вашем автомобиле, обращайтесь.',
      );
    } else {
      return ChatMessageModel.bot(
        'Спасибо за ваш вопрос. Для получения точной консультации по этой теме '
        'рекомендую обратиться к профессиональному механику. Вы также можете '
        'уточнить вопрос, и я постараюсь помочь вам лучше.',
      );
    }
  }
}
