import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/diagnostic_model.dart';
import '../../core/constants/app_constants.dart';

class DiagnosticRepository {
  // Кэш истории диагностики
  Future<List<DiagnosticQueryModel>> getDiagnosticHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyString = prefs.getStringList('diagnostic_history') ?? [];

    return historyString.map((jsonString) {
      final jsonMap = json.decode(jsonString) as Map<String, dynamic>;
      return DiagnosticQueryModel.fromJson(jsonMap);
    }).toList();
  }

  // Сохранение запроса диагностики в историю
  Future<void> saveDiagnosticQuery(DiagnosticQueryModel query) async {
    final prefs = await SharedPreferences.getInstance();
    final historyString = prefs.getStringList('diagnostic_history') ?? [];

    // Добавляем новый запрос в начало истории
    historyString.insert(0, json.encode(query.toJson()));

    // Ограничиваем историю до 20 последних запросов
    if (historyString.length > 20) {
      historyString.removeLast();
    }

    await prefs.setStringList('diagnostic_history', historyString);
  }

  // Очистка истории диагностики
  Future<void> clearDiagnosticHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('diagnostic_history');
  }

  // Запрос диагностики по симптомам
  Future<List<DiagnosticIssueModel>> diagnoseBySymptomsLocal(
    String category,
    String symptoms,
  ) async {
    // Это демо-реализация для локального анализа симптомов
    // В реальном приложении здесь будет запрос к API или более сложная логика

    final results = <DiagnosticIssueModel>[];

    // Двигатель
    if (category == 'Двигатель') {
      if (symptoms.contains('не заводится') ||
          symptoms.contains('плохо заводится')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Двигатель',
            symptom: 'Двигатель не заводится или плохо заводится',
            possibleCauses: [
              'Разряженный аккумулятор',
              'Неисправность стартера',
              'Проблемы с топливной системой',
              'Неисправность свечей зажигания',
            ],
            recommendedActions: [
              'Проверить заряд аккумулятора',
              'Проверить стартер',
              'Проверить топливный насос и давление топлива',
              'Заменить свечи зажигания',
            ],
            severityLevel: 4,
          ),
        );
      }

      if (symptoms.contains('перегрев') ||
          symptoms.contains('температура')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Двигатель',
            symptom: 'Перегрев двигателя',
            possibleCauses: [
              'Недостаток охлаждающей жидкости',
              'Неисправность термостата',
              'Неисправность вентилятора охлаждения',
              'Засорение радиатора',
            ],
            recommendedActions: [
              'Проверить уровень охлаждающей жидкости',
              'Проверить работу термостата',
              'Проверить работу вентилятора охлаждения',
              'Промыть систему охлаждения',
            ],
            severityLevel: 5,
          ),
        );
      }

      if (symptoms.contains('стук') ||
          symptoms.contains('шум') ||
          symptoms.contains('звук')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Двигатель',
            symptom: 'Посторонние шумы в двигателе',
            possibleCauses: [
              'Низкий уровень масла',
              'Износ подшипников',
              'Проблемы с клапанным механизмом',
              'Детонация',
            ],
            recommendedActions: [
              'Проверить уровень и качество масла',
              'Провести диагностику двигателя',
              'Проверить регулировку клапанов',
              'Использовать топливо с рекомендованным октановым числом',
            ],
            severityLevel: 4,
          ),
        );
      }
    }

    // Трансмиссия
    else if (category == 'Трансмиссия') {
      if (symptoms.contains('рывки') ||
          symptoms.contains('дёргается')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Трансмиссия',
            symptom: 'Рывки при переключении передач',
            possibleCauses: [
              'Низкий уровень трансмиссионной жидкости',
              'Износ сцепления',
              'Неисправность электроники АКПП',
              'Износ синхронизаторов МКПП',
            ],
            recommendedActions: [
              'Проверить уровень и качество трансмиссионной жидкости',
              'Диагностика сцепления',
              'Компьютерная диагностика АКПП',
              'Обратиться в специализированный сервис',
            ],
            severityLevel: 3,
          ),
        );
      }

      if (symptoms.contains('шум') ||
          symptoms.contains('гул')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Трансмиссия',
            symptom: 'Шум или гул от трансмиссии',
            possibleCauses: [
              'Износ подшипников',
              'Низкий уровень жидкости',
              'Износ зубчатых передач',
              'Проблемы с дифференциалом',
            ],
            recommendedActions: [
              'Проверить уровень жидкости',
              'Диагностика трансмиссии в сервисе',
              'Замена изношенных компонентов',
            ],
            severityLevel: 3,
          ),
        );
      }
    }

    // Подвеска
    else if (category == 'Подвеска') {
      if (symptoms.contains('стук') ||
          symptoms.contains('грохот')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Подвеска',
            symptom: 'Стук в подвеске',
            possibleCauses: [
              'Износ шаровых опор',
              'Износ стоек стабилизатора',
              'Износ амортизаторов',
              'Ослабление креплений элементов подвески',
            ],
            recommendedActions: [
              'Проверить состояние шаровых опор и стоек стабилизатора',
              'Проверить амортизаторы',
              'Проверить затяжку всех болтов подвески',
            ],
            severityLevel: 3,
          ),
        );
      }
    }

    // Тормоза
    else if (category == 'Тормоза') {
      if (symptoms.contains('скрип') ||
          symptoms.contains('визг')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Тормоза',
            symptom: 'Скрип при торможении',
            possibleCauses: [
              'Износ тормозных колодок',
              'Износ тормозных дисков',
              'Загрязнение тормозных механизмов',
            ],
            recommendedActions: [
              'Проверить состояние тормозных колодок',
              'Проверить состояние тормозных дисков',
              'Очистить тормозные механизмы',
            ],
            severityLevel: 3,
          ),
        );
      }

      if (symptoms.contains('мягкая педаль') ||
          symptoms.contains('проваливается')) {
        results.add(
          DiagnosticIssueModel.create(
            category: 'Тормоза',
            symptom: 'Мягкая педаль тормоза',
            possibleCauses: [
              'Воздух в тормозной системе',
              'Утечка тормозной жидкости',
              'Неисправность главного тормозного цилиндра',
            ],
            recommendedActions: [
              'Проверить уровень тормозной жидкости',
              'Проверить систему на утечки',
              'Прокачать тормозную систему',
              'Проверить главный тормозной цилиндр',
            ],
            severityLevel: 5,
          ),
        );
      }
    }

    // Если нет совпадений, возвращаем общий ответ
    if (results.isEmpty) {
      results.add(
        DiagnosticIssueModel.create(
          category: category,
          symptom: 'Неопределенная проблема',
          possibleCauses: [
            'Требуется детальная диагностика',
          ],
          recommendedActions: [
            'Обратитесь в сервисный центр для профессиональной диагностики',
            'Используйте чат с экспертом для получения более точной консультации',
          ],
          severityLevel: 3,
        ),
      );
    }

    return results;
  }

  // Запрос диагностики через API (для будущей реализации)
  Future<List<DiagnosticIssueModel>> diagnoseBySymptomsApi(
    String category,
    String symptoms,
  ) async {
    try {
      final response = await http.post(
        Uri.parse('${AppConstants.baseUrl}/diagnostics'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'category': category,
          'symptoms': symptoms,
        }),
      );

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = json.decode(response.body);
        return jsonData
            .map((json) => DiagnosticIssueModel.fromJson(json))
            .toList();
      } else {
        // Если API недоступен, используем локальную диагностику
        return diagnoseBySymptomsLocal(category, symptoms);
      }
    } catch (e) {
      // В случае ошибки используем локальную диагностику
      return diagnoseBySymptomsLocal(category, symptoms);
    }
  }

  // Получение распространенных проблем по категории
  List<String> getCommonProblems(String category) {
    switch (category) {
      case 'Двигатель':
        return [
          'Не заводится',
          'Плохо заводится',
          'Троит',
          'Потеря мощности',
          'Перегрев',
          'Повышенный расход топлива',
          'Стук в двигателе',
          'Дым из выхлопной трубы',
        ];
      case 'Трансмиссия':
        return [
          'Рывки при переключении передач',
          'Шум при работе',
          'Пробуксовка',
          'Не включается передача',
          'Течь масла',
          'Гул при движении',
        ];
      case 'Подвеска':
        return [
          'Стук при проезде неровностей',
          'Скрип при повороте руля',
          'Увод в сторону',
          'Неравномерный износ шин',
          'Раскачивание после проезда неровностей',
        ];
      case 'Электрика':
        return [
          'Не работают приборы',
          'Разряжается аккумулятор',
          'Не работает стартер',
          'Не заряжается аккумулятор',
          'Перегорают предохранители',
          'Проблемы с освещением',
        ];
      case 'Тормоза':
        return [
          'Скрип при торможении',
          'Увод при торможении',
          'Мягкая педаль',
          'Вибрация при торможении',
          'Долгий тормозной путь',
        ];
      default:
        return [
          'Необычный шум',
          'Вибрация',
          'Утечка жидкости',
          'Необычный запах',
          'Проблемы с управлением',
        ];
    }
  }
}
