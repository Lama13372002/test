import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../../core/services/storage_service.dart';
import '../models/user_model.dart';
import '../../core/constants/app_constants.dart';

class AuthRepository {
  final StorageService _storageService;

  AuthRepository(this._storageService);

  // Проверка, авторизован ли пользователь
  bool isAuthenticated() {
    final user = _storageService.getUser();
    final token = _storageService.getToken();

    return user != null && token != null;
  }

  // Получение текущего пользователя
  UserModel? getCurrentUser() {
    return _storageService.getUser();
  }

  // Регистрация пользователя
  Future<UserModel> register({
    required String name,
    required String email,
    required String password,
  }) async {
    // В реальном приложении здесь будет запрос к API

    try {
      final response = await http.post(
        Uri.parse('${AppConstants.baseUrl}/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 201) {
        final jsonData = json.decode(response.body);
        final user = UserModel.fromJson(jsonData['user']);
        final token = jsonData['token'];

        // Сохраняем данные пользователя и токен
        await _storageService.setUser(user);
        await _storageService.setToken(token);

        return user;
      } else {
        // В случае ошибки API, создаем локального пользователя
        return _createLocalUser(name, email);
      }
    } catch (e) {
      // В случае сетевой ошибки, создаем локального пользователя
      return _createLocalUser(name, email);
    }
  }

  // Вход пользователя
  Future<UserModel> login({
    required String email,
    required String password,
  }) async {
    // В реальном приложении здесь будет запрос к API

    try {
      final response = await http.post(
        Uri.parse('${AppConstants.baseUrl}/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final user = UserModel.fromJson(jsonData['user']);
        final token = jsonData['token'];

        // Сохраняем данные пользователя и токен
        await _storageService.setUser(user);
        await _storageService.setToken(token);

        return user;
      } else {
        // В случае ошибки API, создаем локального пользователя
        return _createLocalUser('Пользователь', email);
      }
    } catch (e) {
      // В случае сетевой ошибки, создаем локального пользователя
      return _createLocalUser('Пользователь', email);
    }
  }

  // Выход пользователя
  Future<void> logout() async {
    await _storageService.clearUser();
  }

  // Обновление профиля пользователя
  Future<UserModel> updateProfile({
    required String name,
    String? photoUrl,
  }) async {
    final currentUser = _storageService.getUser();

    if (currentUser == null) {
      throw Exception('Пользователь не авторизован');
    }

    // В реальном приложении здесь будет запрос к API

    try {
      final token = _storageService.getToken();

      final response = await http.put(
        Uri.parse('${AppConstants.baseUrl}/users/${currentUser.id}'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode({
          'name': name,
          'photoUrl': photoUrl,
        }),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final updatedUser = UserModel.fromJson(jsonData);

        // Сохраняем обновленные данные пользователя
        await _storageService.setUser(updatedUser);

        return updatedUser;
      } else {
        // В случае ошибки API, обновляем локального пользователя
        final updatedUser = currentUser.copyWith(
          name: name,
          photoUrl: photoUrl,
          updatedAt: DateTime.now(),
        );

        await _storageService.setUser(updatedUser);

        return updatedUser;
      }
    } catch (e) {
      // В случае сетевой ошибки, обновляем локального пользователя
      final updatedUser = currentUser.copyWith(
        name: name,
        photoUrl: photoUrl,
        updatedAt: DateTime.now(),
      );

      await _storageService.setUser(updatedUser);

      return updatedUser;
    }
  }

  // Создание локального пользователя (для демо)
  Future<UserModel> _createLocalUser(String name, String email) async {
    final now = DateTime.now();

    final user = UserModel(
      id: const Uuid().v4(),
      name: name,
      email: email,
      createdAt: now,
      updatedAt: now,
    );

    final token = 'demo_token_${const Uuid().v4()}';

    // Сохраняем данные пользователя и токен
    await _storageService.setUser(user);
    await _storageService.setToken(token);

    return user;
  }

  // Вход без авторизации (гостевой режим)
  Future<UserModel> continueWithoutAccount() async {
    final now = DateTime.now();

    final user = UserModel(
      id: const Uuid().v4(),
      name: 'Гость',
      email: 'guest@autodoc.app',
      createdAt: now,
      updatedAt: now,
    );

    final token = 'guest_token_${const Uuid().v4()}';

    // Сохраняем данные пользователя и токен
    await _storageService.setUser(user);
    await _storageService.setToken(token);

    return user;
  }
}
