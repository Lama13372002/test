import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

class VehicleModel extends Equatable {
  final String id;
  final String brand;
  final String model;
  final int year;
  final int mileage;
  final String? licensePlate;
  final String? vin;
  final String? color;
  final DateTime? lastServiceDate;
  final String? fuelType;
  final String? transmission;
  final String? engineVolume;
  final String? driveType;
  final String? notes;
  final String? imageUrl;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const VehicleModel({
    required this.id,
    required this.brand,
    required this.model,
    required this.year,
    required this.mileage,
    this.licensePlate,
    this.vin,
    this.color,
    this.lastServiceDate,
    this.fuelType,
    this.transmission,
    this.engineVolume,
    this.driveType,
    this.notes,
    this.imageUrl,
    this.createdAt,
    this.updatedAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory VehicleModel.create({
    required String brand,
    required String model,
    required int year,
    required int mileage,
    String? licensePlate,
    String? vin,
    String? color,
    DateTime? lastServiceDate,
    String? fuelType,
    String? transmission,
    String? engineVolume,
    String? driveType,
    String? notes,
    String? imageUrl,
  }) {
    final now = DateTime.now();
    return VehicleModel(
      id: const Uuid().v4(),
      brand: brand,
      model: model,
      year: year,
      mileage: mileage,
      licensePlate: licensePlate,
      vin: vin,
      color: color,
      lastServiceDate: lastServiceDate,
      fuelType: fuelType,
      transmission: transmission,
      engineVolume: engineVolume,
      driveType: driveType,
      notes: notes,
      imageUrl: imageUrl,
      createdAt: now,
      updatedAt: now,
    );
  }

  // Преобразование из JSON
  factory VehicleModel.fromJson(Map<String, dynamic> json) {
    return VehicleModel(
      id: json['id'] as String,
      brand: json['brand'] as String,
      model: json['model'] as String,
      year: json['year'] as int,
      mileage: json['mileage'] as int,
      licensePlate: json['licensePlate'] as String?,
      vin: json['vin'] as String?,
      color: json['color'] as String?,
      lastServiceDate: json['lastServiceDate'] != null
          ? DateTime.parse(json['lastServiceDate'] as String)
          : null,
      fuelType: json['fuelType'] as String?,
      transmission: json['transmission'] as String?,
      engineVolume: json['engineVolume'] as String?,
      driveType: json['driveType'] as String?,
      notes: json['notes'] as String?,
      imageUrl: json['imageUrl'] as String?,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'brand': brand,
      'model': model,
      'year': year,
      'mileage': mileage,
      'licensePlate': licensePlate,
      'vin': vin,
      'color': color,
      'lastServiceDate': lastServiceDate?.toIso8601String(),
      'fuelType': fuelType,
      'transmission': transmission,
      'engineVolume': engineVolume,
      'driveType': driveType,
      'notes': notes,
      'imageUrl': imageUrl,
      'createdAt': createdAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  // Копирование с изменением свойств
  VehicleModel copyWith({
    String? id,
    String? brand,
    String? model,
    int? year,
    int? mileage,
    String? licensePlate,
    String? vin,
    String? color,
    DateTime? lastServiceDate,
    String? fuelType,
    String? transmission,
    String? engineVolume,
    String? driveType,
    String? notes,
    String? imageUrl,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return VehicleModel(
      id: id ?? this.id,
      brand: brand ?? this.brand,
      model: model ?? this.model,
      year: year ?? this.year,
      mileage: mileage ?? this.mileage,
      licensePlate: licensePlate ?? this.licensePlate,
      vin: vin ?? this.vin,
      color: color ?? this.color,
      lastServiceDate: lastServiceDate ?? this.lastServiceDate,
      fuelType: fuelType ?? this.fuelType,
      transmission: transmission ?? this.transmission,
      engineVolume: engineVolume ?? this.engineVolume,
      driveType: driveType ?? this.driveType,
      notes: notes ?? this.notes,
      imageUrl: imageUrl ?? this.imageUrl,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  // Полное имя автомобиля
  String get fullName => '$brand $model ($year)';

  // Получить следующее рекомендуемое ТО по пробегу
  int get nextServiceMileage {
    // Предполагаем, что ТО нужно каждые 10000 км
    const int serviceInterval = 10000;
    return (mileage ~/ serviceInterval + 1) * serviceInterval;
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        brand,
        model,
        year,
        mileage,
        licensePlate,
        vin,
        color,
        lastServiceDate,
        fuelType,
        transmission,
        engineVolume,
        driveType,
        notes,
        imageUrl,
        createdAt,
        updatedAt,
      ];
}
