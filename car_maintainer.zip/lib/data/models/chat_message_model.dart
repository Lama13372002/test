import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

enum MessageType {
  text,
  image,
  link,
  diagnostic,
}

enum MessageSender {
  user,
  bot,
  system,
}

class ChatMessageModel extends Equatable {
  final String id;
  final String text;
  final MessageType type;
  final MessageSender sender;
  final DateTime timestamp;
  final bool isRead;
  final String? imageUrl;
  final String? link;
  final Map<String, dynamic>? diagnosticData;

  const ChatMessageModel({
    required this.id,
    required this.text,
    required this.type,
    required this.sender,
    required this.timestamp,
    this.isRead = false,
    this.imageUrl,
    this.link,
    this.diagnosticData,
  });

  // Фабричный конструктор с генерацией нового ID
  factory ChatMessageModel.create({
    required String text,
    required MessageType type,
    required MessageSender sender,
    String? imageUrl,
    String? link,
    Map<String, dynamic>? diagnosticData,
  }) {
    return ChatMessageModel(
      id: const Uuid().v4(),
      text: text,
      type: type,
      sender: sender,
      timestamp: DateTime.now(),
      isRead: sender == MessageSender.user, // сообщения пользователя считаются прочитанными сразу
      imageUrl: imageUrl,
      link: link,
      diagnosticData: diagnosticData,
    );
  }

  // Создание текстового сообщения от пользователя
  factory ChatMessageModel.user(String text) {
    return ChatMessageModel.create(
      text: text,
      type: MessageType.text,
      sender: MessageSender.user,
    );
  }

  // Создание текстового сообщения от бота
  factory ChatMessageModel.bot(String text) {
    return ChatMessageModel.create(
      text: text,
      type: MessageType.text,
      sender: MessageSender.bot,
    );
  }

  // Создание системного сообщения
  factory ChatMessageModel.system(String text) {
    return ChatMessageModel.create(
      text: text,
      type: MessageType.text,
      sender: MessageSender.system,
    );
  }

  // Преобразование из JSON
  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    return ChatMessageModel(
      id: json['id'] as String,
      text: json['text'] as String,
      type: MessageType.values.byName(json['type'] as String),
      sender: MessageSender.values.byName(json['sender'] as String),
      timestamp: DateTime.parse(json['timestamp'] as String),
      isRead: json['isRead'] as bool? ?? false,
      imageUrl: json['imageUrl'] as String?,
      link: json['link'] as String?,
      diagnosticData: json['diagnosticData'] != null
          ? Map<String, dynamic>.from(json['diagnosticData'] as Map)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
      'type': type.name,
      'sender': sender.name,
      'timestamp': timestamp.toIso8601String(),
      'isRead': isRead,
      'imageUrl': imageUrl,
      'link': link,
      'diagnosticData': diagnosticData,
    };
  }

  // Копирование с изменением свойств
  ChatMessageModel copyWith({
    String? id,
    String? text,
    MessageType? type,
    MessageSender? sender,
    DateTime? timestamp,
    bool? isRead,
    String? imageUrl,
    String? link,
    Map<String, dynamic>? diagnosticData,
  }) {
    return ChatMessageModel(
      id: id ?? this.id,
      text: text ?? this.text,
      type: type ?? this.type,
      sender: sender ?? this.sender,
      timestamp: timestamp ?? this.timestamp,
      isRead: isRead ?? this.isRead,
      imageUrl: imageUrl ?? this.imageUrl,
      link: link ?? this.link,
      diagnosticData: diagnosticData ?? this.diagnosticData,
    );
  }

  // Отметить как прочитанное
  ChatMessageModel markAsRead() {
    return copyWith(isRead: true);
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        text,
        type,
        sender,
        timestamp,
        isRead,
        imageUrl,
        link,
        diagnosticData,
      ];
}

class ChatConversationModel extends Equatable {
  final String id;
  final String title;
  final List<ChatMessageModel> messages;
  final DateTime createdAt;
  final DateTime? lastMessageAt;

  const ChatConversationModel({
    required this.id,
    required this.title,
    required this.messages,
    required this.createdAt,
    this.lastMessageAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory ChatConversationModel.create({
    required String title,
    List<ChatMessageModel> messages = const [],
  }) {
    final now = DateTime.now();
    return ChatConversationModel(
      id: const Uuid().v4(),
      title: title,
      messages: messages,
      createdAt: now,
      lastMessageAt: messages.isNotEmpty ? messages.last.timestamp : now,
    );
  }

  // Преобразование из JSON
  factory ChatConversationModel.fromJson(Map<String, dynamic> json) {
    return ChatConversationModel(
      id: json['id'] as String,
      title: json['title'] as String,
      messages: (json['messages'] as List<dynamic>)
          .map((e) => ChatMessageModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      createdAt: DateTime.parse(json['createdAt'] as String),
      lastMessageAt: json['lastMessageAt'] != null
          ? DateTime.parse(json['lastMessageAt'] as String)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'messages': messages.map((e) => e.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'lastMessageAt': lastMessageAt?.toIso8601String(),
    };
  }

  // Добавление сообщения в беседу
  ChatConversationModel addMessage(ChatMessageModel message) {
    final updatedMessages = List<ChatMessageModel>.from(messages)..add(message);
    return copyWith(
      messages: updatedMessages,
      lastMessageAt: message.timestamp,
    );
  }

  // Копирование с изменением свойств
  ChatConversationModel copyWith({
    String? id,
    String? title,
    List<ChatMessageModel>? messages,
    DateTime? createdAt,
    DateTime? lastMessageAt,
  }) {
    return ChatConversationModel(
      id: id ?? this.id,
      title: title ?? this.title,
      messages: messages ?? this.messages,
      createdAt: createdAt ?? this.createdAt,
      lastMessageAt: lastMessageAt ?? this.lastMessageAt,
    );
  }

  // Получить последнее сообщение
  ChatMessageModel? get lastMessage {
    if (messages.isEmpty) return null;
    return messages.last;
  }

  // Получить непрочитанные сообщения
  List<ChatMessageModel> get unreadMessages {
    return messages.where((message) => !message.isRead).toList();
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [id, title, messages, createdAt, lastMessageAt];
}
