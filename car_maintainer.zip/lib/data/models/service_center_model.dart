import 'package:equatable/equatable.dart';

class ServiceCenterModel extends Equatable {
  final String id;
  final String name;
  final String address;
  final double latitude;
  final double longitude;
  final String type; // тип сервиса: официальный дилер, СТО, шиномонтаж и т.д.
  final String? phone;
  final String? website;
  final String? description;
  final double? rating;
  final List<String>? services;
  final List<ReviewModel>? reviews;
  final WorkingHoursModel? workingHours;
  final String? imageUrl;
  final double? distance; // расстояние от текущего местоположения (км)

  const ServiceCenterModel({
    required this.id,
    required this.name,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.type,
    this.phone,
    this.website,
    this.description,
    this.rating,
    this.services,
    this.reviews,
    this.workingHours,
    this.imageUrl,
    this.distance,
  });

  // Преобразование из JSON
  factory ServiceCenterModel.fromJson(Map<String, dynamic> json) {
    return ServiceCenterModel(
      id: json['id'] as String,
      name: json['name'] as String,
      address: json['address'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      type: json['type'] as String,
      phone: json['phone'] as String?,
      website: json['website'] as String?,
      description: json['description'] as String?,
      rating: json['rating'] != null ? (json['rating'] as num).toDouble() : null,
      services: json['services'] != null
          ? List<String>.from(json['services'] as List<dynamic>)
          : null,
      reviews: json['reviews'] != null
          ? (json['reviews'] as List<dynamic>)
              .map((e) => ReviewModel.fromJson(e as Map<String, dynamic>))
              .toList()
          : null,
      workingHours: json['workingHours'] != null
          ? WorkingHoursModel.fromJson(json['workingHours'] as Map<String, dynamic>)
          : null,
      imageUrl: json['imageUrl'] as String?,
      distance: json['distance'] != null ? (json['distance'] as num).toDouble() : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'type': type,
      'phone': phone,
      'website': website,
      'description': description,
      'rating': rating,
      'services': services,
      'reviews': reviews?.map((e) => e.toJson()).toList(),
      'workingHours': workingHours?.toJson(),
      'imageUrl': imageUrl,
      'distance': distance,
    };
  }

  // Копирование с изменением свойств
  ServiceCenterModel copyWith({
    String? id,
    String? name,
    String? address,
    double? latitude,
    double? longitude,
    String? type,
    String? phone,
    String? website,
    String? description,
    double? rating,
    List<String>? services,
    List<ReviewModel>? reviews,
    WorkingHoursModel? workingHours,
    String? imageUrl,
    double? distance,
  }) {
    return ServiceCenterModel(
      id: id ?? this.id,
      name: name ?? this.name,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      type: type ?? this.type,
      phone: phone ?? this.phone,
      website: website ?? this.website,
      description: description ?? this.description,
      rating: rating ?? this.rating,
      services: services ?? this.services,
      reviews: reviews ?? this.reviews,
      workingHours: workingHours ?? this.workingHours,
      imageUrl: imageUrl ?? this.imageUrl,
      distance: distance ?? this.distance,
    );
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        name,
        address,
        latitude,
        longitude,
        type,
        phone,
        website,
        description,
        rating,
        services,
        reviews,
        workingHours,
        imageUrl,
        distance,
      ];
}

class ReviewModel extends Equatable {
  final String id;
  final String authorName;
  final double rating;
  final String text;
  final DateTime date;

  const ReviewModel({
    required this.id,
    required this.authorName,
    required this.rating,
    required this.text,
    required this.date,
  });

  // Преобразование из JSON
  factory ReviewModel.fromJson(Map<String, dynamic> json) {
    return ReviewModel(
      id: json['id'] as String,
      authorName: json['authorName'] as String,
      rating: (json['rating'] as num).toDouble(),
      text: json['text'] as String,
      date: DateTime.parse(json['date'] as String),
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'authorName': authorName,
      'rating': rating,
      'text': text,
      'date': date.toIso8601String(),
    };
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [id, authorName, rating, text, date];
}

class WorkingHoursModel extends Equatable {
  final Map<String, DayHoursModel> weekdays;

  const WorkingHoursModel({
    required this.weekdays,
  });

  // Преобразование из JSON
  factory WorkingHoursModel.fromJson(Map<String, dynamic> json) {
    final Map<String, DayHoursModel> weekdays = {};

    json.forEach((key, value) {
      weekdays[key] = DayHoursModel.fromJson(value as Map<String, dynamic>);
    });

    return WorkingHoursModel(weekdays: weekdays);
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> result = {};

    weekdays.forEach((key, value) {
      result[key] = value.toJson();
    });

    return result;
  }

  // Проверить, открыто ли сейчас
  bool isOpenNow() {
    final now = DateTime.now();
    final dayOfWeek = _getDayOfWeek(now.weekday);

    if (!weekdays.containsKey(dayOfWeek)) {
      return false;
    }

    final dayHours = weekdays[dayOfWeek]!;

    if (dayHours.isClosed) {
      return false;
    }

    final currentTime = now.hour * 60 + now.minute; // текущее время в минутах
    final openTime = _timeToMinutes(dayHours.openTime);
    final closeTime = _timeToMinutes(dayHours.closeTime);

    return currentTime >= openTime && currentTime < closeTime;
  }

  // Преобразование времени в минуты
  int _timeToMinutes(String time) {
    final parts = time.split(':');
    return int.parse(parts[0]) * 60 + int.parse(parts[1]);
  }

  // Получить день недели по номеру
  String _getDayOfWeek(int weekday) {
    switch (weekday) {
      case 1:
        return 'monday';
      case 2:
        return 'tuesday';
      case 3:
        return 'wednesday';
      case 4:
        return 'thursday';
      case 5:
        return 'friday';
      case 6:
        return 'saturday';
      case 7:
        return 'sunday';
      default:
        return 'monday';
    }
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [weekdays];
}

class DayHoursModel extends Equatable {
  final String openTime;
  final String closeTime;
  final bool isClosed;

  const DayHoursModel({
    required this.openTime,
    required this.closeTime,
    this.isClosed = false,
  });

  // Преобразование из JSON
  factory DayHoursModel.fromJson(Map<String, dynamic> json) {
    if (json['isClosed'] == true) {
      return const DayHoursModel(
        openTime: '00:00',
        closeTime: '00:00',
        isClosed: true,
      );
    }

    return DayHoursModel(
      openTime: json['openTime'] as String,
      closeTime: json['closeTime'] as String,
      isClosed: json['isClosed'] as bool? ?? false,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'openTime': openTime,
      'closeTime': closeTime,
      'isClosed': isClosed,
    };
  }

  // Для отображения времени работы
  String get displayText {
    if (isClosed) return 'Закрыто';
    return '$openTime - $closeTime';
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [openTime, closeTime, isClosed];
}
