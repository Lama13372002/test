import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

class MaintenanceModel extends Equatable {
  final String id;
  final String vehicleId;
  final String type;
  final DateTime date;
  final int mileage;
  final double? cost;
  final List<String>? parts;
  final String? notes;
  final String? serviceCenter;
  final DateTime? reminderDate;
  final int? reminderMileage;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const MaintenanceModel({
    required this.id,
    required this.vehicleId,
    required this.type,
    required this.date,
    required this.mileage,
    this.cost,
    this.parts,
    this.notes,
    this.serviceCenter,
    this.reminderDate,
    this.reminderMileage,
    this.createdAt,
    this.updatedAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory MaintenanceModel.create({
    required String vehicleId,
    required String type,
    required DateTime date,
    required int mileage,
    double? cost,
    List<String>? parts,
    String? notes,
    String? serviceCenter,
    DateTime? reminderDate,
    int? reminderMileage,
  }) {
    final now = DateTime.now();
    return MaintenanceModel(
      id: const Uuid().v4(),
      vehicleId: vehicleId,
      type: type,
      date: date,
      mileage: mileage,
      cost: cost,
      parts: parts,
      notes: notes,
      serviceCenter: serviceCenter,
      reminderDate: reminderDate,
      reminderMileage: reminderMileage,
      createdAt: now,
      updatedAt: now,
    );
  }

  // Преобразование из JSON
  factory MaintenanceModel.fromJson(Map<String, dynamic> json) {
    return MaintenanceModel(
      id: json['id'] as String,
      vehicleId: json['vehicleId'] as String,
      type: json['type'] as String,
      date: DateTime.parse(json['date'] as String),
      mileage: json['mileage'] as int,
      cost: json['cost'] != null ? (json['cost'] as num).toDouble() : null,
      parts: json['parts'] != null
          ? List<String>.from(json['parts'] as List<dynamic>)
          : null,
      notes: json['notes'] as String?,
      serviceCenter: json['serviceCenter'] as String?,
      reminderDate: json['reminderDate'] != null
          ? DateTime.parse(json['reminderDate'] as String)
          : null,
      reminderMileage: json['reminderMileage'] as int?,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'vehicleId': vehicleId,
      'type': type,
      'date': date.toIso8601String(),
      'mileage': mileage,
      'cost': cost,
      'parts': parts,
      'notes': notes,
      'serviceCenter': serviceCenter,
      'reminderDate': reminderDate?.toIso8601String(),
      'reminderMileage': reminderMileage,
      'createdAt': createdAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  // Копирование с изменением свойств
  MaintenanceModel copyWith({
    String? id,
    String? vehicleId,
    String? type,
    DateTime? date,
    int? mileage,
    double? cost,
    List<String>? parts,
    String? notes,
    String? serviceCenter,
    DateTime? reminderDate,
    int? reminderMileage,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return MaintenanceModel(
      id: id ?? this.id,
      vehicleId: vehicleId ?? this.vehicleId,
      type: type ?? this.type,
      date: date ?? this.date,
      mileage: mileage ?? this.mileage,
      cost: cost ?? this.cost,
      parts: parts ?? this.parts,
      notes: notes ?? this.notes,
      serviceCenter: serviceCenter ?? this.serviceCenter,
      reminderDate: reminderDate ?? this.reminderDate,
      reminderMileage: reminderMileage ?? this.reminderMileage,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        vehicleId,
        type,
        date,
        mileage,
        cost,
        parts,
        notes,
        serviceCenter,
        reminderDate,
        reminderMileage,
        createdAt,
        updatedAt,
      ];
}
