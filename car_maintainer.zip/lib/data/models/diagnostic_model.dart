import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

class DiagnosticIssueModel extends Equatable {
  final String id;
  final String category;
  final String symptom;
  final List<String> possibleCauses;
  final List<String> recommendedActions;
  final int severityLevel; // От 1 (незначительная) до 5 (критическая)
  final DateTime? createdAt;

  const DiagnosticIssueModel({
    required this.id,
    required this.category,
    required this.symptom,
    required this.possibleCauses,
    required this.recommendedActions,
    this.severityLevel = 3,
    this.createdAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory DiagnosticIssueModel.create({
    required String category,
    required String symptom,
    required List<String> possibleCauses,
    required List<String> recommendedActions,
    int severityLevel = 3,
  }) {
    return DiagnosticIssueModel(
      id: const Uuid().v4(),
      category: category,
      symptom: symptom,
      possibleCauses: possibleCauses,
      recommendedActions: recommendedActions,
      severityLevel: severityLevel,
      createdAt: DateTime.now(),
    );
  }

  // Преобразование из JSON
  factory DiagnosticIssueModel.fromJson(Map<String, dynamic> json) {
    return DiagnosticIssueModel(
      id: json['id'] as String,
      category: json['category'] as String,
      symptom: json['symptom'] as String,
      possibleCauses: List<String>.from(json['possibleCauses'] as List<dynamic>),
      recommendedActions: List<String>.from(json['recommendedActions'] as List<dynamic>),
      severityLevel: json['severityLevel'] as int? ?? 3,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'category': category,
      'symptom': symptom,
      'possibleCauses': possibleCauses,
      'recommendedActions': recommendedActions,
      'severityLevel': severityLevel,
      'createdAt': createdAt?.toIso8601String(),
    };
  }

  // Копирование с изменением свойств
  DiagnosticIssueModel copyWith({
    String? id,
    String? category,
    String? symptom,
    List<String>? possibleCauses,
    List<String>? recommendedActions,
    int? severityLevel,
    DateTime? createdAt,
  }) {
    return DiagnosticIssueModel(
      id: id ?? this.id,
      category: category ?? this.category,
      symptom: symptom ?? this.symptom,
      possibleCauses: possibleCauses ?? this.possibleCauses,
      recommendedActions: recommendedActions ?? this.recommendedActions,
      severityLevel: severityLevel ?? this.severityLevel,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  // Геттер для получения цвета по уровню критичности
  String get severityColor {
    switch (severityLevel) {
      case 1:
        return '#34C759'; // Зеленый
      case 2:
        return '#5AC8FA'; // Голубой
      case 3:
        return '#FFCC00'; // Желтый
      case 4:
        return '#FF9500'; // Оранжевый
      case 5:
        return '#FF3B30'; // Красный
      default:
        return '#FFCC00'; // По умолчанию желтый
    }
  }

  // Геттер для получения текстового описания уровня критичности
  String get severityText {
    switch (severityLevel) {
      case 1:
        return 'Незначительная';
      case 2:
        return 'Низкая';
      case 3:
        return 'Средняя';
      case 4:
        return 'Высокая';
      case 5:
        return 'Критическая';
      default:
        return 'Средняя';
    }
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        category,
        symptom,
        possibleCauses,
        recommendedActions,
        severityLevel,
        createdAt,
      ];
}

class DiagnosticQueryModel extends Equatable {
  final String id;
  final String category;
  final String description;
  final List<DiagnosticIssueModel> results;
  final DateTime createdAt;

  const DiagnosticQueryModel({
    required this.id,
    required this.category,
    required this.description,
    required this.results,
    required this.createdAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory DiagnosticQueryModel.create({
    required String category,
    required String description,
    List<DiagnosticIssueModel> results = const [],
  }) {
    return DiagnosticQueryModel(
      id: const Uuid().v4(),
      category: category,
      description: description,
      results: results,
      createdAt: DateTime.now(),
    );
  }

  // Преобразование из JSON
  factory DiagnosticQueryModel.fromJson(Map<String, dynamic> json) {
    return DiagnosticQueryModel(
      id: json['id'] as String,
      category: json['category'] as String,
      description: json['description'] as String,
      results: (json['results'] as List<dynamic>)
          .map((e) => DiagnosticIssueModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'category': category,
      'description': description,
      'results': results.map((e) => e.toJson()).toList(),
      'createdAt': createdAt.toIso8601String(),
    };
  }

  // Копирование с изменением свойств
  DiagnosticQueryModel copyWith({
    String? id,
    String? category,
    String? description,
    List<DiagnosticIssueModel>? results,
    DateTime? createdAt,
  }) {
    return DiagnosticQueryModel(
      id: id ?? this.id,
      category: category ?? this.category,
      description: description ?? this.description,
      results: results ?? this.results,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [id, category, description, results, createdAt];
}
