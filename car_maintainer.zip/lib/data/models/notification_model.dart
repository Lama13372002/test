import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

class NotificationModel extends Equatable {
  final String id;
  final String vehicleId;
  final String? vehicleName;
  final String type;
  final String title;
  final String body;
  final DateTime scheduledDate;
  final int? scheduledMileage;
  final int? notificationId;
  final bool isRead;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const NotificationModel({
    required this.id,
    required this.vehicleId,
    this.vehicleName,
    required this.type,
    required this.title,
    required this.body,
    required this.scheduledDate,
    this.scheduledMileage,
    this.notificationId,
    this.isRead = false,
    this.createdAt,
    this.updatedAt,
  });

  // Фабричный конструктор с генерацией нового ID
  factory NotificationModel.create({
    required String vehicleId,
    String? vehicleName,
    required String type,
    required String title,
    required String body,
    required DateTime scheduledDate,
    int? scheduledMileage,
    int? notificationId,
  }) {
    final now = DateTime.now();
    return NotificationModel(
      id: const Uuid().v4(),
      vehicleId: vehicleId,
      vehicleName: vehicleName,
      type: type,
      title: title,
      body: body,
      scheduledDate: scheduledDate,
      scheduledMileage: scheduledMileage,
      notificationId: notificationId,
      isRead: false,
      createdAt: now,
      updatedAt: now,
    );
  }

  // Преобразование из JSON
  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'] as String,
      vehicleId: json['vehicleId'] as String,
      vehicleName: json['vehicleName'] as String?,
      type: json['type'] as String,
      title: json['title'] as String,
      body: json['body'] as String,
      scheduledDate: DateTime.parse(json['scheduledDate'] as String),
      scheduledMileage: json['scheduledMileage'] as int?,
      notificationId: json['notificationId'] as int?,
      isRead: json['isRead'] as bool? ?? false,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'] as String)
          : null,
    );
  }

  // Преобразование в JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'vehicleId': vehicleId,
      'vehicleName': vehicleName,
      'type': type,
      'title': title,
      'body': body,
      'scheduledDate': scheduledDate.toIso8601String(),
      'scheduledMileage': scheduledMileage,
      'notificationId': notificationId,
      'isRead': isRead,
      'createdAt': createdAt?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  // Копирование с изменением свойств
  NotificationModel copyWith({
    String? id,
    String? vehicleId,
    String? vehicleName,
    String? type,
    String? title,
    String? body,
    DateTime? scheduledDate,
    int? scheduledMileage,
    int? notificationId,
    bool? isRead,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return NotificationModel(
      id: id ?? this.id,
      vehicleId: vehicleId ?? this.vehicleId,
      vehicleName: vehicleName ?? this.vehicleName,
      type: type ?? this.type,
      title: title ?? this.title,
      body: body ?? this.body,
      scheduledDate: scheduledDate ?? this.scheduledDate,
      scheduledMileage: scheduledMileage ?? this.scheduledMileage,
      notificationId: notificationId ?? this.notificationId,
      isRead: isRead ?? this.isRead,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  // Отметить как прочитанное
  NotificationModel markAsRead() {
    return copyWith(isRead: true);
  }

  // Проверить, является ли уведомление активным
  bool get isActive {
    final now = DateTime.now();
    return scheduledDate.isAfter(now);
  }

  // Для сравнения объектов
  @override
  List<Object?> get props => [
        id,
        vehicleId,
        vehicleName,
        type,
        title,
        body,
        scheduledDate,
        scheduledMileage,
        notificationId,
        isRead,
        createdAt,
        updatedAt,
      ];
}
