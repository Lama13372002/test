// Скрипт для отключения запросов изображений и
// добавления функциональности кнопкам в модальном окне устройств

// Отключаем запросы изображений
(function() {
    // Оригинальный метод создания элемента
    const originalCreateElement = document.createElement;

    // Переопределяем метод для перехвата создания img элементов
    document.createElement = function(tagName) {
        if (tagName.toLowerCase() === 'img') {
            // Для img элементов устанавливаем обработчик ошибки
            const imgElement = originalCreateElement.call(document, tagName);
            imgElement.onerror = function() {
                if (this.src && !this.src.startsWith('data:')) {
                    this.src = '/img/methods/unknown_method.svg';
                }
            };
            return imgElement;
        }
        return originalCreateElement.call(document, tagName);
    };
})();

// Добавляем обработчики для модальных окон и кнопок после загрузки DOM
document.addEventListener('DOMContentLoaded', function() {
    // Функция для добавления обработчиков к кнопкам в модальном окне устройств
    function setupDeviceModalHandlers() {
        // Находим модальное окно устройств
        const deviceModals = document.querySelectorAll('.modal');
        deviceModals.forEach(function(modal) {
            const title = modal.querySelector('.modal-title');
            if (title && title.textContent === 'Устройства') {
                // Кнопка добавления устройства
                const addButton = modal.querySelector('.fa-plus').closest('button');
                if (addButton) {
                    addButton.addEventListener('click', function() {
                        alert('Добавление устройства');
                        // Здесь должен быть код для открытия формы добавления устройства
                    });
                }

                // Динамически добавляем функциональность для кнопок редактирования и удаления,
                // которые могут появиться позже
                modal.addEventListener('click', function(e) {
                    // Кнопка редактирования
                    if (e.target.classList.contains('fa-pencil') ||
                        e.target.closest('button:has(.fa-pencil)')) {
                        e.preventDefault();
                        alert('Редактирование устройства');
                        // Здесь должен быть код для открытия формы редактирования устройства
                    }

                    // Кнопка удаления
                    if (e.target.classList.contains('fa-trash') ||
                        e.target.closest('button:has(.fa-trash)')) {
                        e.preventDefault();
                        alert('Удаление устройства');
                        // Здесь должен быть код для подтверждения и удаления устройства
                    }

                    // Кнопка комментариев
                    if (e.target.classList.contains('fa-comments') ||
                        e.target.closest('button:has(.fa-comments)')) {
                        e.preventDefault();
                        alert('Комментарии к устройству');
                        // Здесь должен быть код для открытия комментариев
                    }

                    // Кнопка Android
                    if (e.target.classList.contains('fa-android') ||
                        e.target.closest('button:has(.fa-android)')) {
                        e.preventDefault();
                        alert('Android приложения для устройства');
                        // Здесь должен быть код для отображения Android приложений
                    }
                });
            }
        });
    }

    // Запускаем настройку обработчиков
    setupDeviceModalHandlers();

    // Для динамически добавляемых модальных окон также добавляем
    // мутационный обсервер, который будет отслеживать появление новых модальных окон
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                for(let i = 0; i < mutation.addedNodes.length; i++) {
                    const node = mutation.addedNodes[i];
                    if (node.classList && node.classList.contains('modal')) {
                        setupDeviceModalHandlers();
                        break;
                    }
                }
            }
        });
    });

    // Наблюдаем за изменениями в body
    observer.observe(document.body, { childList: true, subtree: true });
});
