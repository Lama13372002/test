import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function AIChatPlaceholder() {
  return (
    <div className="flex flex-col h-full bg-gray-50 rounded-lg border dark:bg-gray-900/50">
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          <div className="flex flex-col">
            <div className="bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-200 p-3 rounded-lg self-center max-w-[80%] text-center">
              <p className="whitespace-pre-wrap text-sm">Добро пожаловать в DualAI Code! Задайте вопрос, и оба ассистента помогут вам с разработкой.</p>
            </div>
            <div className="text-xs text-gray-500 mt-1 px-1">
              10:30
            </div>
          </div>

          <div className="flex flex-col">
            <div className="bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-100 p-3 rounded-lg self-end max-w-[80%]">
              <div className="font-medium mb-1">Вы</div>
              <p className="whitespace-pre-wrap">Как мне реализовать авторизацию через JWT в Next.js?</p>
            </div>
            <div className="text-xs text-gray-500 mt-1 px-1 self-end">
              10:31
            </div>
          </div>

          <div className="flex flex-col">
            <div className="bg-blue-100 text-blue-900 dark:bg-blue-900/20 dark:text-blue-100 p-3 rounded-lg self-start max-w-[80%]">
              <div className="font-medium mb-1">ChatGPT</div>
              <p className="whitespace-pre-wrap">Для реализации JWT авторизации в Next.js можно использовать библиотеку next-auth или jsonwebtoken напрямую. Вот базовые шаги:

1. Установите необходимые пакеты:
```
npm install jsonwebtoken cookie
npm install @types/jsonwebtoken @types/cookie --save-dev
```

2. Создайте API-роут для аутентификации в `/pages/api/auth/login.js`
3. Реализуйте проверку учетных данных и генерацию токена
4. Храните токен в куки или localStorage
5. Создайте HOC или middleware для защиты маршрутов

Подробный пример хотите увидеть?</p>
            </div>
            <div className="text-xs text-gray-500 mt-1 px-1">
              10:32
            </div>
          </div>

          <div className="flex flex-col">
            <div className="bg-emerald-100 text-emerald-900 dark:bg-emerald-900/20 dark:text-emerald-100 p-3 rounded-lg self-start max-w-[80%]">
              <div className="font-medium mb-1">Claude</div>
              <p className="whitespace-pre-wrap">В Next.js есть несколько подходов к JWT аутентификации:

1. **Используя next-auth (рекомендуется):**
   - Простая интеграция, множество провайдеров
   - Хорошая документация, официальная поддержка

2. **Ручная реализация с jsonwebtoken:**
   - Больше контроля над процессом
   - Требует больше кода

Для полноценной реализации стоит создать:
- API для входа/регистрации
- Хранение токена (HttpOnly cookie предпочтительнее localStorage)
- Middleware для проверки авторизации
- Контекст React для пользовательских данных

Если у вас есть конкретные требования к авторизации, я могу предложить более детальное решение.</p>
            </div>
            <div className="text-xs text-gray-500 mt-1 px-1">
              10:33
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="both" className="px-4 mb-3">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="both">Оба ассистента</TabsTrigger>
          <TabsTrigger value="chatgpt">ChatGPT</TabsTrigger>
          <TabsTrigger value="claude">Claude</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="p-4 border-t">
        <div className="flex space-x-2">
          <Textarea
            placeholder="Введите ваше сообщение..."
            className="min-h-[80px]"
            disabled={true}
          />
          <Button
            className="h-full"
            disabled={true}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 10l7-7m0 0l7 7m-7-7v18"
                transform="rotate(90 12 12)"
              />
            </svg>
            <span className="sr-only">Отправить</span>
          </Button>
        </div>
        <p className="text-xs text-center mt-2 text-gray-500">
          Примечание: В демо-версии функциональность чата ограничена
        </p>
      </div>
    </div>
  )
}
