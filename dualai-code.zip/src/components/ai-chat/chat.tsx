"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type Message = {
  id: string
  sender: "user" | "chatgpt" | "claude" | "system"
  content: string
  timestamp: Date
}

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "system",
      content: "Добро пожаловать в DualAI Code! Задайте вопрос, и оба ассистента помогут вам с разработкой.",
      timestamp: new Date(),
    },
  ])

  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSendMessage = () => {
    if (inputMessage.trim() === "") return

    // Добавление сообщения пользователя
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: inputMessage,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)

    // Имитация ответа от ChatGPT (в реальном приложении здесь будет API запрос)
    setTimeout(() => {
      const chatgptResponse: Message = {
        id: Date.now().toString(),
        sender: "chatgpt",
        content: "Это демо-ответ от ChatGPT. В реальном приложении здесь будет фактический ответ от API.",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, chatgptResponse])

      // Имитация ответа от Claude с небольшой задержкой
      setTimeout(() => {
        const claudeResponse: Message = {
          id: Date.now().toString(),
          sender: "claude",
          content: "Это демо-ответ от Claude. В реальном приложении здесь будет фактический ответ от API Anthropic.",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, claudeResponse])
        setIsLoading(false)
      }, 1500)
    }, 1000)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex flex-col h-full bg-gray-50 rounded-lg border dark:bg-gray-900/50">
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="flex flex-col">
              {message.sender === "user" ? (
                <div className="bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-100 p-3 rounded-lg self-end max-w-[80%]">
                  <div className="font-medium mb-1">Вы</div>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              ) : message.sender === "system" ? (
                <div className="bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-200 p-3 rounded-lg self-center max-w-[80%] text-center">
                  <p className="whitespace-pre-wrap text-sm">{message.content}</p>
                </div>
              ) : (
                <div className={`${
                  message.sender === "chatgpt"
                    ? "bg-blue-100 text-blue-900 dark:bg-blue-900/20 dark:text-blue-100"
                    : "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/20 dark:text-emerald-100"
                } p-3 rounded-lg self-start max-w-[80%]`}>
                  <div className="font-medium mb-1">
                    {message.sender === "chatgpt" ? "ChatGPT" : "Claude"}
                  </div>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              )}
              <div className="text-xs text-gray-500 mt-1 px-1">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex space-x-2 p-3 rounded-lg self-start max-w-[80%] bg-gray-100 dark:bg-gray-800/50">
              <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce"></div>
              <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-500 animate-bounce [animation-delay:0.4s]"></div>
            </div>
          )}
        </div>
      </div>

      <Tabs defaultValue="both" className="px-4 mb-3">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="both">Оба ассистента</TabsTrigger>
          <TabsTrigger value="chatgpt">ChatGPT</TabsTrigger>
          <TabsTrigger value="claude">Claude</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="p-4 border-t">
        <div className="flex space-x-2">
          <Textarea
            placeholder="Введите ваше сообщение..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-[80px]"
            disabled={isLoading}
          />
          <Button
            onClick={handleSendMessage}
            disabled={isLoading || inputMessage.trim() === ""}
            className="h-full"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 10l7-7m0 0l7 7m-7-7v18"
                transform="rotate(90 12 12)"
              />
            </svg>
            <span className="sr-only">Отправить</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
