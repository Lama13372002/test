import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 w-full">
      <div className="container py-10">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-medium">DualAI Code</h3>
            <p className="text-sm text-muted-foreground">
              Платформа для коллаборативной разработки кода с использованием двух AI-моделей
            </p>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-medium">Ресурсы</h3>
            <Link href="/documentation" className="text-sm text-muted-foreground hover:text-foreground">
              Документация
            </Link>
            <Link href="/examples" className="text-sm text-muted-foreground hover:text-foreground">
              Примеры проектов
            </Link>
            <Link href="/tutorials" className="text-sm text-muted-foreground hover:text-foreground">
              Руководства
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-medium">Компания</h3>
            <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
              О нас
            </Link>
            <Link href="/blog" className="text-sm text-muted-foreground hover:text-foreground">
              Блог
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
              Контакты
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-medium">Правовая информация</h3>
            <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
              Условия использования
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
              Политика конфиденциальности
            </Link>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 DualAI Code. Все права защищены.</p>
        </div>
      </div>
    </footer>
  )
}
