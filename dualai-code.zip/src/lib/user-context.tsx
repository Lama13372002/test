"use client"

import React, { createContext, useContext, useState, useEffect } from "react"

export type UserRole = "basic" | "premium" | "admin" | null
export type User = {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

type UserContextType = {
  user: User | null
  isLoading: boolean
  isLoggedIn: boolean
  role: UserRole
  login: (user: User) => void
  logout: () => void
  updateUser: (userData: Partial<User>) => void
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)

  // Проверка авторизации при загрузке
  // В реальном приложении здесь должен быть запрос к API
  useEffect(() => {
    // Имитация загрузки данных пользователя
    const storedUser = localStorage.getItem("user")

    setTimeout(() => {
      if (storedUser) {
        try {
          const userData = JSON.parse(storedUser)
          setUser(userData)
        } catch (error) {
          console.error("Не удалось получить данные пользователя", error)
          localStorage.removeItem("user")
        }
      }
      setIsLoading(false)
    }, 500)
  }, [])

  const login = (userData: User) => {
    setUser(userData)
    localStorage.setItem("user", JSON.stringify(userData))
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  const updateUser = (userData: Partial<User>) => {
    if (!user) return

    const updatedUser = {
      ...user,
      ...userData,
    }

    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))
  }

  return (
    <UserContext.Provider
      value={{
        user,
        isLoading,
        isLoggedIn: !!user,
        role: user?.role || null,
        login,
        logout,
        updateUser,
      }}
    >
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)

  if (context === undefined) {
    throw new Error("useUser должен использоваться внутри UserProvider")
  }

  return context
}

// Хук для проверки роли пользователя
export function useHasRole(requiredRole: UserRole) {
  const { role } = useUser()

  if (!role || !requiredRole) return false

  // Админы имеют доступ ко всему
  if (role === "admin") return true

  // Premium пользователи имеют доступ к premium и basic функциям
  if (role === "premium" && requiredRole === "basic") return true

  // Базовый доступ только к basic функциям
  return role === requiredRole
}
