import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export const metadata = {
  title: "Загрузка кода - DualAI Code",
  description: "Загрузите существующий код для анализа и доработки в DualAI Code",
}

export default function UploadCodePage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Загрузка существующего кода</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Загрузите ваш код для анализа и доработки с помощью AI-ассистентов
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Детали проекта</CardTitle>
          <CardDescription>
            Основная информация о вашем проекте
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="project-name">Название проекта</Label>
            <Input id="project-name" placeholder="Введите название проекта" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="project-description">Описание</Label>
            <Textarea
              id="project-description"
              placeholder="Краткое описание проекта и задач"
              className="min-h-24"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Загрузка кода</CardTitle>
          <CardDescription>
            Загрузите исходный код вашего проекта
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="mx-auto h-12 w-12 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
              />
            </svg>
            <p className="mt-2 text-sm font-medium">
              Перетащите ZIP/RAR архив или репозиторий сюда или{" "}
              <span className="text-violet-600 hover:underline cursor-pointer">выберите файлы</span>
            </p>
            <p className="mt-1 text-xs text-gray-500">Поддерживаемые форматы: ZIP, RAR, TAR, GZ до 100MB</p>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-3 border rounded-md bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-gray-500 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              <span className="text-sm text-gray-700 dark:text-gray-300">Или укажите URL репозитория</span>
            </div>
            <Input
              placeholder="https://github.com/username/repository"
              className="max-w-xs"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Задачи и инструкции</CardTitle>
          <CardDescription>
            Опишите, что вы хотите сделать с кодом
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tasks">Что требуется сделать с кодом?</Label>
            <Textarea
              id="tasks"
              placeholder="Например: Улучшить производительность, исправить баги, добавить новые функции, обновить стиль и т.д."
              className="min-h-32"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tech-stack">Технологический стек проекта</Label>
            <Input
              id="tech-stack"
              placeholder="Например: React, Node.js, Express, MongoDB"
            />
          </div>

          <div className="border p-4 rounded-md bg-amber-50 dark:bg-amber-950/50 mt-4">
            <div className="flex items-start space-x-3">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-amber-600 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              <div>
                <h4 className="font-medium text-amber-800 dark:text-amber-400">Рекомендации</h4>
                <ul className="mt-1 text-sm text-amber-700 dark:text-amber-300 space-y-1 list-disc pl-5">
                  <li>Убедитесь, что архив содержит все необходимые файлы</li>
                  <li>Исключите node_modules, .git и другие директории с зависимостями</li>
                  <li>По возможности укажите точные цели и требования</li>
                  <li>Чем подробнее вы опишете задачу, тем лучше результат</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>AI-ассистенты</CardTitle>
          <CardDescription>
            Настройте ассистентов для анализа кода
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center space-x-3">
              <div className="size-9 rounded-full bg-violet-100 flex items-center justify-center text-violet-800">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              <div>
                <p className="font-medium">ChatGPT 4.0</p>
                <p className="text-sm text-gray-500">Основной анализ кода</p>
              </div>
            </div>
            <input
              type="checkbox"
              className="h-6 w-10 rounded-full bg-gray-300 before:rounded-full before:bg-white dark:bg-gray-600 checked:bg-violet-600 checked:before:translate-x-4 relative before:absolute before:h-5 before:w-5 before:top-[2px] before:left-[2px] transition before:transition"
              defaultChecked
            />
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center space-x-3">
              <div className="size-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-800">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
              </div>
              <div>
                <p className="font-medium">Claude 3.7</p>
                <p className="text-sm text-gray-500">Дополнительный анализ и рекомендации</p>
              </div>
            </div>
            <input
              type="checkbox"
              className="h-6 w-10 rounded-full bg-gray-300 before:rounded-full before:bg-white dark:bg-gray-600 checked:bg-violet-600 checked:before:translate-x-4 relative before:absolute before:h-5 before:w-5 before:top-[2px] before:left-[2px] transition before:transition"
              defaultChecked
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end space-x-4">
        <Button variant="outline" asChild>
          <Link href="/dashboard">Отмена</Link>
        </Button>
        <Button>Загрузить и начать анализ</Button>
      </div>
    </div>
  )
}
