"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { useUser } from "@/lib/user-context"
import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function DashboardLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const pathname = usePathname()
  const { user, isLoggedIn, logout, role } = useUser()
  const router = useRouter()

  // Перенаправляем не авторизованных пользователей на страницу входа
  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/login")
    }
  }, [isLoggedIn, router])

  // Если пользователь не авторизован, показываем заглушку загрузки
  if (!isLoggedIn) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="space-y-4 text-center">
          <div className="flex space-x-2 justify-center">
            <div className="w-3 h-3 rounded-full bg-violet-600 animate-bounce"></div>
            <div className="w-3 h-3 rounded-full bg-violet-600 animate-bounce [animation-delay:0.2s]"></div>
            <div className="w-3 h-3 rounded-full bg-violet-600 animate-bounce [animation-delay:0.4s]"></div>
          </div>
          <p className="text-sm text-gray-500">Загрузка...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="hidden w-64 flex-shrink-0 border-r bg-gray-50/50 dark:bg-gray-900/50 md:flex md:flex-col">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <span className="text-xl font-bold">Мой кабинет</span>
          </Link>
        </div>
        <nav className="flex flex-1 flex-col py-4">
          <div className="px-4 py-2">
            <h2 className="mb-2 text-sm font-semibold text-gray-500 dark:text-gray-400">Главное</h2>
            <div className="space-y-1">
              <Link
                href="/dashboard"
                className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                  pathname === "/dashboard"
                    ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                    : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                  />
                </svg>
                Обзор
              </Link>
              <Link
                href="/dashboard/projects"
                className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                  pathname === "/dashboard/projects" || pathname.startsWith("/dashboard/projects/")
                    ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                    : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
                  />
                </svg>
                Проекты
              </Link>
              <Link
                href="/dashboard/settings"
                className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                  pathname === "/dashboard/settings"
                    ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                    : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                Настройки
              </Link>
            </div>
          </div>

          {role === "premium" && (
            <div className="px-4 py-2">
              <h2 className="mb-2 text-sm font-semibold text-gray-500 dark:text-gray-400">Премиум функции</h2>
              <div className="space-y-1">
                <Link
                  href="/dashboard/advanced-analytics"
                  className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                    pathname === "/dashboard/advanced-analytics"
                      ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                  }`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="mr-2 h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                  Расширенная аналитика
                </Link>
                <Link
                  href="/dashboard/api-integrations"
                  className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                    pathname === "/dashboard/api-integrations"
                      ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                  }`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="mr-2 h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                  API Интеграции
                </Link>
                <Link
                  href="/dashboard/team-management"
                  className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                    pathname === "/dashboard/team-management"
                      ? "bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-50"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800/50"
                  }`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="mr-2 h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                  Управление командой
                </Link>
              </div>
            </div>
          )}
        </nav>
        <div className="border-t p-4">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={user?.avatar || ""} />
              <AvatarFallback>
                {user?.name?.split(" ").map(n => n[0]).join("") || "П"}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-0.5">
              <p className="text-sm font-medium">{user?.name || "Пользователь"}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {role === "premium" ? "Премиум план" : "Базовый план"}
              </p>
            </div>
          </div>
          <Button variant="outline" className="mt-4 w-full" onClick={() => logout()}>
            Выйти
          </Button>
        </div>
      </div>

      {/* Mobile Nav */}
      <div className="flex md:hidden w-full border-b bg-background h-14 items-center px-4 sticky top-0 z-10">
        <Link href="/dashboard" className="font-semibold">
          Мой кабинет
        </Link>
        <div className="ml-auto">
          <Avatar className="size-8">
            <AvatarImage src={user?.avatar || ""} />
            <AvatarFallback>
              {user?.name?.split(" ").map(n => n[0]).join("") || "П"}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 flex-col">
        <div className="flex-1 p-6 md:p-8">
          {children}
        </div>
      </div>
    </div>
  )
}
