import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export const metadata = {
  title: "API Интеграции - DualAI Code",
  description: "Интеграция DualAI Code с внешними сервисами и APIs",
}

export default function ApiIntegrationsPage() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">API Интеграции</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Интегрируйте DualAI Code с вашими любимыми инструментами разработки
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>GitHub</CardTitle>
            <CardDescription>Подключите ваш GitHub аккаунт для импорта и экспорта кода</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
              <svg className="w-8 h-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"
                />
              </svg>
              <div>
                <p className="font-medium">GitHub</p>
                <p className="text-sm text-gray-500">Не подключено</p>
              </div>
              <Button className="ml-auto">Подключить</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>GitLab</CardTitle>
            <CardDescription>Подключите ваш GitLab аккаунт для импорта и экспорта кода</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
              <svg className="w-8 h-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                <path d="M22.65 14.39L12 22.13 1.35 14.39a.84.84 0 0 1-.3-.94l1.22-3.78 2.44-7.51A.42.42 0 0 1 4.82 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.49h8.1l2.44-7.51A.42.42 0 0 1 18.6 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.51L23 13.45a.84.84 0 0 1-.35.94z" />
              </svg>
              <div>
                <p className="font-medium">GitLab</p>
                <p className="text-sm text-gray-500">Не подключено</p>
              </div>
              <Button className="ml-auto">Подключить</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Bitbucket</CardTitle>
            <CardDescription>Подключите ваш Bitbucket аккаунт для импорта и экспорта кода</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
              <svg className="w-8 h-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                <path d="M.778 1.211c-.424 0-.635.191-.635.574 0 .061 0 .122.016.195l3.348 20.512c.086.5.424.86.86.86h16.195c.424 0 .635-.274.635-.631a.8.8 0 0 0-.016-.195L17.83 1.977a.839.839 0 0 0-.847-.766H.778zM14.316 15.3c-.311.328-.944.722-1.609.722-1.069 0-1.337-.766-1.154-1.337l1.075-6.574H8.947l-1.815 8.432s-.264 1.624 1.901 1.624c1.19 0 2.101-.407 2.66-.719l-.311 1.487h3.978l2.945-14.574h-4l-1.292 6.425.303-2.485z" />
              </svg>
              <div>
                <p className="font-medium">Bitbucket</p>
                <p className="text-sm text-gray-500">Не подключено</p>
              </div>
              <Button className="ml-auto">Подключить</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Jira</CardTitle>
            <CardDescription>Подключите ваш Jira аккаунт для интеграции тикетов</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
              <svg className="w-8 h-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                <path d="M11.571 11.513H0a5.218 5.218 0 0 0 5.232 5.215h2.13v2.057A5.215 5.215 0 0 0 12.575 24V12.518a1.005 1.005 0 0 0-1.005-1.005zm5.723-5.756H5.736a5.215 5.215 0 0 0 5.215 5.214h2.129v2.058a5.218 5.218 0 0 0 5.215 5.214V6.758a1.001 1.001 0 0 0-1.001-1.001zM23.013 0H11.455a5.215 5.215 0 0 0 5.215 5.215h2.129v2.057A5.215 5.215 0 0 0 24 12.483V1.005A1.001 1.001 0 0 0 23.013 0z" />
              </svg>
              <div>
                <p className="font-medium">Jira</p>
                <p className="text-sm text-gray-500">Не подключено</p>
              </div>
              <Button className="ml-auto">Подключить</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>API Ключи</CardTitle>
          <CardDescription>Управляйте вашими API ключами</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">Основной API ключ</p>
                <p className="text-xs text-gray-500">Создан 15.03.2023</p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">Обновить</Button>
                <Button variant="outline" size="sm" className="text-red-500">Удалить</Button>
              </div>
            </div>
            <div className="flex">
              <Input className="font-mono bg-gray-50 dark:bg-gray-900" value="••••••••••••••••••••••••••••" readOnly />
              <Button className="ml-2" variant="outline">Показать</Button>
              <Button className="ml-2">Копировать</Button>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="ml-auto">Создать новый ключ</Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Webhooks</CardTitle>
          <CardDescription>Настройте webhook URL для уведомлений</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <p className="text-sm">URL для уведомлений</p>
            <div className="flex">
              <Input placeholder="https://yoursite.com/webhook" />
              <Button className="ml-2">Сохранить</Button>
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-sm">События</p>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="project-created" className="rounded text-violet-600" />
                <label htmlFor="project-created" className="text-sm">Создание проекта</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="project-updated" className="rounded text-violet-600" />
                <label htmlFor="project-updated" className="text-sm">Обновление проекта</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="code-generated" className="rounded text-violet-600" />
                <label htmlFor="code-generated" className="text-sm">Генерация кода</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="error-occurred" className="rounded text-violet-600" />
                <label htmlFor="error-occurred" className="text-sm">Возникновение ошибки</label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-sm text-gray-500 mt-6">
        Эти функции доступны только для премиум-пользователей.{" "}
        <Link href="/pricing" className="text-violet-600 hover:underline">
          Узнать больше о преимуществах премиум-подписки
        </Link>
      </p>
    </div>
  )
}
