import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Список проектов для статической генерации
const projectIds = ["1", "2", "3"];

// Для статического экспорта
export function generateStaticParams() {
  return projectIds.map(id => ({ id }));
}

export default function EditProjectPage({ params }: { params: { id: string } }) {
  const projectId = params.id;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link href={`/dashboard/projects/${projectId}`} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span className="sr-only">Назад</span>
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">Редактирование проекта #{projectId}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Редактирование проекта</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Страница редактирования проекта находится в разработке</p>
          <div className="mt-4">
            <Button asChild>
              <Link href={`/dashboard/projects/${projectId}`}>Вернуться к проекту</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
