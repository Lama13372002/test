import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AIChatPlaceholder } from "@/components/ai-chat/chat-placeholder"

// Данные проектов (в реальном приложении будут загружаться с сервера)
const projectsData: Record<string, {
  id: string;
  name: string;
  description: string;
  techStack: string;
}> = {
  "1": {
    id: "1",
    name: "Фронтенд e-commerce",
    description: "React приложение для интернет-магазина",
    techStack: "React, Redux, Tailwind CSS",
  },
  "2": {
    id: "2",
    name: "Backend API",
    description: "Node.js REST API для мобильного приложения",
    techStack: "Node.js, Express, MongoDB",
  },
  "3": {
    id: "3",
    name: "Лендинг для стартапа",
    description: "Одностраничный лендинг с анимациями",
    techStack: "HTML, CSS, JavaScript, GSAP",
  },
};

// Для статического экспорта
export function generateStaticParams() {
  return Object.keys(projectsData).map(id => ({ id }));
}

export default function ProjectChatPage({ params }: { params: { id: string } }) {
  const projectId = params.id;

  // В реальном приложении здесь был бы запрос к API
  const project = projectsData[projectId] || {
    id: projectId,
    name: "Проект не найден",
    description: "Информация о проекте отсутствует",
    techStack: "-",
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/projects/${projectId}`} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>
              <span className="sr-only">Назад</span>
            </Link>
            <h1 className="text-2xl font-bold tracking-tight">Чат проекта {project.name}</h1>
          </div>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Взаимодействие с AI-ассистентами для разработки
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="text-xl">Чат с AI-ассистентами</CardTitle>
              <CardDescription>
                Задавайте вопросы и получайте ответы от обоих ассистентов
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 p-0">
              <AIChatPlaceholder />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Информация о проекте</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold">Название</h3>
                <p>{project.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold">Описание</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">{project.description}</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold">Технологический стек</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">{project.techStack}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Часто задаваемые вопросы</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="text-sm">
                  <span className="text-violet-600 hover:underline cursor-pointer">
                    Как добавить авторизацию пользователей?
                  </span>
                </li>
                <li className="text-sm">
                  <span className="text-violet-600 hover:underline cursor-pointer">
                    Оптимизировать запросы к БД
                  </span>
                </li>
                <li className="text-sm">
                  <span className="text-violet-600 hover:underline cursor-pointer">
                    Как реализовать корзину товаров?
                  </span>
                </li>
                <li className="text-sm">
                  <span className="text-violet-600 hover:underline cursor-pointer">
                    Добавить глобальное состояние через Redux
                  </span>
                </li>
                <li className="text-sm">
                  <span className="text-violet-600 hover:underline cursor-pointer">
                    Создать анимированное меню
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Действия</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full" asChild>
                <Link href={`/dashboard/projects/${projectId}`}>
                  Вернуться к проекту
                </Link>
              </Button>
              <Button className="w-full">Открыть редактор кода</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
