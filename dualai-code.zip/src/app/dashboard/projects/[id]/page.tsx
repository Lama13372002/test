import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// В реальном приложении эти данные будут загружаться с сервера по ID проекта
const projectsData: Record<string, {
  id: string;
  name: string;
  description: string;
  lastUpdated: string;
  progress: number;
  status: string;
  techStack: string;
  createdAt: string;
  collaborators: Array<{
    id: string;
    name: string;
    avatar: string;
  }>;
  history: Array<{
    id: string;
    date: string;
    description: string;
  }>;
}> = {
  "1": {
    id: "1",
    name: "Фронтенд e-commerce",
    description: "React приложение для интернет-магазина",
    lastUpdated: "2 дня назад",
    progress: 75,
    status: "in-progress",
    techStack: "React, Redux, Tailwind CSS",
    createdAt: "15.03.2025",
    collaborators: [
      { id: "user1", name: "Алексей П.", avatar: "" },
      { id: "user2", name: "Мария С.", avatar: "" },
    ],
    history: [
      { id: "h1", date: "22.03.2025", description: "Добавлена корзина товаров" },
      { id: "h2", date: "20.03.2025", description: "Улучшена навигация" },
      { id: "h3", date: "18.03.2025", description: "Создан список товаров" },
      { id: "h4", date: "15.03.2025", description: "Проект инициализирован" },
    ],
  },
  "2": {
    id: "2",
    name: "Backend API",
    description: "Node.js REST API для мобильного приложения",
    lastUpdated: "5 дней назад",
    progress: 40,
    status: "in-progress",
    techStack: "Node.js, Express, MongoDB",
    createdAt: "10.03.2025",
    collaborators: [
      { id: "user1", name: "Алексей П.", avatar: "" },
    ],
    history: [
      { id: "h1", date: "19.03.2025", description: "Добавлена аутентификация" },
      { id: "h2", date: "15.03.2025", description: "Созданы базовые эндпоинты" },
      { id: "h3", date: "10.03.2025", description: "Проект инициализирован" },
    ],
  },
  "3": {
    id: "3",
    name: "Лендинг для стартапа",
    description: "Одностраничный лендинг с анимациями",
    lastUpdated: "1 неделю назад",
    progress: 100,
    status: "completed",
    techStack: "HTML, CSS, JavaScript, GSAP",
    createdAt: "05.03.2025",
    collaborators: [
      { id: "user1", name: "Алексей П.", avatar: "" },
      { id: "user3", name: "Дмитрий К.", avatar: "" },
    ],
    history: [
      { id: "h1", date: "17.03.2025", description: "Проект завершен" },
      { id: "h2", date: "15.03.2025", description: "Добавлены анимации" },
      { id: "h3", date: "10.03.2025", description: "Создана структура страницы" },
      { id: "h4", date: "05.03.2025", description: "Проект инициализирован" },
    ],
  },
};

// Для статического экспорта
export function generateStaticParams() {
  return Object.keys(projectsData).map(id => ({ id }));
}

const statusColors: Record<string, string> = {
  "in-progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300",
  "completed": "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300",
  "on-hold": "bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-300",
  "not-found": "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300",
}

const statusLabels: Record<string, string> = {
  "in-progress": "В работе",
  "completed": "Завершён",
  "on-hold": "На паузе",
  "not-found": "Не найден",
}

export default function ProjectPage({ params }: { params: { id: string } }) {
  const projectId = params.id;

  // В реальном приложении здесь был бы запрос к API
  const project = projectsData[projectId] || {
    id: projectId,
    name: "Проект не найден",
    description: "Информация о проекте отсутствует",
    lastUpdated: "-",
    progress: 0,
    status: "not-found",
    techStack: "-",
    createdAt: "-",
    collaborators: [],
    history: [],
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Link href="/dashboard/projects" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>
              <span className="sr-only">Назад</span>
            </Link>
            <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
            <span className={`text-xs font-medium px-2 py-1 rounded-full ${statusColors[project.status]}`}>
              {statusLabels[project.status]}
            </span>
          </div>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            {project.description}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href={`/dashboard/projects/${projectId}/edit`}>
              Редактировать
            </Link>
          </Button>
          <Button size="sm">Открыть в редакторе</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Прогресс</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{project.progress}%</div>
            <div className="mt-2 h-2 w-full rounded-full bg-gray-100 dark:bg-gray-800">
              <div
                className={`h-full rounded-full ${
                  project.status === "completed"
                    ? "bg-green-600"
                    : project.status === "on-hold"
                      ? "bg-amber-600"
                      : "bg-blue-600"
                }`}
                style={{ width: `${project.progress}%` }}
              ></div>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              Последнее обновление: {project.lastUpdated}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Технологии</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-medium">{project.techStack}</div>
            <p className="mt-2 text-xs text-gray-500">
              Проект создан: {project.createdAt}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Участники</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              {project.collaborators.length > 0 ? (
                project.collaborators.map((user) => (
                  <div key={user.id} className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
                      {user.avatar ? (
                        <img src={user.avatar} alt={user.name} className="h-full w-full rounded-full" />
                      ) : (
                        <span className="text-xs font-medium">
                          {user.name.split(" ").map(n => n[0]).join("")}
                        </span>
                      )}
                    </div>
                    <span>{user.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-sm">Нет участников</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Обзор</TabsTrigger>
          <TabsTrigger value="history">История</TabsTrigger>
          <TabsTrigger value="files">Файлы</TabsTrigger>
          <TabsTrigger value="settings">Настройки</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Описание проекта</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{project.description}</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>История изменений</CardTitle>
              <CardDescription>
                Хронология изменений в проекте
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative ml-3 space-y-4 border-l border-gray-200 dark:border-gray-800 py-2">
                {project.history.length > 0 ? (
                  project.history.map((event) => (
                    <div key={event.id} className="mb-4 ml-6">
                      <span className="absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border border-white bg-gray-200 dark:border-gray-900 dark:bg-gray-700"></span>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1">
                        <time className="mb-1 text-sm font-normal leading-none text-gray-500 dark:text-gray-400">
                          {event.date}
                        </time>
                      </div>
                      <p className="text-base font-normal text-gray-600 dark:text-gray-300">
                        {event.description}
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500">История не найдена</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Файлы проекта</CardTitle>
              <CardDescription>
                Структура и файлы проекта
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Файловая структура временно недоступна</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline">Загрузить код</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Настройки проекта</CardTitle>
              <CardDescription>
                Управление настройками проекта
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Настройки проекта временно недоступны</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
