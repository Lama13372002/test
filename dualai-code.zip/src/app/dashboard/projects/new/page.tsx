import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export const metadata = {
  title: "Новый проект - DualAI Code",
  description: "Создайте новый проект в DualAI Code",
}

export default function NewProjectPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Создать новый проект</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Настройте параметры нового проекта или загрузите существующий код
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Детали проекта</CardTitle>
          <CardDescription>
            Основная информация о вашем проекте
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="project-name">Название проекта</Label>
            <Input id="project-name" placeholder="Введите название проекта" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="project-description">Описание</Label>
            <Textarea
              id="project-description"
              placeholder="Краткое описание проекта"
              className="min-h-24"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="project-type">Тип проекта</Label>
            <select
              id="project-type"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              defaultValue=""
            >
              <option value="" disabled>Выберите тип проекта</option>
              <option value="web-frontend">Веб-фронтенд</option>
              <option value="web-backend">Веб-бэкенд</option>
              <option value="full-stack">Фулстек</option>
              <option value="mobile">Мобильное приложение</option>
              <option value="desktop">Десктопное приложение</option>
              <option value="other">Другое</option>
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="tech-stack">Технологический стек</Label>
            <select
              id="tech-stack"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              defaultValue=""
            >
              <option value="" disabled>Выберите основной стек</option>
              <option value="react">React</option>
              <option value="vue">Vue.js</option>
              <option value="angular">Angular</option>
              <option value="next">Next.js</option>
              <option value="node">Node.js</option>
              <option value="django">Django</option>
              <option value="flask">Flask</option>
              <option value="laravel">Laravel</option>
              <option value="react-native">React Native</option>
              <option value="flutter">Flutter</option>
              <option value="other">Другое</option>
            </select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Инициализация проекта</CardTitle>
          <CardDescription>
            Выберите способ создания проекта
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col space-y-4">
            <div className="flex items-start space-x-3">
              <input
                type="radio"
                id="start-new"
                name="project-start"
                className="mt-1 h-4 w-4 rounded-full border-gray-300 text-violet-600 focus:ring-violet-500"
                defaultChecked
              />
              <div>
                <Label htmlFor="start-new" className="font-medium">Начать с нуля</Label>
                <p className="text-sm text-gray-500">Создайте проект с пустой структурой или базовым шаблоном</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <input
                type="radio"
                id="start-template"
                name="project-start"
                className="mt-1 h-4 w-4 rounded-full border-gray-300 text-violet-600 focus:ring-violet-500"
              />
              <div>
                <Label htmlFor="start-template" className="font-medium">Использовать готовый шаблон</Label>
                <p className="text-sm text-gray-500">Выберите один из предустановленных шаблонов проектов</p>

                <div className="mt-2">
                  <select
                    id="template"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    defaultValue=""
                    disabled
                  >
                    <option value="" disabled>Выберите шаблон</option>
                    <option value="react-basic">React - Базовое приложение</option>
                    <option value="react-redux">React + Redux</option>
                    <option value="next-basic">Next.js - Базовое приложение</option>
                    <option value="next-ecommerce">Next.js - E-commerce</option>
                    <option value="node-express-api">Node.js + Express API</option>
                    <option value="django-rest">Django REST API</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <input
                type="radio"
                id="upload-existing"
                name="project-start"
                className="mt-1 h-4 w-4 rounded-full border-gray-300 text-violet-600 focus:ring-violet-500"
              />
              <div>
                <Label htmlFor="upload-existing" className="font-medium">Загрузить существующий код</Label>
                <p className="text-sm text-gray-500">Загрузите архив с кодом для анализа и доработки</p>

                <div className="mt-3">
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="mx-auto h-12 w-12 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                      />
                    </svg>
                    <p className="mt-2 text-sm font-medium">
                      Перетащите файлы сюда или <span className="text-violet-600">выберите файлы</span>
                    </p>
                    <p className="mt-1 text-xs text-gray-500">ZIP, RAR до 50MB</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>AI-ассистенты</CardTitle>
          <CardDescription>
            Настройте ассистентов для вашего проекта
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center space-x-3">
              <div className="size-9 rounded-full bg-violet-100 flex items-center justify-center text-violet-800">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              <div>
                <p className="font-medium">ChatGPT 4.0</p>
                <p className="text-sm text-gray-500">Основной ассистент</p>
              </div>
            </div>
            <input
              type="checkbox"
              className="h-6 w-10 rounded-full bg-gray-300 before:rounded-full before:bg-white dark:bg-gray-600 checked:bg-violet-600 checked:before:translate-x-4 relative before:absolute before:h-5 before:w-5 before:top-[2px] before:left-[2px] transition before:transition"
              defaultChecked
            />
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center space-x-3">
              <div className="size-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-800">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
              </div>
              <div>
                <p className="font-medium">Claude 3.7</p>
                <p className="text-sm text-gray-500">Вторичный ассистент</p>
              </div>
            </div>
            <input
              type="checkbox"
              className="h-6 w-10 rounded-full bg-gray-300 before:rounded-full before:bg-white dark:bg-gray-600 checked:bg-violet-600 checked:before:translate-x-4 relative before:absolute before:h-5 before:w-5 before:top-[2px] before:left-[2px] transition before:transition"
              defaultChecked
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end space-x-4">
        <Button variant="outline" asChild>
          <Link href="/dashboard/projects">Отмена</Link>
        </Button>
        <Button>Создать проект</Button>
      </div>
    </div>
  )
}
