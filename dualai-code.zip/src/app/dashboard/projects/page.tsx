import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"

export const metadata = {
  title: "Проекты - DualAI Code",
  description: "Управление проектами в DualAI Code",
}

export default function ProjectsPage() {
  // Демо-данные для проектов (в реальном приложении будут загружаться с сервера)
  const projects = [
    {
      id: "1",
      name: "Фронтенд e-commerce",
      description: "React приложение для интернет-магазина",
      lastUpdated: "2 дня назад",
      progress: 75,
      status: "in-progress",
    },
    {
      id: "2",
      name: "Backend API",
      description: "Node.js REST API для мобильного приложения",
      lastUpdated: "5 дней назад",
      progress: 40,
      status: "in-progress",
    },
    {
      id: "3",
      name: "Лендинг для стартапа",
      description: "Одностраничный лендинг с анимациями",
      lastUpdated: "1 неделю назад",
      progress: 100,
      status: "completed",
    },
    {
      id: "4",
      name: "Приложение для планирования",
      description: "React/Redux приложение для планирования задач",
      lastUpdated: "2 недели назад",
      progress: 90,
      status: "in-progress",
    },
    {
      id: "5",
      name: "Документация API",
      description: "Создание документации с помощью Swagger",
      lastUpdated: "3 недели назад",
      progress: 60,
      status: "on-hold",
    },
    {
      id: "6",
      name: "Библиотека компонентов",
      description: "UI компоненты для будущих проектов",
      lastUpdated: "1 месяц назад",
      progress: 100,
      status: "completed",
    },
    {
      id: "7",
      name: "Админ-панель",
      description: "Панель управления для интернет-магазина",
      lastUpdated: "5 недель назад",
      progress: 20,
      status: "on-hold",
    },
  ]

  const inProgressProjects = projects.filter(project => project.status === "in-progress")
  const completedProjects = projects.filter(project => project.status === "completed")
  const onHoldProjects = projects.filter(project => project.status === "on-hold")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Проекты</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Управляйте своими проектами и начинайте новые
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/projects/new">Новый проект</Link>
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Input
            placeholder="Поиск проектов..."
            className="max-w-sm"
          />
          <Button variant="outline" size="icon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
              />
            </svg>
            <span className="sr-only">Фильтры</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full md:w-[600px] grid-cols-4">
          <TabsTrigger value="all">Все ({projects.length})</TabsTrigger>
          <TabsTrigger value="in-progress">В работе ({inProgressProjects.length})</TabsTrigger>
          <TabsTrigger value="completed">Завершённые ({completedProjects.length})</TabsTrigger>
          <TabsTrigger value="on-hold">На паузе ({onHoldProjects.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="in-progress" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {inProgressProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {completedProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="on-hold" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {onHoldProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function ProjectCard({ project }) {
  const statusColors = {
    "in-progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300",
    "completed": "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300",
    "on-hold": "bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-300",
  }

  const statusLabels = {
    "in-progress": "В работе",
    "completed": "Завершён",
    "on-hold": "На паузе",
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="mb-1">{project.name}</CardTitle>
            <CardDescription>{project.description}</CardDescription>
          </div>
          <span className={`text-xs font-medium px-2 py-1 rounded-full ${statusColors[project.status]}`}>
            {statusLabels[project.status]}
          </span>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="mb-1 flex items-center justify-between text-sm">
          <span>Прогресс</span>
          <span className="font-medium">{project.progress}%</span>
        </div>
        <div className="h-2 w-full rounded-full bg-gray-100 dark:bg-gray-800">
          <div
            className={`h-full rounded-full ${
              project.status === "completed"
                ? "bg-green-600"
                : project.status === "on-hold"
                  ? "bg-amber-600"
                  : "bg-blue-600"
            }`}
            style={{ width: `${project.progress}%` }}
          ></div>
        </div>
        <div className="mt-4 text-xs text-gray-500">
          Последнее обновление: {project.lastUpdated}
        </div>

        <div className="mt-4 flex gap-2">
          <Button size="sm" variant="outline" className="w-full" asChild>
            <Link href={`/dashboard/projects/${project.id}`}>Подробнее</Link>
          </Button>
          <Button size="sm" className="w-full" asChild>
            <Link href={`/dashboard/projects/${project.id}/edit`}>Открыть</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
