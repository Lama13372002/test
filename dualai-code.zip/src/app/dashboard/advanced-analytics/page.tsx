import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Расширенная аналитика - DualAI Code",
  description: "Расширенная аналитика для премиум пользователей DualAI Code",
}

export default function AdvancedAnalyticsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Расширенная аналитика</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Детальный анализ использования и производительности проектов
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Использование токенов</CardTitle>
            <CardDescription>За 30 дней</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">28,452</div>
            <p className="text-xs text-gray-500">+4.25% по сравнению с прошлым месяцем</p>
            <div className="mt-4 h-[120px] w-full bg-gray-100 dark:bg-gray-800 rounded-md flex items-end p-2">
              {[45, 30, 60, 80, 65, 75, 50, 70, 90, 65, 80, 70].map((height, i) => (
                <div
                  key={i}
                  className="flex-1 mx-[1px] bg-violet-500"
                  style={{ height: `${height}%` }}
                ></div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Распределение моделей</CardTitle>
            <CardDescription>ChatGPT vs. Claude</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center h-[180px]">
              <div className="relative w-40 h-40">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-sm font-medium">Всего</div>
                    <div className="text-lg font-bold">8,432</div>
                  </div>
                </div>
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="12"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#8b5cf6"
                    strokeWidth="12"
                    strokeDasharray="251.2"
                    strokeDashoffset="100.48"
                    style={{ transform: "rotate(-90deg)", transformOrigin: "center" }}
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="12"
                    strokeDasharray="251.2"
                    strokeDashoffset="175.84"
                    style={{ transform: "rotate(150.72deg)", transformOrigin: "center" }}
                  />
                </svg>
              </div>
            </div>
            <div className="flex justify-between mt-4 text-sm">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-violet-500 mr-2"></div>
                <span>ChatGPT (60%)</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-emerald-500 mr-2"></div>
                <span>Claude (40%)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Производительность</CardTitle>
            <CardDescription>Среднее время генерации</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.8 сек.</div>
            <p className="text-xs text-gray-500">-0.3 сек. по сравнению с прошлой неделей</p>
            <div className="mt-4 space-y-2">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>ChatGPT</span>
                  <span>1.2 сек.</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700">
                  <div className="bg-violet-500 h-2 rounded-full" style={{ width: "60%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Claude</span>
                  <span>2.6 сек.</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700">
                  <div className="bg-emerald-500 h-2 rounded-full" style={{ width: "85%" }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Топ проекты по использованию</CardTitle>
            <CardDescription>Проекты с наибольшим потреблением ресурсов</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "E-commerce Platform", usage: "7,245", percent: 28 },
                { name: "Mobile App Backend", usage: "4,891", percent: 19 },
                { name: "Admin Dashboard", usage: "3,760", percent: 15 },
                { name: "API Documentation", usage: "2,504", percent: 10 },
                { name: "Landing Page", usage: "1,873", percent: 7 },
              ].map((project, i) => (
                <div key={i} className="flex items-center">
                  <div className="w-4 text-gray-500">{i + 1}.</div>
                  <div className="ml-2 flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">{project.name}</span>
                      <span className="text-sm text-gray-500">{project.usage}</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-1.5 dark:bg-gray-700">
                      <div
                        className="bg-violet-500 h-1.5 rounded-full"
                        style={{ width: `${project.percent}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Эффективность запросов</CardTitle>
            <CardDescription>Анализ улучшения кода</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Качество кода</span>
                  <span className="text-sm font-medium">78%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "78%" }}></div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Код соответствует стандартам и лучшим практикам</p>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Производительность</span>
                  <span className="text-sm font-medium">65%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: "65%" }}></div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Оптимизация операций и потребления ресурсов</p>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Безопасность</span>
                  <span className="text-sm font-medium">92%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 dark:bg-gray-700">
                  <div className="bg-violet-500 h-2 rounded-full" style={{ width: "92%" }}></div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Защита от уязвимостей и соблюдение практик безопасности</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <p className="text-center text-sm text-gray-500 mt-6">
        Эти данные доступны только для премиум-пользователей.{" "}
        <Link href="/pricing" className="text-violet-600 hover:underline">
          Узнать больше о преимуществах премиум-подписки
        </Link>
      </p>
    </div>
  )
}
