import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Личный кабинет - DualAI Code",
  description: "Управляйте своими проектами и настройками в личном кабинете DualAI Code",
}

export default function DashboardPage() {
  // Демо-данные для проектов (в реальном приложении будут загружаться с сервера)
  const recentProjects = [
    {
      id: "1",
      name: "Фронтенд e-commerce",
      description: "React приложение для интернет-магазина",
      lastUpdated: "2 дня назад",
      progress: 75,
    },
    {
      id: "2",
      name: "Backend API",
      description: "Node.js REST API для мобильного приложения",
      lastUpdated: "5 дней назад",
      progress: 40,
    },
    {
      id: "3",
      name: "Лендинг для стартапа",
      description: "Одностраничный лендинг с анимациями",
      lastUpdated: "1 неделю назад",
      progress: 100,
    },
  ]

  const stats = [
    {
      title: "Активные проекты",
      value: "3",
      description: "2 в процессе, 1 завершен",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-violet-600"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
          />
        </svg>
      ),
    },
    {
      title: "Использовано токенов",
      value: "8,547",
      description: "из 10,000 (базовый план)",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-violet-600"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      ),
    },
    {
      title: "Сохранённых проектов",
      value: "12",
      description: "всего за все время",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-violet-600"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
          />
        </svg>
      ),
    },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Добро пожаловать, Пользователь!</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Управляйте своими проектами и настройками в личном кабинете
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <div className="h-9 w-9 rounded-lg bg-violet-100 p-2 dark:bg-violet-900/20">
                {stat.icon}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-gray-500 dark:text-gray-400">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Недавние проекты</h2>
          <Button variant="outline" size="sm" asChild>
            <Link href="/dashboard/projects">Все проекты</Link>
          </Button>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {recentProjects.map((project) => (
            <Card key={project.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle>{project.name}</CardTitle>
                <CardDescription>{project.description}</CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span>Прогресс</span>
                  <span className="font-medium">{project.progress}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-gray-100 dark:bg-gray-800">
                  <div
                    className="h-full rounded-full bg-violet-600"
                    style={{ width: `${project.progress}%` }}
                  ></div>
                </div>
                <div className="mt-4 text-xs text-gray-500">
                  Последнее обновление: {project.lastUpdated}
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Button className="w-full" asChild>
                  <Link href={`/dashboard/projects/${project.id}`}>Открыть проект</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Ваш текущий план</CardTitle>
            <CardDescription>Базовый пользователь</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4 text-green-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                10,000 токенов в месяц
              </li>
              <li className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4 text-green-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                До 5 проектов одновременно
              </li>
              <li className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2 h-4 w-4 text-green-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Базовая поддержка
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/pricing">Изменить план</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Быстрые действия</CardTitle>
            <CardDescription>Создавайте проекты и управляйте ими</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full" asChild>
              <Link href="/dashboard/projects/new">Создать новый проект</Link>
            </Button>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/upload-code">Загрузить существующий код</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
