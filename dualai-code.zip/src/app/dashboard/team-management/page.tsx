import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"

export const metadata = {
  title: "Управление командой - DualAI Code",
  description: "Управление членами команды и их ролями в DualAI Code",
}

const teamMembers = [
  {
    id: "1",
    name: "Петр Кузнецов",
    email: "p.kuznetsov@example.com",
    role: "Владелец",
    lastActive: "Сейчас",
    avatar: "",
  },
  {
    id: "2",
    name: "Алексей Петров",
    email: "a.petrov@example.com",
    role: "Администратор",
    lastActive: "2 часа назад",
    avatar: "",
  },
  {
    id: "3",
    name: "Мария Смирнова",
    email: "m.smirnova@example.com",
    role: "Разработчик",
    lastActive: "1 день назад",
    avatar: "",
  },
  {
    id: "4",
    name: "Дмитрий Козлов",
    email: "d.kozlov@example.com",
    role: "Разработчик",
    lastActive: "3 дня назад",
    avatar: "",
  },
  {
    id: "5",
    name: "Анна Иванова",
    email: "a.ivanova@example.com",
    role: "Наблюдатель",
    lastActive: "1 неделю назад",
    avatar: "",
  },
];

const pendingInvites = [
  {
    id: "1",
    email: "s.sidorov@example.com",
    role: "Разработчик",
    sentAt: "2 дня назад",
  },
  {
    id: "2",
    email: "i.popov@example.com",
    role: "Наблюдатель",
    sentAt: "5 дней назад",
  },
];

export default function TeamManagementPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Управление командой</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Приглашайте и управляйте доступом членов вашей команды
        </p>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
          <div>
            <CardTitle>Члены команды</CardTitle>
            <CardDescription>
              Управляйте доступом пользователей к вашим проектам
            </CardDescription>
          </div>
          <Button>Пригласить пользователя</Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Input
                placeholder="Поиск по имени или email"
                className="max-w-sm"
              />
              <select className="h-10 rounded-md border border-input bg-background px-3 py-2">
                <option value="all">Все роли</option>
                <option value="owner">Владелец</option>
                <option value="admin">Администратор</option>
                <option value="developer">Разработчик</option>
                <option value="viewer">Наблюдатель</option>
              </select>
            </div>

            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-800">
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Пользователь</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Роль</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Последняя активность</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Действия</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {teamMembers.map((member) => (
                    <tr key={member.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={member.avatar} alt={member.name} />
                            <AvatarFallback>
                              {member.name.split(" ").map(n => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{member.name}</div>
                            <div className="text-sm text-gray-500">{member.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            member.role === "Владелец"
                              ? "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
                              : member.role === "Администратор"
                                ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                                : member.role === "Разработчик"
                                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                                  : "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300"
                          }`}>
                            {member.role}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300">
                        {member.lastActive}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {member.role !== "Владелец" && (
                          <div className="flex items-center justify-end gap-2">
                            <select className="h-8 rounded-md border border-input bg-background px-2 py-1 text-xs">
                              <option value="" disabled>Изменить роль</option>
                              <option value="admin">Администратор</option>
                              <option value="developer">Разработчик</option>
                              <option value="viewer">Наблюдатель</option>
                            </select>
                            <Button variant="outline" size="sm" className="text-red-500 h-8">Удалить</Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ожидающие приглашения</CardTitle>
          <CardDescription>
            Пользователи, которым отправлены приглашения, но они еще не присоединились
          </CardDescription>
        </CardHeader>
        <CardContent>
          {pendingInvites.length > 0 ? (
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-800">
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Email</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Роль</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Отправлено</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Действия</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {pendingInvites.map((invite) => (
                    <tr key={invite.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                      <td className="px-4 py-3 text-sm">
                        {invite.email}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            invite.role === "Администратор"
                              ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                              : invite.role === "Разработчик"
                                ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                                : "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300"
                          }`}>
                            {invite.role}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300">
                        {invite.sentAt}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="outline" size="sm" className="h-8">Повторить</Button>
                          <Button variant="outline" size="sm" className="text-red-500 h-8">Отменить</Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500">Нет ожидающих приглашений</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Настройки команды</CardTitle>
          <CardDescription>
            Управляйте доступом и разрешениями для вашей команды
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Разрешить редактирование проектов</p>
              <p className="text-sm text-gray-500">
                Разрешить разработчикам редактировать любые проекты команды
              </p>
            </div>
            <div className="relative inline-flex h-[24px] w-[44px] cursor-pointer rounded-full bg-gray-200 transition-colors duration-200 ease-in-out dark:bg-gray-700">
              <span className="inline-block h-[20px] w-[20px] transform rounded-full bg-white transition duration-200 ease-in-out translate-x-[22px] translate-y-[2px]"></span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Разрешить создание проектов</p>
              <p className="text-sm text-gray-500">
                Разрешить разработчикам создавать новые проекты
              </p>
            </div>
            <div className="relative inline-flex h-[24px] w-[44px] cursor-pointer rounded-full bg-violet-600 transition-colors duration-200 ease-in-out dark:bg-violet-700">
              <span className="inline-block h-[20px] w-[20px] transform rounded-full bg-white transition duration-200 ease-in-out translate-x-[22px] translate-y-[2px]"></span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Разрешить приглашение пользователей</p>
              <p className="text-sm text-gray-500">
                Разрешить администраторам приглашать новых пользователей
              </p>
            </div>
            <div className="relative inline-flex h-[24px] w-[44px] cursor-pointer rounded-full bg-violet-600 transition-colors duration-200 ease-in-out dark:bg-violet-700">
              <span className="inline-block h-[20px] w-[20px] transform rounded-full bg-white transition duration-200 ease-in-out translate-x-[22px] translate-y-[2px]"></span>
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-sm text-gray-500 mt-6">
        Управление командой доступно только для премиум-пользователей.{" "}
        <Link href="/pricing" className="text-violet-600 hover:underline">
          Узнать больше о преимуществах премиум-подписки
        </Link>
      </p>
    </div>
  )
}
