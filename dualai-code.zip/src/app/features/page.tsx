import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Возможности DualAI Code - Коллаборативная разработка с AI",
  description: "Узнайте о всех возможностях платформы DualAI Code для разработки кода с использованием двух AI-моделей",
}

export default function FeaturesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-24 md:py-32 bg-gradient-to-br from-violet-900/10 via-background to-blue-900/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                Возможности{" "}
                <span className="bg-gradient-to-r from-violet-600 to-blue-600 text-transparent bg-clip-text">
                  DualAI Code
                </span>
              </h1>
              <p className="mx-auto max-w-[800px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Исследуйте уникальные функции нашей платформы, которые делают разработку кода
                быстрее, эффективнее и качественнее с помощью синергии двух AI-моделей.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Features Section */}
      <section className="w-full py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                Основные возможности
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Коллаборативный искусственный интеллект
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Наша платформа объединяет мощь ChatGPT и Claude 3.7 для создания непревзойденного опыта разработки
              </p>
            </div>
          </div>

          <div className="mx-auto grid gap-8 py-12 md:grid-cols-2">
            <Card className="border-2 border-violet-200 dark:border-violet-900/50">
              <CardHeader>
                <CardTitle className="text-2xl">AI-коллаборация</CardTitle>
                <CardDescription className="text-base">
                  Уникальная система взаимодействия между моделями
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4 text-gray-500 dark:text-gray-400">
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Параллельная работа моделей</strong> — AI-модели работают над разными компонентами проекта одновременно
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Обмен знаниями</strong> — модели делятся своими выводами и решениями для достижения лучшего результата
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Визуализация взаимодействия</strong> — наблюдайте за процессом общения между моделями в реальном времени
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Интеллектуальное распределение задач</strong> — система автоматически определяет, какая модель лучше справится с конкретной задачей
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-200 dark:border-blue-900/50">
              <CardHeader>
                <CardTitle className="text-2xl">Система проверки кода</CardTitle>
                <CardDescription className="text-base">
                  Многоуровневый подход к обеспечению качества
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4 text-gray-500 dark:text-gray-400">
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Взаимный код-ревью</strong> — каждая модель проверяет код, написанный другой моделью
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Автоматический статический анализ</strong> — выявление потенциальных ошибок и проблем с производительностью
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Проверка безопасности</strong> — анализ кода на наличие уязвимостей и рисков безопасности
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="rounded-full bg-green-500/20 p-1">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L5.33333 10.6667L3 8.33333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <span>
                      <strong>Безопасное выполнение кода</strong> — тестирование в изолированной среде для проверки функциональности
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Secondary Features Section */}
      <section className="w-full py-16 md:py-24 bg-gradient-to-br from-background via-violet-900/10 to-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                Дополнительные возможности
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Продвинутые инструменты для разработки
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                DualAI Code предоставляет полный набор инструментов для эффективной разработки кода
              </p>
            </div>
          </div>

          <div className="mx-auto grid gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Редактор кода</CardTitle>
                <CardDescription>
                  Мощный редактор с современными функциями
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• Интеграция Monaco Editor</li>
                  <li>• Подсветка синтаксиса для всех языков</li>
                  <li>• Интеллектуальное автодополнение</li>
                  <li>• Маркировка кода от разных моделей</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Контроль версий</CardTitle>
                <CardDescription>
                  Полноценная система управления историей кода
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• Автоматическое создание версий</li>
                  <li>• Комментарии от обеих моделей</li>
                  <li>• Визуализация изменений</li>
                  <li>• Возможность отката к предыдущим версиям</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Обучающие функции</CardTitle>
                <CardDescription>
                  Повышайте свои навыки программирования
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• Детальные комментарии к коду</li>
                  <li>• Объяснение принятых решений</li>
                  <li>• Альтернативные подходы к решению</li>
                  <li>• Библиотека образцов кода</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Многоязычная поддержка</CardTitle>
                <CardDescription>
                  Разработка на любых популярных языках
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• JavaScript и TypeScript</li>
                  <li>• Python и Ruby</li>
                  <li>• Java, C# и C++</li>
                  <li>• Golang, Rust и многие другие</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Управление проектами</CardTitle>
                <CardDescription>
                  Организация работы над проектами
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• Создание различных типов проектов</li>
                  <li>• Управление файловой структурой</li>
                  <li>• Отслеживание прогресса</li>
                  <li>• Экспорт готового кода</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Интеграции</CardTitle>
                <CardDescription>
                  Работа с популярными инструментами
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                  <li>• GitHub и GitLab</li>
                  <li>• Jira и Trello</li>
                  <li>• Docker и Kubernetes</li>
                  <li>• CI/CD системы</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
