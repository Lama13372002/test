import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-24 md:py-32 lg:py-40 bg-gradient-to-br from-violet-900/10 via-background to-blue-900/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                Разработка кода в синергии с{" "}
                <span className="bg-gradient-to-r from-violet-600 to-blue-600 text-transparent bg-clip-text">
                  двумя AI-моделями
                </span>
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                DualAI Code объединяет мощь ChatGPT и Claude 3.7 для создания качественного, проверенного и
                оптимизированного кода. Ускорьте свою разработку и получите лучшие результаты.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <Link href="/register">Начать бесплатно</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/demo">Смотреть демо</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                Возможности
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Превосходство двойного интеллекта
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Наша платформа использует уникальный подход с двумя AI-моделями, которые взаимодействуют и
                дополняют друг друга.
              </p>
            </div>
          </div>
          <div className="mx-auto grid gap-6 py-12 md:grid-cols-2 lg:grid-cols-3 lg:gap-10">
            <Card>
              <CardHeader>
                <CardTitle>Парная разработка</CardTitle>
                <CardDescription>
                  ChatGPT и Claude 3.7 работают вместе, каждая модель фокусируется на своих сильных сторонах
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Две AI-модели анализируют задачу с разных перспектив, обмениваются идеями и находят
                  оптимальные решения, как опытные разработчики в паре.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Взаимная проверка кода</CardTitle>
                <CardDescription>
                  Каждая строка кода проверяется обеими моделями для обеспечения качества
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  После написания кода одной моделью, вторая проводит тщательный код-ревью, выявляя
                  потенциальные проблемы и предлагая улучшения.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Подробные комментарии</CardTitle>
                <CardDescription>
                  Документируйте код с пояснениями от обеих моделей
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Каждый компонент и функция сопровождаются детальными комментариями, объясняющими логику
                  и принятые решения для лучшего понимания кода.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Оптимизация производительности</CardTitle>
                <CardDescription>
                  Автоматическая оптимизация кода для лучшей производительности
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  AI-модели анализируют код и предлагают оптимизации для улучшения скорости работы,
                  уменьшения потребления ресурсов и повышения масштабируемости.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Различные языки программирования</CardTitle>
                <CardDescription>
                  Поддержка всех популярных языков и фреймворков
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  От JavaScript и Python до Rust и Golang — DualAI Code помогает с разработкой на любом
                  современном языке программирования и технологическом стеке.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Обучающий эффект</CardTitle>
                <CardDescription>
                  Улучшайте свои навыки, наблюдая за работой двух AI-моделей
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Наблюдение за процессом создания и улучшения кода двумя различными AI-моделями помогает
                  понять различные подходы к решению задач и улучшить свои навыки программирования.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="w-full py-16 md:py-24 bg-gradient-to-br from-violet-900/10 via-background to-blue-900/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                Процесс работы
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Как работает DualAI Code
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Ознакомьтесь с процессом разработки кода с использованием двух AI-моделей
              </p>
            </div>
          </div>
          <div className="mx-auto grid gap-6 py-12 md:grid-cols-2 lg:grid-cols-4 lg:gap-10">
            <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
              <div className="flex size-12 items-center justify-center rounded-full bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-400">
                1
              </div>
              <h3 className="text-lg font-bold">Создайте задачу</h3>
              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                Опишите ваш проект и требования к коду
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
              <div className="flex size-12 items-center justify-center rounded-full bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-400">
                2
              </div>
              <h3 className="text-lg font-bold">AI-модели обсуждают</h3>
              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                ChatGPT и Claude 3.7 анализируют задачу и планируют решение
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
              <div className="flex size-12 items-center justify-center rounded-full bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-400">
                3
              </div>
              <h3 className="text-lg font-bold">Создание и проверка</h3>
              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                Модели пишут код и выполняют взаимную проверку
              </p>
            </div>
            <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
              <div className="flex size-12 items-center justify-center rounded-full bg-violet-100 text-violet-900 dark:bg-violet-900/20 dark:text-violet-400">
                4
              </div>
              <h3 className="text-lg font-bold">Получите результат</h3>
              <p className="text-center text-sm text-gray-500 dark:text-gray-400">
                Загрузите готовый, проверенный и оптимизированный код
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Начните использовать DualAI Code сегодня
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Присоединяйтесь к тысячам разработчиков, которые уже оценили преимущества коллаборативной
                разработки с AI-моделями
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <Link href="/register">Создать аккаунт</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/pricing">Посмотреть тарифы</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
