import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Демонстрация - DualAI Code",
  description: "Посмотрите, как работает DualAI Code с использованием двух AI-моделей для разработки кода",
}

export default function DemoPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-16 md:py-24 bg-gradient-to-br from-violet-900/10 via-background to-blue-900/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">
                Демонстрация работы{" "}
                <span className="bg-gradient-to-r from-violet-600 to-blue-600 text-transparent bg-clip-text">
                  DualAI Code
                </span>
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Посмотрите, как две AI-модели (ChatGPT и Claude 3.7) взаимодействуют для создания
                качественного кода и решения задач программирования.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Interface Section */}
      <section className="w-full py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="working" className="w-full">
            <TabsList className="grid w-full md:w-[400px] grid-cols-2 mx-auto mb-8">
              <TabsTrigger value="working">Процесс работы</TabsTrigger>
              <TabsTrigger value="result">Результат</TabsTrigger>
            </TabsList>

            <TabsContent value="working" className="space-y-8">
              <h2 className="text-2xl font-bold text-center">Процесс взаимодействия моделей</h2>

              <div className="grid gap-6 md:grid-cols-2">
                <Card className="border-2 border-violet-200 dark:border-violet-900/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className="size-6 rounded-full bg-violet-100 flex items-center justify-center text-violet-800">
                        <span className="text-xs font-bold">G</span>
                      </div>
                      ChatGPT
                    </CardTitle>
                    <CardDescription>Ведущая модель в этом проекте</CardDescription>
                  </CardHeader>
                  <CardContent className="h-96 overflow-y-auto border-t p-4 text-sm">
                    <div className="space-y-4">
                      <div className="rounded-lg bg-violet-50 dark:bg-violet-900/20 p-3">
                        <p>Анализирую задачу: нам нужно создать функцию для сортировки массива объектов по нескольким параметрам.</p>
                      </div>
                      <div className="rounded-lg bg-violet-50 dark:bg-violet-900/20 p-3">
                        <p>Предлагаю использовать функцию высшего порядка, которая будет принимать ключи для сортировки и порядок сортировки.</p>
                        <pre className="bg-black/5 dark:bg-white/5 mt-2 p-2 rounded text-xs overflow-x-auto">
{`function multiSort(arr, sortConfig) {
  return [...arr].sort((a, b) => {
    for (const { key, order } of sortConfig) {
      if (a[key] !== b[key]) {
        return order === 'asc'
          ? a[key] > b[key] ? 1 : -1
          : a[key] > b[key] ? -1 : 1;
      }
    }
    return 0;
  });
}`}
                        </pre>
                      </div>
                      <div className="rounded-lg bg-violet-50 dark:bg-violet-900/20 p-3">
                        <p>Моя функция предлагает гибкую настройку сортировки, но я не уверен, что она правильно обрабатывает все типы данных. Claude, что ты думаешь?</p>
                      </div>
                      <div className="rounded-lg bg-violet-50 dark:bg-violet-900/20 p-3">
                        <p>Соглашаюсь с предложением Claude добавить проверку типов и сделать функцию более универсальной. Вот обновленный вариант:</p>
                        <pre className="bg-black/5 dark:bg-white/5 mt-2 p-2 rounded text-xs overflow-x-auto">
{`function multiSort(arr, sortConfig) {
  if (!Array.isArray(arr) || arr.length === 0) return [];
  if (!Array.isArray(sortConfig) || sortConfig.length === 0) return [...arr];

  return [...arr].sort((a, b) => {
    for (const { key, order } of sortConfig) {
      const aValue = a[key];
      const bValue = b[key];

      // Skip if both values are undefined or null
      if ((aValue === undefined || aValue === null) &&
          (bValue === undefined || bValue === null)) {
        continue;
      }

      // Handle cases where only one value is undefined or null
      if (aValue === undefined || aValue === null) return order === 'asc' ? 1 : -1;
      if (bValue === undefined || bValue === null) return order === 'asc' ? -1 : 1;

      if (aValue !== bValue) {
        // Handle different data types appropriately
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return order === 'asc'
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }

        return order === 'asc'
          ? aValue > bValue ? 1 : -1
          : aValue > bValue ? -1 : 1;
      }
    }
    return 0;
  });
}`}
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-blue-200 dark:border-blue-900/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className="size-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-800">
                        <span className="text-xs font-bold">C</span>
                      </div>
                      Claude 3.7
                    </CardTitle>
                    <CardDescription>Поддерживающая модель в этом проекте</CardDescription>
                  </CardHeader>
                  <CardContent className="h-96 overflow-y-auto border-t p-4 text-sm">
                    <div className="space-y-4">
                      <div className="rounded-lg bg-blue-50 dark:bg-blue-900/20 p-3">
                        <p>Проанализировал задачу и предложение ChatGPT. Функция multiSort выглядит хорошо, но я вижу несколько возможных улучшений:</p>
                      </div>
                      <div className="rounded-lg bg-blue-50 dark:bg-blue-900/20 p-3">
                        <p>Функция не обрабатывает следующие случаи:</p>
                        <ul className="list-disc pl-5 mt-1 space-y-1">
                          <li>Пустые массивы или отсутствие конфигурации сортировки</li>
                          <li>Различные типы данных (например, строки нужно сравнивать через localeCompare)</li>
                          <li>Отсутствующие значения (undefined или null)</li>
                        </ul>
                      </div>
                      <div className="rounded-lg bg-blue-50 dark:bg-blue-900/20 p-3">
                        <p>Предлагаю улучшить функцию, добавив проверку типов данных и обработку краевых случаев.</p>
                      </div>
                      <div className="rounded-lg bg-blue-50 dark:bg-blue-900/20 p-3">
                        <p>Отличное улучшение от ChatGPT! Я бы только добавил документацию и пару примеров использования, чтобы функция была более понятной:</p>
                        <pre className="bg-black/5 dark:bg-white/5 mt-2 p-2 rounded text-xs overflow-x-auto">
{`/**
 * Сортирует массив объектов по нескольким параметрам
 * @param {Array} arr - Исходный массив объектов
 * @param {Array} sortConfig - Массив конфигураций сортировки [{key: string, order: 'asc'|'desc'}]
 * @return {Array} Новый отсортированный массив
 *
 * @example
 * const users = [
 *   { name: "John", age: 30, role: "admin" },
 *   { name: "Alice", age: 25, role: "user" },
 *   { name: "Bob", age: 25, role: "admin" }
 * ];
 *
 * // Сортировка сначала по роли (по возрастанию), затем по возрасту (по убыванию)
 * const sorted = multiSort(users, [
 *   { key: "role", order: "asc" },
 *   { key: "age", order: "desc" }
 * ]);
 */`}
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  В реальном сервисе вы увидите полное взаимодействие моделей, которые вместе разрабатывают код,
                  обсуждают решения и находят оптимальные подходы к реализации ваших задач.
                </p>
                <Button asChild>
                  <Link href="/register">Попробовать бесплатно</Link>
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="result" className="space-y-8">
              <h2 className="text-2xl font-bold text-center">Результат совместной работы</h2>

              <Card>
                <CardHeader>
                  <CardTitle>Итоговая функция multiSort</CardTitle>
                  <CardDescription>Функция для сортировки массива объектов по нескольким параметрам</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded bg-black p-4 text-green-400 font-mono text-sm overflow-x-auto">
<pre>{`/**
 * Сортирует массив объектов по нескольким параметрам
 * @param {Array} arr - Исходный массив объектов
 * @param {Array} sortConfig - Массив конфигураций сортировки [{key: string, order: 'asc'|'desc'}]
 * @return {Array} Новый отсортированный массив
 *
 * @example
 * const users = [
 *   { name: "John", age: 30, role: "admin" },
 *   { name: "Alice", age: 25, role: "user" },
 *   { name: "Bob", age: 25, role: "admin" }
 * ];
 *
 * // Сортировка сначала по роли (по возрастанию), затем по возрасту (по убыванию)
 * const sorted = multiSort(users, [
 *   { key: "role", order: "asc" },
 *   { key: "age", order: "desc" }
 * ]);
 */
function multiSort(arr, sortConfig) {
  if (!Array.isArray(arr) || arr.length === 0) return [];
  if (!Array.isArray(sortConfig) || sortConfig.length === 0) return [...arr];

  return [...arr].sort((a, b) => {
    for (const { key, order } of sortConfig) {
      const aValue = a[key];
      const bValue = b[key];

      // Skip if both values are undefined or null
      if ((aValue === undefined || aValue === null) &&
          (bValue === undefined || bValue === null)) {
        continue;
      }

      // Handle cases where only one value is undefined or null
      if (aValue === undefined || aValue === null) return order === 'asc' ? 1 : -1;
      if (bValue === undefined || bValue === null) return order === 'asc' ? -1 : 1;

      if (aValue !== bValue) {
        // Handle different data types appropriately
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return order === 'asc'
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }

        return order === 'asc'
          ? aValue > bValue ? 1 : -1
          : aValue > bValue ? -1 : 1;
      }
    }
    return 0;
  });
}`}</pre>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Пример использования</CardTitle>
                  <CardDescription>Демонстрация работы функции на реальных данных</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded bg-black p-4 text-green-400 font-mono text-sm overflow-x-auto">
<pre>{`// Тестовые данные
const users = [
  { name: "John", age: 30, role: "admin", active: true },
  { name: "Alice", age: 25, role: "user", active: true },
  { name: "Bob", age: 25, role: "admin", active: false },
  { name: "Mary", age: 28, role: "user", active: true },
  { name: "David", age: 32, role: "admin", active: true },
  { name: "Sarah", age: 25, role: "user", active: false }
];

// Сортировка по нескольким полям
const sortedByRoleAndAge = multiSort(users, [
  { key: "role", order: "asc" },
  { key: "age", order: "desc" }
]);

console.log("Sorted by role (asc) and age (desc):");
console.log(sortedByRoleAndAge);

// Результат:
// [
//   { name: "David", age: 32, role: "admin", active: true },
//   { name: "John", age: 30, role: "admin", active: true },
//   { name: "Bob", age: 25, role: "admin", active: false },
//   { name: "Mary", age: 28, role: "user", active: true },
//   { name: "Alice", age: 25, role: "user", active: true },
//   { name: "Sarah", age: 25, role: "user", active: false }
// ]

// Сортировка по активности и имени
const sortedByActiveAndName = multiSort(users, [
  { key: "active", order: "desc" },
  { key: "name", order: "asc" }
]);

console.log("\\nSorted by active status (desc) and name (asc):");
console.log(sortedByActiveAndName);

// Результат:
// [
//   { name: "Alice", age: 25, role: "user", active: true },
//   { name: "David", age: 32, role: "admin", active: true },
//   { name: "John", age: 30, role: "admin", active: true },
//   { name: "Mary", age: 28, role: "user", active: true },
//   { name: "Bob", age: 25, role: "admin", active: false },
//   { name: "Sarah", age: 25, role: "user", active: false }
// ]`}</pre>
                  </div>
                </CardContent>
              </Card>

              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  Это только один пример того, как две AI-модели могут совместно разрабатывать код.
                  Наш сервис позволяет решать гораздо более сложные задачи, от создания компонентов
                  React до разработки полноценных приложений и микросервисов.
                </p>
                <Button asChild>
                  <Link href="/register">Начать создавать код вместе с AI</Link>
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
