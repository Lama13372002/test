#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import time
import sqlite3
import sys
import warnings

# Handle missing dependencies gracefully
try:
    import pyotp
except ImportError:
    warnings.warn("pyotp library not found. Using fallback implementation for TOTP.")
    pyotp = None

try:
    import qrcode
    from io import BytesIO
    qrcode_available = True
except ImportError:
    warnings.warn("qrcode library not found. QR code generation will be disabled.")
    qrcode_available = False

def generate_totp_secret():
    """Generate a random secret for TOTP"""
    if pyotp:
        # Use pyotp's random_base32 for standards-compliant secret generation
        return pyotp.random_base32()
    else:
        # Fallback implementation if pyotp is not available
        return base64.b32encode(secrets.token_bytes(20)).decode('utf-8')

def generate_totp_uri(secret, username, issuer='FlaskApp'):
    """
    Generate a TOTP URI for authenticator apps
    Format: otpauth://totp/ISSUER:ACCOUNT?secret=SECRET&issuer=ISSUER
    """
    # Стандартный URI для TOTP-приложений по спецификации TOTP
    return f"otpauth://totp/{issuer}:{username}?secret={secret}&issuer={issuer}"

def generate_qr_code_base64(secret, username, issuer='FlaskApp'):
    """Generate a QR code for the TOTP URI and return it as a base64 string"""
    # Create TOTP URI
    totp_uri = generate_totp_uri(secret, username, issuer)

    if qrcode_available:
        try:
            # Generate QR code
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(totp_uri)
            qr.make(fit=True)

            # Create an image from the QR code
            img = qr.make_image(fill_color="black", back_color="white")

            # Save the image to a bytes buffer
            buffer = BytesIO()
            img.save(buffer, format='PNG')

            # Convert the bytes to a base64 string
            qr_code_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

            return qr_code_base64
        except Exception as e:
            print(f"Error generating QR code: {e}", file=sys.stderr)

    # Return a URL to a public QR code generation service if qrcode module is not available
    # or if an error occurred during QR code generation
    return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={totp_uri}"

def generate_current_totp(secret):
    """Generate the current TOTP code for a secret"""
    if pyotp:
        # Use pyotp for standards-compliant TOTP generation
        try:
            totp = pyotp.TOTP(secret)
            return totp.now()
        except Exception as e:
            print(f"Error with pyotp.TOTP: {e}", file=sys.stderr)
            # Fall back to manual implementation

    # Fallback implementation if pyotp is not available or fails
    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    try:
        # Decode the base32 secret
        secret_padded = secret.upper()
        padding = len(secret_padded) % 8
        if padding > 0:
            secret_padded += '=' * (8 - padding)

        secret_bytes = base64.b32decode(secret_padded)

        # Compute HMAC
        counter_bytes = intervals_no.to_bytes(8, byteorder='big')
        h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

        # Get offset
        offset = h[-1] & 0x0F

        # Get 4 bytes at the offset
        truncated_hash = h[offset:offset+4]

        # Convert to an integer and get only 6 digits
        code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
        code = code % 1000000

        # Zero pad to 6 digits
        code_str = str(code).zfill(6)

        return code_str
    except Exception as e:
        print(f"Error generating TOTP: {e}", file=sys.stderr)
        return "000000"  # Return dummy code in case of error

def verify_totp(secret, token):
    """Verify a TOTP token against a secret"""
    if not token:
        print("Token is empty")
        return False

    # Normalize token: remove spaces and ensure it contains only digits
    token = token.strip()
    if not token.isdigit() or len(token) != 6:
        print(f"Token format invalid: '{token}'")
        return False

    # Подробное логирование для отладки
    print(f"Детальная проверка токена: '{token}'")
    print(f"Используемый секрет (первые 5 символов): {secret[:5]}...")

    # Расширенное временное окно для проверки (±90 секунд)
    # Это дает больше гибкости при рассинхронизации часов
    now = int(time.time())
    time_step = 30
    current_interval = now // time_step

    print(f"Текущее время: {now}, текущий интервал: {current_interval}")

    # Проверяем текущий интервал и несколько соседних интервалов
    # Используем более широкое окно: ±3 интервала (90 секунд в каждую сторону)
    for delta in range(-3, 4):  # -3, -2, -1, 0, 1, 2, 3
        counter = current_interval + delta

        try:
            # Подготавливаем секретный ключ для расчета хеша
            secret_padded = secret.upper()
            padding = len(secret_padded) % 8
            if padding > 0:
                secret_padded += '=' * (8 - padding)

            secret_bytes = base64.b32decode(secret_padded)

            # Вычисляем HMAC-SHA1 хеш
            counter_bytes = counter.to_bytes(8, byteorder='big')
            h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

            # Вычисляем TOTP код по алгоритму RFC 6238
            offset = h[-1] & 0x0F
            truncated_hash = h[offset:offset+4]
            code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
            code = code % 1000000

            # Дополняем до 6 цифр нулями при необходимости
            code_str = str(code).zfill(6)

            # Выводим сгенерированный код для отладки
            if delta == 0:
                print(f"Сгенерированный код для текущего интервала: {code_str}")
            else:
                print(f"Сгенерированный код для интервала {counter} (смещение {delta}): {code_str}")

            # Сравниваем с введенным пользователем кодом
            if code_str == token:
                print(f"Код совпал на интервале {counter} (смещение {delta})!")
                return True

        except Exception as e:
            print(f"Ошибка при проверке TOTP для интервала {counter}: {e}", file=sys.stderr)

    print("Ни один код не совпал после проверки всех интервалов")
    return False

# Test function to demonstrate usage
if __name__ == "__main__":
    print("2FA Module Testing")
    print("-----------------")

    # Generate a new secret
    secret = generate_totp_secret()
    print(f"Generated secret: {secret}")

    # Generate a URI for authenticator apps
    uri = generate_totp_uri(secret, "testuser", "TestApp")
    print(f"TOTP URI: {uri}")

    # Generate current code
    code = generate_current_totp(secret)
    print(f"Current TOTP code: {code}")

    # Verify the code
    if verify_totp(secret, code):
        print("Verification successful!")
    else:
        print("Verification failed!")

    # Show QR code URL
    qr_url = generate_qr_code_base64(secret, "testuser", "TestApp")
    if qr_url.startswith("http"):
        print(f"\nQR Code URL: {qr_url}")
    else:
        print("\nQR Code base64 generated (first 50 chars):", qr_url[:50] + "...")

    print("\nTo use this with an authenticator app, scan the QR code or enter the secret manually.")
    print("Compatible with Google Authenticator, Microsoft Authenticator, Authy, etc.")
