#!/usr/bin/env python3
import sqlite3
import sys
import argparse
import qrcode
from io import BytesIO
import twofa  # Используем наш модуль для работы с 2FA

def list_users():
    """List all users in the database"""
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, login, twofa_enabled FROM users")
    users = cursor.fetchall()
    conn.close()

    if not users:
        print("Пользователи не найдены в базе данных.")
        return

    print("\nСписок пользователей:")
    print("ID  | Логин    | 2FA")
    print("----+----------+-------")
    for user in users:
        status = "Включено" if user[2] else "Отключено"
        print(f"{user[0]:<3} | {user[1]:<8} | {status}")

def get_user_by_login(login):
    """Get user details by login"""
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, login, twofa_enabled, twofa_secret FROM users WHERE login = ?", (login,))
    user = cursor.fetchone()
    conn.close()

    return user

def setup_2fa_for_user(login, force=False):
    """Setup 2FA for a user"""
    user = get_user_by_login(login)

    if not user:
        print(f"Пользователь '{login}' не найден.")
        return

    user_id, username, twofa_enabled, twofa_secret = user

    # Check if 2FA is already enabled
    if twofa_enabled and not force:
        print(f"Двухфакторная аутентификация уже включена для пользователя '{username}'.")
        print("Используйте аргумент --force для повторной генерации.")
        return

    # Generate a new secret
    secret = twofa.generate_totp_secret()

    # Update the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET twofa_secret = ? WHERE id = ?", (secret, user_id))
    conn.commit()
    conn.close()

    # Create TOTP URI for QR code
    totp_uri = twofa.generate_totp_uri(secret, username)

    print(f"\n2FA настроена для пользователя '{username}' (ID: {user_id})")
    print("=" * 60)
    print(f"Секретный ключ: {secret}")
    print(f"Текущий TOTP код: {twofa.generate_current_totp(secret)}")
    print(f"TOTP URI: {totp_uri}")
    print("\nИнструкции для пользователя:")
    print("1. Откройте приложение Google Authenticator, Microsoft Authenticator или аналогичное")
    print("2. Добавьте новую учетную запись, отсканировав QR-код или выбрав 'Ввести ключ вручную'")
    print("3. Если вы выбрали ручной ввод, введите секретный ключ, показанный выше")
    print("4. Используйте 6-значный код из приложения при входе в систему")

    # Генерация QR-кода в текстовом виде (ASCII)
    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(totp_uri)
        qr.make(fit=True)

        # Create ASCII QR code
        print("\nQR-код для сканирования (если видно корректно):")
        qr.print_ascii()
    except ImportError:
        print("\nДля генерации QR-кода в терминале установите библиотеку qrcode:")
        print("   pip install qrcode")

def enable_2fa_for_user(login):
    """Enable 2FA for a user after they have set up the authenticator app"""
    user = get_user_by_login(login)

    if not user:
        print(f"Пользователь '{login}' не найден.")
        return

    user_id, username, twofa_enabled, twofa_secret = user

    # Check if 2FA is already enabled
    if twofa_enabled:
        print(f"Двухфакторная аутентификация уже включена для пользователя '{username}'.")
        return

    # Check if secret exists
    if not twofa_secret:
        print(f"Для пользователя '{username}' не настроен секретный ключ.")
        print("Сначала выполните настройку с помощью команды setup.")
        return

    # Ask for verification code
    code = input("Введите 6-значный код из приложения-аутентификатора: ")

    # Verify the code
    if not twofa.verify_totp(twofa_secret, code):
        print("Неверный код. 2FA не активирована.")
        return

    # Enable 2FA
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET twofa_enabled = 1 WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

    print(f"2FA успешно активирована для пользователя '{username}'!")

def main():
    parser = argparse.ArgumentParser(description='Инструмент для управления двухфакторной аутентификацией')
    subparsers = parser.add_subparsers(dest='command', help='Команда для выполнения')

    # List users command
    list_parser = subparsers.add_parser('list', help='Показать список пользователей')

    # Setup 2FA command
    setup_parser = subparsers.add_parser('setup', help='Настроить 2FA для пользователя')
    setup_parser.add_argument('login', type=str, help='Логин пользователя')
    setup_parser.add_argument('--force', action='store_true', help='Принудительно сгенерировать новый ключ')

    # Enable 2FA command
    enable_parser = subparsers.add_parser('enable', help='Активировать 2FA для пользователя')
    enable_parser.add_argument('login', type=str, help='Логин пользователя')

    args = parser.parse_args()

    if args.command == 'list':
        list_users()
    elif args.command == 'setup':
        setup_2fa_for_user(args.login, args.force)
    elif args.command == 'enable':
        enable_2fa_for_user(args.login)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
