// This file is used by the @netlify/plugin-nextjs plugin
// It helps Netlify understand how to deploy Next.js applications

module.exports = {
  // Disable the plugin if needed
  // disabled: false,

  // Specify the version of Next.js you're using
  nextjsVersion: 15,
};
