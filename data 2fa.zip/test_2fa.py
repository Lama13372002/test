#!/usr/bin/env python3
import sys
import time
import twofa  # Import our improved 2FA module

def test_totp_verification(interactive=False):
    """Test the TOTP verification functionality"""
    print("TOTP Verification Test")
    print("=====================")

    # Test 1: Verify that a generated code is verified successfully
    secret = twofa.generate_totp_secret()
    print(f"Test 1: Generated secret: {secret}")

    code = twofa.generate_current_totp(secret)
    print(f"Generated code: {code}")

    if twofa.verify_totp(secret, code):
        print("Test 1 PASS: Code verified successfully")
    else:
        print("Test 1 FAIL: Code verification failed")

    # Test 2: Verify that an incorrect code is rejected
    wrong_code = "000000"
    print(f"\nTest 2: Trying incorrect code: {wrong_code}")
    if not twofa.verify_totp(secret, wrong_code):
        print("Test 2 PASS: Incorrect code rejected")
    else:
        print("Test 2 FAIL: Incorrect code was accepted")

    # Test 3: Generate authenticator app setup information
    print("\nTest 3: Authenticator App Setup Information")
    print("------------------------------------------")
    uri = twofa.generate_totp_uri(secret, "testuser", "TestApp")
    print(f"TOTP URI: {uri}")

    qr_url = twofa.generate_qr_code_base64(secret, "testuser", "TestApp")
    if qr_url.startswith("http"):
        print(f"QR Code URL: {qr_url}")
        print("You can open this URL in a browser to see the QR code")
    else:
        print("QR Code generated as base64")

    print("\nTo set up this test account in your authenticator app:")
    print("1. Open Google Authenticator, Microsoft Authenticator, or Authy")
    print("2. Add a new account by scanning the QR code OR by manual entry")
    print(f"3. Secret key for manual entry: {secret}")
    print("4. After setup, the app will show a 6-digit code")

    if interactive:
        # Ask if the user wants to test with a real authenticator app
        print("\nWould you like to test with a real authenticator app? (y/n)")
        choice = input("> ").strip().lower()

        if choice == 'y':
            validate_with_authenticator_app(secret)
        else:
            print("\nSkipping authenticator app test.")
            print("You can run this test later by running:")
            print(f"python3 test_2fa.py validate {secret}")

    print("\nAll automatic tests PASSED!")
    return secret

def validate_with_authenticator_app(secret):
    """Interactive test to verify a code from an authenticator app"""
    print("\nAuthenticator App Verification Test")
    print("================================")
    print(f"Using secret: {secret}")
    print("\nCurrent expected code from our implementation:")

    # Show the current code according to our implementation
    code = twofa.generate_current_totp(secret)
    print(f"Expected code: {code}")

    # Ask the user for the code from their authenticator app
    print("\nPlease enter the 6-digit code from your authenticator app:")
    user_code = input("> ").strip()

    # Verify the user-provided code
    if twofa.verify_totp(secret, user_code):
        print("SUCCESS! The code from your authenticator app is valid.")
        print("This confirms that our implementation is compatible with standard authenticator apps.")
    else:
        print("FAILED! The code from your authenticator app is not valid.")
        print("Possible issues:")
        print("- Incorrect code entry")
        print("- Time synchronization issues")
        print("- Implementation compatibility problems")

    print("\nFor reference, here's the code our system generated:")
    print(f"Our system code: {code}")

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # Run the basic TOTP verification test in non-interactive mode
        test_totp_verification(interactive=False)

    elif len(sys.argv) == 2 and sys.argv[1] == "interactive":
        # Run in interactive mode
        test_totp_verification(interactive=True)

    elif len(sys.argv) == 3 and sys.argv[1] == "validate":
        # Validate a specific code for a specific secret
        secret = sys.argv[2]
        validate_with_authenticator_app(secret)

    else:
        print("Usage:")
        print("  python3 test_2fa.py                 # Run automatic verification tests")
        print("  python3 test_2fa.py interactive     # Run tests with interactive prompts")
        print("  python3 test_2fa.py validate SECRET # Test with an authenticator app")
