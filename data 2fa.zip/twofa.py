#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import time
import sys

def generate_totp_secret():
    """Генерация секретного ключа для TOTP"""
    # Генерируем случайные байты
    random_bytes = secrets.token_bytes(10)
    # Кодируем в base32 для совместимости с аутентификаторами
    # Важно: удаляем padding для Google Authenticator
    return base64.b32encode(random_bytes).decode('utf-8').rstrip('=')

def generate_totp_uri(secret, username, issuer='FlaskApp'):
    """Генерация URI для аутентификаторов"""
    # Экранируем специальные символы
    username_safe = username.replace(':', '%3A').replace('&', '%26')
    issuer_safe = issuer.replace(':', '%3A').replace('&', '%26')
    # Формируем URI в стандартном формате
    return f"otpauth://totp/{issuer_safe}:{username_safe}?secret={secret}&issuer={issuer_safe}"

def generate_qr_code_base64(secret, username, issuer='FlaskApp'):
    """Генерация QR-кода для URI"""
    totp_uri = generate_totp_uri(secret, username, issuer)
    # Используем внешний сервис для генерации QR-кода
    return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={totp_uri}"

def _generate_hotp(secret, counter, digits=6):
    """
    Базовая реализация HOTP (RFC 4226)
    """
    # Добавляем padding к секрету, если необходимо
    secret_padded = secret.upper()
    if len(secret_padded) % 8 != 0:
        secret_padded += '=' * (8 - len(secret_padded) % 8)

    # Декодируем секрет из base32
    key = base64.b32decode(secret_padded)

    # Преобразуем счетчик в 8 байт
    counter_bytes = counter.to_bytes(8, byteorder='big')

    # Вычисляем HMAC-SHA1
    h = hmac.new(key, counter_bytes, hashlib.sha1).digest()

    # Берем динамическое усечение по RFC 4226
    offset = h[-1] & 0x0F
    truncated_hash = h[offset:offset+4]

    # Маскируем старший бит и получаем число
    code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF

    # Берем остаток по модулю 10^digits (обычно 10^6 = 1 млн)
    code = code % (10 ** digits)

    # Дополняем нулями слева до нужного количества цифр
    return str(code).zfill(digits)

def generate_current_totp(secret, digits=6, window=30):
    """
    Генерация текущего TOTP кода по RFC 6238
    """
    # Получаем количество временных интервалов с начала эпохи
    counter = int(time.time()) // window
    return _generate_hotp(secret, counter, digits)

def verify_totp(secret, token, digits=6, window=30, window_size=1):
    """
    Проверка TOTP токена
    window_size - количество интервалов для проверки до и после текущего
    """
    if not token or not token.isdigit() or len(token) != digits:
        return False

    # Получаем текущий интервал
    current_interval = int(time.time()) // window

    # Проверяем текущий и соседние интервалы в диапазоне window_size
    for i in range(-window_size, window_size + 1):
        # Вычисляем интервал для проверки
        check_interval = current_interval + i
        # Генерируем код для этого интервала
        check_code = _generate_hotp(secret, check_interval, digits)
        # Сравниваем с введенным кодом
        if check_code == token:
            return True

    # Если ни один код не совпал
    return False

# Тестовая функция для демонстрации работы
if __name__ == "__main__":
    print("Тестирование 2FA модуля")
    print("=" * 30)

    # Генерируем новый секретный ключ
    secret = generate_totp_secret()
    print(f"Секретный ключ: {secret}")

    # Создаем URI для аутентификаторов
    uri = generate_totp_uri(secret, "testuser", "TestApp")
    print(f"TOTP URI: {uri}")

    # Генерируем текущий код
    code = generate_current_totp(secret)
    print(f"Текущий TOTP код: {code}")

    # Проверяем код
    if verify_totp(secret, code):
        print("Проверка успешна!")
    else:
        print("Проверка не удалась!")

    # Получаем URL QR-кода
    qr_url = generate_qr_code_base64(secret, "testuser", "TestApp")
    print(f"URL QR-кода: {qr_url}")

    print("\nВы можете добавить этот аккаунт в Google Authenticator, отсканировав QR-код")
    print("или введя секретный ключ вручную.")
