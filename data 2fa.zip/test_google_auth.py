#!/usr/bin/env python3
"""
Скрипт для тестирования совместимости Google Authenticator с нашей системой.
Генерирует секретный ключ, показывает QR-код и позволяет вводить коды из Google Authenticator
для проверки совместимости.
"""

import twofa
import time
import os
import sys

def clear_screen():
    """Очистка экрана для лучшей читаемости"""
    os.system('clear' if os.name != 'nt' else 'cls')

def show_banner():
    """Показать баннер теста"""
    print("=" * 60)
    print(f"{'ТЕСТ СОВМЕСТИМОСТИ С GOOGLE AUTHENTICATOR':^60}")
    print("=" * 60)

def generate_key_and_qr():
    """Генерация ключа и QR-кода для тестирования"""
    # Генерируем секретный ключ
    secret = twofa.generate_totp_secret()

    # Создаем URI для аутентификатора
    uri = twofa.generate_totp_uri(secret, "test_user", "TestApp")

    # Получаем URL QR-кода
    qr_url = twofa.generate_qr_code_base64(secret, "test_user", "TestApp")

    return secret, uri, qr_url

def run_interactive_test():
    """Интерактивный тест совместимости с Google Authenticator"""
    clear_screen()
    show_banner()

    print("\nЭтот тест поможет проверить совместимость кодов Google Authenticator")
    print("с реализацией TOTP в нашей системе.\n")

    input("Нажмите Enter, чтобы продолжить...")

    clear_screen()
    show_banner()

    # Генерируем секретный ключ
    secret, uri, qr_url = generate_key_and_qr()

    print("\n1. Секретный ключ для ручного ввода:")
    print(f"   {secret}")

    print("\n2. URI для аутентификатора:")
    print(f"   {uri}")

    print("\n3. QR-код для сканирования:")
    print(f"   {qr_url}")

    print("\nДля настройки Google Authenticator:")
    print("1. Откройте приложение Google Authenticator")
    print("2. Нажмите '+' для добавления нового аккаунта")
    print("3. Выберите 'Сканировать QR-код' или 'Ввести ключ вручную'")
    print("   - Если выбрали 'Сканировать QR-код', отсканируйте QR-код по ссылке выше")
    print("   - Если выбрали 'Ввести ключ вручную', введите секретный ключ")

    input("\nПосле добавления аккаунта в Google Authenticator нажмите Enter...")

    # Цикл проверки кодов
    while True:
        clear_screen()
        show_banner()

        print("\nПРОВЕРКА КОДОВ\n")

        # Генерируем текущий код нашей системы
        our_code = twofa.generate_current_totp(secret)

        # Текущее время и расчет оставшихся секунд до следующего кода
        now = int(time.time())
        remaining = 30 - (now % 30)

        print(f"Код нашей системы: {our_code} (меняется через {remaining} сек)")

        # Запрашиваем код из Google Authenticator
        user_code = input("\nВведите 6-значный код из Google Authenticator: ")

        if not user_code or user_code.lower() in ('q', 'quit', 'exit'):
            break

        # Проверяем код с широким окном (±3 интервала = ±90 сек)
        if twofa.verify_totp(secret, user_code, window_size=3):
            print("\n✅ УСПЕХ! Код из Google Authenticator подтвержден.")
            print("Это означает, что наша система совместима с Google Authenticator.")
        else:
            print("\n❌ Код не подтвержден. Возможные причины:")
            print("   - Неправильно введен код")
            print("   - Значительная рассинхронизация времени")
            print("   - Проблемы с совместимостью реализации")

        # Показываем разницу во времени между нашей системой и Google Authenticator
        if user_code.isdigit() and len(user_code) == 6:
            # Проверяем код в широком диапазоне интервалов для определения сдвига времени
            current_interval = now // 30
            for delta in range(-10, 11):  # ±5 минут
                check_interval = current_interval + delta
                check_code = twofa._generate_hotp(secret, check_interval)
                if check_code == user_code:
                    time_diff = delta * 30
                    if time_diff == 0:
                        print("\nВремя на устройстве синхронизировано с сервером.")
                    else:
                        print(f"\nРазница во времени: {time_diff} секунд " +
                              f"({'опережение' if time_diff < 0 else 'отставание'} от сервера).")
                    break

        input("\nНажмите Enter для продолжения или введите 'q' для выхода...")
        if input("\nПродолжить тестирование? (y/n): ").lower() != 'y':
            break

if __name__ == "__main__":
    run_interactive_test()
    print("\nТест завершен. Если коды были успешно проверены, значит система совместима с Google Authenticator.")
