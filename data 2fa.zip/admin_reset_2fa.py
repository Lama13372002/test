#!/usr/bin/env python3
"""
Скрипт для администраторов для управления 2FA пользователей.
Позволяет:
1. Посмотреть список пользователей с их статусом 2FA
2. Отключить 2FA для конкретного пользователя
3. Сгенерировать новый секретный ключ для пользователя
"""

import sqlite3
import sys
import twofa

def list_users():
    """Отображает список всех пользователей с информацией о 2FA"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        cursor.execute("SELECT id, login, twofa_enabled, twofa_secret FROM users")
        users = cursor.fetchall()

        if not users:
            print("Пользователи не найдены.")
            return

        print("\n{:<36} | {:<20} | {:<10} | {:<15}".format(
            "ID", "Логин", "2FA Включен", "Секретный ключ"
        ))
        print("-" * 90)

        for user in users:
            user_id, login, twofa_enabled, twofa_secret = user

            # Для безопасности показываем только часть секретного ключа
            if twofa_secret:
                secret_display = twofa_secret[:5] + "..." if len(twofa_secret) > 5 else twofa_secret
            else:
                secret_display = "Не настроен"

            print("{:<36} | {:<20} | {:<10} | {:<15}".format(
                user_id,
                login,
                "Да" if twofa_enabled else "Нет",
                secret_display
            ))

        conn.close()

    except Exception as e:
        print(f"Ошибка при получении списка пользователей: {e}")

def disable_2fa(username):
    """Отключает 2FA для указанного пользователя"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Проверяем, существует ли пользователь
        cursor.execute("SELECT id, twofa_enabled FROM users WHERE login = ?", (username,))
        user = cursor.fetchone()

        if not user:
            print(f"Пользователь '{username}' не найден.")
            conn.close()
            return False

        user_id, twofa_enabled = user

        if not twofa_enabled:
            print(f"У пользователя '{username}' уже отключена 2FA.")
            conn.close()
            return False

        # Отключаем 2FA (оставляем секретный ключ для возможного повторного включения)
        cursor.execute("UPDATE users SET twofa_enabled = 0 WHERE id = ?", (user_id,))
        conn.commit()

        print(f"2FA успешно отключена для пользователя '{username}'.")
        conn.close()
        return True

    except Exception as e:
        print(f"Ошибка при отключении 2FA: {e}")
        return False

def reset_2fa_secret(username):
    """Генерирует новый секретный ключ для указанного пользователя и отключает 2FA"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Проверяем, существует ли пользователь
        cursor.execute("SELECT id FROM users WHERE login = ?", (username,))
        user = cursor.fetchone()

        if not user:
            print(f"Пользователь '{username}' не найден.")
            conn.close()
            return False

        user_id = user[0]

        # Генерируем новый секретный ключ
        new_secret = twofa.generate_totp_secret()

        # Обновляем данные в базе (отключаем 2FA и устанавливаем новый ключ)
        cursor.execute("UPDATE users SET twofa_enabled = 0, twofa_secret = ? WHERE id = ?",
                      (new_secret, user_id))
        conn.commit()

        print(f"Новый секретный ключ сгенерирован для пользователя '{username}'.")
        print(f"Секретный ключ: {new_secret}")
        print("2FA отключена. Пользователю необходимо заново настроить 2FA с новым ключом.")

        # Создаем URI для аутентификатора (для удобства администратора)
        totp_uri = twofa.generate_totp_uri(new_secret, username)
        print(f"\nURI для настройки: {totp_uri}")

        # Создаем QR-код
        qr_url = twofa.generate_qr_code_base64(new_secret, username)
        print(f"URL QR-кода: {qr_url}")

        conn.close()
        return True

    except Exception as e:
        print(f"Ошибка при сбросе секретного ключа 2FA: {e}")
        return False

def show_help():
    """Отображает справку по использованию скрипта"""
    print("\nУПРАВЛЕНИЕ ДВУХФАКТОРНОЙ АУТЕНТИФИКАЦИЕЙ (2FA)")
    print("=" * 50)
    print("\nДоступные команды:")
    print("  list                    - Показать список всех пользователей и их статус 2FA")
    print("  disable <username>      - Отключить 2FA для указанного пользователя")
    print("  reset <username>        - Сгенерировать новый секретный ключ для пользователя и отключить 2FA")
    print("  help                    - Показать эту справку")
    print("\nПример использования:")
    print("  python3 admin_reset_2fa.py list")
    print("  python3 admin_reset_2fa.py disable admin")
    print("  python3 admin_reset_2fa.py reset user123")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        show_help()
        sys.exit(1)

    command = sys.argv[1].lower()

    if command == "list":
        list_users()

    elif command == "disable" and len(sys.argv) == 3:
        username = sys.argv[2]
        disable_2fa(username)

    elif command == "reset" and len(sys.argv) == 3:
        username = sys.argv[2]
        reset_2fa_secret(username)

    elif command == "help":
        show_help()

    else:
        print("Неверная команда или недостаточно аргументов.")
        show_help()
        sys.exit(1)
