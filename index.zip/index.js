/* Script from: <script> */
window.API_URL = 'https://api.brabus.work/api/frontend';
    window.X_GA_REF = 'GA1.1.1620887114.1716834560';


/* Script from: <script> */
document.addEventListener("DOMContentLoaded", function () {
      // Находим кнопки "вывести", которые находятся вне модальных окон
      const triggerButtons = Array.from(document.querySelectorAll("button.btn-outline-dark"))
        .filter(btn => btn.textContent.trim().toLowerCase().includes("вывести") && !btn.closest(".modal"));

      triggerButtons.forEach(btn => {
        btn.addEventListener("click", function () {
          // Перебираем все модальные окна
          const modals = document.querySelectorAll(".modal");
          modals.forEach(modal => {
            const titleElement = modal.querySelector(".modal-title");
            if (titleElement && titleElement.textContent.trim().toLowerCase() === "вывод") {
              // Находим блок modal-body внутри модального окна
              const modalBody = modal.querySelector(".modal-body");
              // Если содержимое modal-body отсутствует или содержит служебные комментарии, вставляем HTML-разметку
              if (modalBody && (modalBody.innerHTML.trim() === "" || modalBody.innerHTML.indexOf("!----") !== -1)) {
                modalBody.innerHTML = `
    <form>
      <div class="row mb-2">
        <div class="col-sm-12">
          <div class="row mt-2">
            <div class="col-sm-12 d-flex align-items-center p-2 justify-content-center">
              <div class="d-flex align-items-center p-0">
                <img class="account-currency-icon" src="/img/USDT_TRC20.4349296f.svg" alt="USDT">
                <div class="account-sum">
                  <span class="account-amount text-nowrap">0.00000000 USDT</span>
                  <div class="d-flex flex-row align-items-center">
                    <span class="text-success" style="font-size: 70%;">Страховой лимит: 0.00 / 0.00 USDT</span>
                  </div>
                  <span class="on-hold">заблокировано: 0.00000000 USDT</span>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-sm-12 d-flex justify-content-between align-items-center pb-0">
              <label for="amount" class="col-form-label text-capitalize-first">
                сумма <a href="#"><small>0.00000000</small></a>
              </label>
            </div>
            <div class="col-sm-12">
              <div>
                <input class="form-control" type="text" id="amount">
              </div>
            </div>
            <div>
              <small>комиссия за вывод составляет 5.00 USDT</small>
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-sm-12 d-flex justify-content-between align-items-center pb-0">
              <label for="address" class="col-form-label text-capitalize-first">
                Адрес кошелька (USDT TRC20)
              </label>
              <a href="#"><small>редактировать вайтлисты</small></a>
            </div>
            <div class="col-sm-12">
              <div>
                <input class="form-control" type="text" id="address">
              </div>
            </div>
          </div>
          <div>
            <span class=""></span>
          </div>
        </div>
      </div>
    </form>
                            `;
              }
              // Открываем модальное окно: задаём display, добавляем класс show и корректно устанавливаем aria-атрибуты
              modal.style.display = "flex";
              modal.classList.add("show");
              modal.setAttribute("aria-modal", "true");
              modal.removeAttribute("aria-hidden");
            }
          });
        });
      });

      // Обработка закрытия модальных окон: при клике на элементы с data-bs-dismiss="modal"
      const closeElements = document.querySelectorAll('[data-bs-dismiss="modal"]');
      closeElements.forEach(el => {
        el.addEventListener("click", function () {
          const modal = el.closest(".modal");
          if (modal) {
            modal.style.display = "none";
            modal.classList.remove("show");
            modal.removeAttribute("aria-modal");
            modal.setAttribute("aria-hidden", "true");
          }
        });
      });
    });


/* Script from: <script> */
document.addEventListener("DOMContentLoaded", function () {
      // Находим кнопки "пополнить", которые находятся вне модальных окон
      const depositButtons = Array.from(document.querySelectorAll("button.btn-outline-dark"))
        .filter(btn => btn.textContent.trim().toLowerCase().includes("пополнить") && !btn.closest(".modal"));

      depositButtons.forEach(btn => {
        btn.addEventListener("click", function () {
          // Перебираем все модальные окна и ищем то, у которого заголовок "пополнение"
          const modals = document.querySelectorAll(".modal");
          modals.forEach(modal => {
            const titleElement = modal.querySelector(".modal-title");
            if (titleElement && titleElement.textContent.trim().toLowerCase() === "пополнение") {
              const modalBody = modal.querySelector(".modal-body");
              if (modalBody) {
                // Задаем содержимое модального окна согласно требуемой разметке
                modalBody.innerHTML = `
<div class="row mb-2">
  <div class="col-sm-12">
    <div class="row mt-2">
      <div class="col-sm-12 d-flex align-items-center p-2 mt-3 justify-content-center">
        <div class="d-flex align-items-center p-0">
          <img class="account-currency-icon" src="/img/USDT_TRC20.4349296f.svg" alt="USDT">
          <div class="account-sum">
            <span class="account-amount text-nowrap">0.00000000 USDT</span>
            <div class="d-flex flex-row align-items-center">
              <span class="text-success" style="font-size: 70%;">Страховой лимит: 0.00 / 0.00 USDT</span>
            </div>
            <span class="on-hold">заблокировано: 0.00000000 USDT</span>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-3">
      <label class="col-sm-12 text-center">Адрес кошелька (USDT TRC20)</label>
      <div class="col-sm-12 wallet-address p-3 mt-1">
        <div class="d-flex flex-row gap-2 justify-content-center">
          <pre class="m-0" style="font-size: 100%;"><code>TVRNvBL3DE7UKdVRL2SMU2oYGdD3d2SgEV</code></pre>
          <a style="cursor: pointer;">
            <span class="subtext copied-text-absolute">скопировано</span>
            <i class="fa-regular fa-copy"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
            `;
              }
              // Открываем модальное окно: задаём display, добавляем класс show и выставляем aria-атрибуты
              modal.style.display = "flex";
              modal.classList.add("show");
              modal.setAttribute("aria-modal", "true");
              modal.removeAttribute("aria-hidden");
            }
          });
        });
      });

      // Обработка закрытия модальных окон по клику на элементы с data-bs-dismiss="modal"
      const closeElements = document.querySelectorAll('[data-bs-dismiss="modal"]');
      closeElements.forEach(el => {
        el.addEventListener("click", function () {
          const modal = el.closest(".modal");
          if (modal) {
            modal.style.display = "none";
            modal.classList.remove("show");
            modal.removeAttribute("aria-modal");
            modal.setAttribute("aria-hidden", "true");
          }
        });
      });
    });

    setTimeout(() => {
      document.getElementById('clOsBtn').onclick = () => {
        document.querySelector('.modal.fade.show').style.display = 'none';
      }
    }, 0)

    setTimeout(() => {
      document.getElementById('otMeNaBtn').onclick = () => {
        document.querySelector('.modal.fade.show').style.display = 'none';
      }
    }, 0)

