"use client";

import { Chat, ChatMessage, User } from "./types";

// Временная функция для имитации API запросов
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Фиктивные данные чатов для демонстрации
const MOCK_CHATS: Record<string, Chat[]> = {
  user1: [
    {
      id: "chat1",
      title: "Проект интернет-магазина",
      messages: [
        {
          id: "msg1",
          content: "Привет! Помоги мне создать структуру для интернет-магазина.",
          sender: "user",
          timestamp: new Date("2023-04-01T10:00:00"),
        },
        {
          id: "msg2",
          content: "Конечно! Для интернет-магазина вам понадобится следующая структура:\n1. Главная страница\n2. Каталог товаров\n3. Страница товара\n4. Корзина\n5. Оформление заказа\n6. Личный кабинет\n\nХотите, чтобы я подробнее рассказал о каждом разделе?",
          sender: "ai",
          timestamp: new Date("2023-04-01T10:01:00"),
        },
      ],
      createdAt: new Date("2023-04-01T10:00:00"),
      updatedAt: new Date("2023-04-01T10:01:00"),
    },
    {
      id: "chat2",
      title: "Оптимизация SQL-запросов",
      messages: [
        {
          id: "msg3",
          content: "Как оптимизировать сложные SQL-запросы с несколькими JOIN?",
          sender: "user",
          timestamp: new Date("2023-04-02T14:30:00"),
        },
        {
          id: "msg4",
          content: "Для оптимизации SQL-запросов с множественными JOIN рекомендую следующее:\n\n1. Используйте индексы для полей, участвующих в JOIN\n2. Минимизируйте количество промежуточных данных\n3. Рассмотрите возможность денормализации данных\n4. Используйте EXPLAIN для анализа запроса\n5. Избегайте SELECT * и запрашивайте только нужные поля\n\nХотите подробнее узнать о какой-то конкретной технике оптимизации?",
          sender: "ai",
          timestamp: new Date("2023-04-02T14:31:00"),
        },
      ],
      createdAt: new Date("2023-04-02T14:30:00"),
      updatedAt: new Date("2023-04-02T14:31:00"),
    },
  ],
  user2: [
    {
      id: "chat3",
      title: "Разработка мобильного приложения",
      messages: [
        {
          id: "msg5",
          content: "Какой фреймворк лучше использовать для кроссплатформенной разработки приложения для фитнеса?",
          sender: "user",
          timestamp: new Date("2023-03-15T09:20:00"),
        },
        {
          id: "msg6",
          content: "Для создания кроссплатформенного фитнес-приложения рекомендую обратить внимание на следующие фреймворки:\n\n1. React Native - отличное производительность, большое сообщество, хорошая работа с нативными функциями\n2. Flutter - плавная анимация, единая кодовая база, отличное UI\n3. Ionic - веб-технологии, простота разработки, быстрый цикл разработки\n\nДля фитнес-приложения особенно важны:\n- Работа с датчиками устройства\n- Возможность работы с Bluetooth (для фитнес-трекеров)\n- Плавная анимация для демонстрации упражнений\n- Работа в оффлайн режиме\n\nУчитывая эти требования, я бы порекомендовал React Native или Flutter. React Native может быть предпочтительнее, если у вас уже есть опыт с JavaScript/React. Flutter отлично подойдет, если вы начинаете с нуля и готовы изучить Dart.",
          sender: "ai",
          timestamp: new Date("2023-03-15T09:22:00"),
        },
      ],
      createdAt: new Date("2023-03-15T09:20:00"),
      updatedAt: new Date("2023-03-15T09:22:00"),
    },
  ],
};

class ChatService {
  // Получение всех чатов пользователя
  async getUserChats(userId: string): Promise<Chat[]> {
    await delay(500);
    return MOCK_CHATS[userId] || [];
  }

  // Получение чата по ID
  async getChatById(userId: string, chatId: string): Promise<Chat | null> {
    await delay(300);
    const userChats = MOCK_CHATS[userId] || [];
    return userChats.find((chat) => chat.id === chatId) || null;
  }

  // Создание нового чата
  async createChat(userId: string, title: string = "Новый чат"): Promise<Chat> {
    await delay(700);

    const newChat: Chat = {
      id: `chat${Date.now()}`,
      title,
      messages: [
        {
          id: `msg${Date.now()}`,
          content: "Привет! Я ваш ИИ-ассистент. Чем я могу вам помочь сегодня?",
          sender: "ai",
          timestamp: new Date(),
        },
      ],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    if (!MOCK_CHATS[userId]) {
      MOCK_CHATS[userId] = [];
    }

    MOCK_CHATS[userId].push(newChat);
    return newChat;
  }

  // Добавление сообщения в чат
  async addMessage(
    userId: string,
    chatId: string,
    content: string,
    sender: "user" | "ai" | "system"
  ): Promise<ChatMessage> {
    await delay(500);

    const chat = await this.getChatById(userId, chatId);
    if (!chat) {
      throw new Error("Чат не найден");
    }

    const newMessage: ChatMessage = {
      id: `msg${Date.now()}`,
      content,
      sender,
      timestamp: new Date(),
    };

    chat.messages.push(newMessage);
    chat.updatedAt = new Date();

    // В реальном приложении здесь был бы API-запрос

    return newMessage;
  }

  // Генерация ответа ИИ
  async generateAIResponse(userId: string, chatId: string, userMessage: string): Promise<ChatMessage> {
    await delay(1500); // Имитация работы ИИ

    const chat = await this.getChatById(userId, chatId);
    if (!chat) {
      throw new Error("Чат не найден");
    }

    // Здесь в реальном приложении был бы запрос к API ИИ-модели
    // Пример простого ответа для демонстрации
    let aiResponse = "";

    if (userMessage.toLowerCase().includes("привет")) {
      aiResponse = "Здравствуйте! Чем я могу вам помочь?";
    } else if (userMessage.toLowerCase().includes("код") || userMessage.toLowerCase().includes("программ")) {
      aiResponse = "Я могу помочь вам с написанием кода или объяснением программных концепций. Что именно вас интересует?";
    } else if (userMessage.toLowerCase().includes("проект") || userMessage.toLowerCase().includes("разработ")) {
      aiResponse = "Разработка проектов - это моя специализация. Я могу помочь с архитектурой, выбором технологий и решением конкретных задач. Опишите подробнее, что вы хотите создать.";
    } else {
      aiResponse = "Я проанализировал ваш запрос. Пожалуйста, предоставьте больше деталей о вашей задаче, чтобы я мог дать более точный ответ.";
    }

    const newMessage: ChatMessage = {
      id: `msg${Date.now()}`,
      content: aiResponse,
      sender: "ai",
      timestamp: new Date(),
    };

    chat.messages.push(newMessage);
    chat.updatedAt = new Date();

    return newMessage;
  }

  // Удаление чата
  async deleteChat(userId: string, chatId: string): Promise<boolean> {
    await delay(400);

    if (!MOCK_CHATS[userId]) {
      return false;
    }

    const initialLength = MOCK_CHATS[userId].length;
    MOCK_CHATS[userId] = MOCK_CHATS[userId].filter((chat) => chat.id !== chatId);

    return MOCK_CHATS[userId].length < initialLength;
  }

  // Переименование чата
  async renameChat(userId: string, chatId: string, newTitle: string): Promise<Chat | null> {
    await delay(400);

    const chat = await this.getChatById(userId, chatId);
    if (!chat) {
      return null;
    }

    chat.title = newTitle;
    chat.updatedAt = new Date();

    return chat;
  }
}

// Синглтон для использования сервиса во всем приложении
export const chatService = new ChatService();
