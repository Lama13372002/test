"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { AuthState, User, UserRole } from "./types";
import { setCookie, getCookie, deleteCookie } from "./cookie-utils";

// Создаем контекст аутентификации
const AuthContext = createContext<{
  authState: AuthState;
  login: (email: string, password: string) => Promise<void>;
  register: (
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ) => Promise<void>;
  logout: () => void;
  updateUserProfile: (userData: Partial<User>) => Promise<void>;
}>({
  authState: {
    isAuthenticated: false,
    user: null,
    loading: true,
    error: null,
  },
  login: async () => {},
  register: async () => {},
  logout: () => {},
  updateUserProfile: async () => {},
});

// Временная функция для имитации API запросов
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Фиктивные пользователи для демонстрации
const MOCK_USERS = [
  {
    id: "user1",
    firstName: "Иван",
    lastName: "Иванов",
    email: "ivan@example.com",
    password: "password123",
    role: "basic" as UserRole,
    avatar: "https://source.unsplash.com/random/200x200/?face-1",
    createdAt: new Date(),
  },
  {
    id: "user2",
    firstName: "Мария",
    lastName: "Петрова",
    email: "maria@example.com",
    password: "password123",
    role: "premium" as UserRole,
    avatar: "https://source.unsplash.com/random/200x200/?face-2",
    createdAt: new Date(),
  },
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    // Проверяем, есть ли пользователь в localStorage и куки
    const checkAuth = async () => {
      try {
        // Проверяем куки
        const userCookie = getCookie("user");

        if (userCookie) {
          const user = JSON.parse(userCookie);
          setAuthState({
            isAuthenticated: true,
            user,
            loading: false,
            error: null,
          });
          return;
        }

        // Если куки нет, проверяем localStorage для обратной совместимости
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
          const user = JSON.parse(storedUser);
          // Устанавливаем куки
          setCookie("user", storedUser, 7);

          setAuthState({
            isAuthenticated: true,
            user,
            loading: false,
            error: null,
          });
        } else {
          setAuthState({
            isAuthenticated: false,
            user: null,
            loading: false,
            error: null,
          });
        }
      } catch (error) {
        console.error("Error parsing user:", error);
        localStorage.removeItem("user");
        deleteCookie("user");

        setAuthState({
          isAuthenticated: false,
          user: null,
          loading: false,
          error: null,
        });
      }
    };

    checkAuth();
  }, []);

  // Функция входа
  const login = async (email: string, password: string) => {
    setAuthState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      await delay(1000); // Имитация задержки сети

      // В реальном приложении это был бы запрос к API
      const user = MOCK_USERS.find(
        (u) => u.email === email && u.password === password
      );

      if (!user) {
        throw new Error("Неверные учетные данные");
      }

      // Удаляем пароль из объекта пользователя перед сохранением
      const { password: _, ...userWithoutPassword } = user;

      const userJson = JSON.stringify(userWithoutPassword);

      // Сохраняем в localStorage и куки
      localStorage.setItem("user", userJson);
      setCookie("user", userJson, 7); // Куки на 7 дней

      setAuthState({
        isAuthenticated: true,
        user: userWithoutPassword,
        loading: false,
        error: null,
      });
    } catch (error) {
      setAuthState({
        isAuthenticated: false,
        user: null,
        loading: false,
        error: error instanceof Error ? error.message : "Ошибка входа",
      });
    }
  };

  // Функция регистрации
  const register = async (
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ) => {
    setAuthState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      await delay(1000); // Имитация задержки сети

      // Проверка, существует ли пользователь с таким email
      if (MOCK_USERS.some((u) => u.email === email)) {
        throw new Error("Пользователь с таким email уже существует");
      }

      // Создаем нового пользователя
      const newUser = {
        id: `user${Date.now()}`,
        firstName,
        lastName,
        email,
        role: "basic" as UserRole, // По умолчанию - базовый пользователь
        avatar: `https://source.unsplash.com/random/200x200/?face-${Math.floor(Math.random() * 10)}`,
        createdAt: new Date(),
      };

      // В реальном приложении здесь был бы API-запрос
      // Имитируем добавление пользователя в базу данных
      MOCK_USERS.push({ ...newUser, password });

      const userJson = JSON.stringify(newUser);

      // Сохраняем в localStorage и куки
      localStorage.setItem("user", userJson);
      setCookie("user", userJson, 7); // Куки на 7 дней

      setAuthState({
        isAuthenticated: true,
        user: newUser,
        loading: false,
        error: null,
      });
    } catch (error) {
      setAuthState({
        isAuthenticated: false,
        user: null,
        loading: false,
        error: error instanceof Error ? error.message : "Ошибка регистрации",
      });
    }
  };

  // Функция выхода
  const logout = () => {
    localStorage.removeItem("user");
    deleteCookie("user");

    setAuthState({
      isAuthenticated: false,
      user: null,
      loading: false,
      error: null,
    });
  };

  // Функция обновления профиля пользователя
  const updateUserProfile = async (userData: Partial<User>) => {
    if (!authState.user) {
      throw new Error("Пользователь не аутентифицирован");
    }

    setAuthState((prev) => ({ ...prev, loading: true }));

    try {
      await delay(1000); // Имитация задержки сети

      const updatedUser = { ...authState.user, ...userData };
      const userJson = JSON.stringify(updatedUser);

      // Обновляем пользователя в localStorage и куки
      localStorage.setItem("user", userJson);
      setCookie("user", userJson, 7); // Обновляем куки

      // Обновляем состояние
      setAuthState({
        isAuthenticated: true,
        user: updatedUser,
        loading: false,
        error: null,
      });
    } catch (error) {
      setAuthState((prev) => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : "Ошибка обновления профиля",
      }));
    }
  };

  return (
    <AuthContext.Provider
      value={{ authState, login, register, logout, updateUserProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Хук для использования контекста аутентификации
export const useAuth = () => useContext(AuthContext);
