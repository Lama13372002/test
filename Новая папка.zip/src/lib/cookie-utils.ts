/**
 * Устанавливает cookie в браузере
 * @param name Имя cookie
 * @param value Значение cookie
 * @param days Срок хранения cookie в днях
 */
export function setCookie(name: string, value: string, days: number): void {
  if (typeof window === 'undefined') return; // Server-side check

  let expires = '';
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = `; expires=${date.toUTCString()}`;
  }

  document.cookie = `${name}=${value}${expires}; path=/`;
}

/**
 * Получает значение cookie по имени
 * @param name Имя cookie
 * @returns Значение cookie или пустая строка, если cookie не найдена
 */
export function getCookie(name: string): string | undefined {
  if (typeof window === 'undefined') return undefined; // Server-side check

  const nameEQ = `${name}=`;
  const ca = document.cookie.split(';');

  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
  }

  return undefined;
}

/**
 * Удаляет cookie по имени
 * @param name Имя cookie
 */
export function deleteCookie(name: string): void {
  if (typeof window === 'undefined') return; // Server-side check

  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}
