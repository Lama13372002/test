import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Получаем данные пользователя из локального хранилища
  // В реальном приложении здесь должна быть проверка JWT или сессии
  const userJson = request.cookies.get('user')?.value
  const isAuthenticated = !!userJson

  // Защищаем маршруты /dashboard/*
  if (request.nextUrl.pathname.startsWith('/dashboard')) {
    if (!isAuthenticated) {
      // Если пользователь не авторизован, перенаправляем на страницу входа
      return NextResponse.redirect(new URL('/login', request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*'],
}
