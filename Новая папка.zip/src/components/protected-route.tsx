"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: "basic" | "premium";
}

export default function ProtectedRoute({
  children,
  requiredRole,
}: ProtectedRouteProps) {
  const { authState } = useAuth();
  const { isAuthenticated, user, loading } = authState;
  const router = useRouter();

  useEffect(() => {
    // Проверка аутентификации после загрузки
    if (!loading && !isAuthenticated) {
      router.push("/login");
    }

    // Проверка роли, если требуется определенная роль
    if (!loading && isAuthenticated && requiredRole && user?.role !== requiredRole) {
      if (requiredRole === "premium" && user?.role === "basic") {
        // Если нужен премиум, а у пользователя базовый аккаунт - отправляем на страницу тарифов
        router.push("/pricing");
      }
    }
  }, [isAuthenticated, loading, requiredRole, router, user]);

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <p>Загрузка...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle>Доступ запрещен</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Для доступа к этой странице необходимо войти в систему</p>
            <Button onClick={() => router.push("/login")}>Войти</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Проверка роли
  if (requiredRole && user?.role !== requiredRole) {
    if (requiredRole === "premium" && user?.role === "basic") {
      return (
        <div className="container mx-auto py-8">
          <Card>
            <CardHeader>
              <CardTitle>Требуется Премиум-аккаунт</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Эта функция доступна только пользователям с Премиум-аккаунтом.
              </p>
              <Button onClick={() => router.push("/pricing")}>
                Перейти на Премиум
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle>Доступ запрещен</CardTitle>
          </CardHeader>
          <CardContent>
            <p>У вас нет прав для просмотра этой страницы</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}
