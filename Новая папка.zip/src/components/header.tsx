"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu"

export function Header() {
  const pathname = usePathname()
  const { authState, logout } = useAuth()
  const { isAuthenticated, user } = authState

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  return (
    <header className="w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-blue-600 text-transparent bg-clip-text">DualAI Code</span>
          </Link>
        </div>
        <nav className="hidden gap-6 md:flex">
          <Link
            href="/"
            className={`text-sm font-medium transition-colors ${
              pathname === "/" ? "text-foreground" : "text-foreground/60 hover:text-foreground"
            }`}
          >
            Главная
          </Link>
          <Link
            href="/features"
            className={`text-sm font-medium transition-colors ${
              pathname === "/features" ? "text-foreground" : "text-foreground/60 hover:text-foreground"
            }`}
          >
            Возможности
          </Link>
          <Link
            href="/pricing"
            className={`text-sm font-medium transition-colors ${
              pathname === "/pricing" ? "text-foreground" : "text-foreground/60 hover:text-foreground"
            }`}
          >
            Тарифы
          </Link>
          {isAuthenticated && (
            <Link
              href="/dashboard"
              className={`text-sm font-medium transition-colors ${
                pathname.startsWith("/dashboard") && !pathname.includes("/chat") && !pathname.includes("/premium")
                  ? "text-foreground"
                  : "text-foreground/60 hover:text-foreground"
              }`}
            >
              Мои проекты
            </Link>
          )}
          {isAuthenticated && (
            <Link
              href="/dashboard/chat"
              className={`text-sm font-medium transition-colors ${
                pathname.startsWith("/dashboard/chat") ? "text-foreground" : "text-foreground/60 hover:text-foreground"
              }`}
            >
              AI-Чат
            </Link>
          )}
          {isAuthenticated && user?.role === "premium" && (
            <Link
              href="/dashboard/premium-features"
              className={`text-sm font-medium transition-colors ${
                pathname.startsWith("/dashboard/premium") ? "text-foreground" : "text-foreground/60 hover:text-foreground"
              }`}
            >
              <span className="flex items-center">
                <span>Премиум</span>
                <span className="ml-1.5 inline-flex items-center rounded-full bg-violet-100 px-1.5 py-0.5 text-xs font-medium text-violet-800">
                  PRO
                </span>
              </span>
            </Link>
          )}
        </nav>
        <div className="flex items-center gap-2">
          {!isAuthenticated ? (
            <>
              <Button variant="outline" asChild>
                <Link href="/login">Войти</Link>
              </Button>
              <Button asChild>
                <Link href="/register">Регистрация</Link>
              </Button>
            </>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar} alt={`${user?.firstName} ${user?.lastName}`} />
                    <AvatarFallback>
                      {user && getInitials(user.firstName, user.lastName)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                    <p className="text-xs leading-none text-muted-foreground mt-1">
                      {user?.role === 'premium' ? 'Премиум аккаунт' : 'Базовый аккаунт'}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">Мои проекты</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/chat">AI-Чат</Link>
                </DropdownMenuItem>
                {user?.role === "premium" && (
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/premium-features">Премиум-функции</Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/profile">Настройки профиля</Link>
                </DropdownMenuItem>
                {user?.role === 'basic' && (
                  <DropdownMenuItem asChild>
                    <Link href="/pricing" className="text-violet-600 hover:text-violet-700">Перейти на Премиум</Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                  Выйти
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  )
}
