"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import ProtectedRoute from "@/components/protected-route"
import { useAuth } from "@/lib/auth-context"

export default function PremiumFeaturesPage() {
  const { authState } = useAuth()
  const { user } = authState

  return (
    <ProtectedRoute requiredRole="premium">
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Премиум возможности</h1>
          <p className="text-muted-foreground">
            Эксклюзивные функции, доступные только для пользователей с премиум-аккаунтом
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-violet-100 to-violet-50 border-violet-200">
            <CardHeader>
              <CardTitle>Расширенный AI-чат</CardTitle>
              <CardDescription>
                Улучшенные возможности чата с ИИ
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Неограниченное количество сообщений</li>
                <li>Расширенный контекст для более умных ответов</li>
                <li>Приоритетная обработка запросов</li>
                <li>Экспорт истории чата</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="default" size="sm">
                Открыть расширенный чат
              </Button>
            </CardFooter>
          </Card>

          <Card className="bg-gradient-to-br from-blue-100 to-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle>AI Code Review</CardTitle>
              <CardDescription>
                Автоматический анализ и улучшение кода
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Детальный анализ кода на ошибки</li>
                <li>Рекомендации по улучшению производительности</li>
                <li>Автоматическое форматирование кода</li>
                <li>Поддержка более 20 языков программирования</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="default" size="sm">
                Запустить Code Review
              </Button>
            </CardFooter>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-100 to-emerald-50 border-emerald-200">
            <CardHeader>
              <CardTitle>Приоритетная поддержка</CardTitle>
              <CardDescription>
                Персональная поддержка от команды DualAI
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Ответ в течение 24 часов</li>
                <li>Персональный менеджер поддержки</li>
                <li>Видеоконсультации по запросу</li>
                <li>Помощь в настройке сложных проектов</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="default" size="sm">
                Обратиться в поддержку
              </Button>
            </CardFooter>
          </Card>
        </div>

        <Card className="border-violet-200">
          <CardHeader>
            <CardTitle>Расширенная аналитика проектов</CardTitle>
            <CardDescription>
              Детальный анализ и статистика по всем вашим проектам
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-violet-50 p-4 rounded-lg">
                <h3 className="font-medium text-lg">Активных проектов</h3>
                <p className="text-3xl font-bold text-violet-700">8</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-medium text-lg">AI-запросов</h3>
                <p className="text-3xl font-bold text-blue-700">354</p>
              </div>
              <div className="bg-emerald-50 p-4 rounded-lg">
                <h3 className="font-medium text-lg">Сэкономлено времени</h3>
                <p className="text-3xl font-bold text-emerald-700">48ч</p>
              </div>
              <div className="bg-amber-50 p-4 rounded-lg">
                <h3 className="font-medium text-lg">Эффективность</h3>
                <p className="text-3xl font-bold text-amber-700">92%</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Как премиум-пользователь, вы имеете доступ к детальной аналитике по всем вашим проектам.
              Используйте эти данные для оптимизации рабочего процесса и повышения эффективности.
            </p>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="mr-2">Скачать отчет</Button>
            <Button>Подробная аналитика</Button>
          </CardFooter>
        </Card>
      </div>
    </ProtectedRoute>
  )
}
