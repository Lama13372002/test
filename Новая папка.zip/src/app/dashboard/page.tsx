"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"
import ProtectedRoute from "@/components/protected-route"

// Фиктивные данные для проектов пользователя
const MOCK_PROJECTS = [
  {
    id: "p1",
    title: "E-commerce Platform",
    description: "Платформа электронной коммерции с функциями каталога, корзины и оформления заказа",
    status: "В разработке",
    lastUpdated: new Date("2023-03-15"),
  },
  {
    id: "p2",
    title: "Personal Blog",
    description: "Личный блог с поддержкой Markdown и системой комментариев",
    status: "Завершен",
    lastUpdated: new Date("2023-02-20"),
  },
  {
    id: "p3",
    title: "Weather App",
    description: "Приложение для отслеживания погоды с использованием API прогноза погоды",
    status: "Планирование",
    lastUpdated: new Date("2023-03-25"),
  },
]

export default function DashboardPage() {
  const { authState } = useAuth()
  const { user } = authState
  const [projects, setProjects] = useState(MOCK_PROJECTS)

  return (
    <ProtectedRoute>
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Личный кабинет</h1>
          <p className="text-muted-foreground">
            Добро пожаловать, {user?.firstName}! Здесь вы можете управлять своими проектами и настройками.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Проекты</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{projects.length}</p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" asChild>
                <Link href="#projects">Управление проектами</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">AI-Чат</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">∞</p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/chat">Открыть чат</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Тип аккаунта</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <p className="text-xl font-bold">
                  {user?.role === "premium" ? "Премиум" : "Базовый"}
                </p>
                {user?.role === "premium" && (
                  <span className="inline-flex items-center rounded-full bg-violet-100 px-2.5 py-0.5 text-xs font-medium text-violet-800">
                    PRO
                  </span>
                )}
              </div>
            </CardContent>
            <CardFooter>
              {user?.role === "basic" ? (
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/pricing">Перейти на Премиум</Link>
                </Button>
              ) : (
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/dashboard/premium-features">Премиум-функции</Link>
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>

        <section id="projects" className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Ваши проекты</h2>
            <Button>Создать новый проект</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card key={project.id}>
                <CardHeader>
                  <CardTitle>{project.title}</CardTitle>
                  <CardDescription>
                    Статус: {project.status}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{project.description}</p>
                  <p className="text-xs mt-4">
                    Последнее обновление: {project.lastUpdated.toLocaleDateString()}
                  </p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm">
                    Редактировать
                  </Button>
                  <Button size="sm">Открыть</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </section>

        {user?.role === "basic" && (
          <Card className="bg-violet-50 border-violet-200">
            <CardHeader>
              <CardTitle>Улучшите возможности с Премиум-аккаунтом</CardTitle>
              <CardDescription>
                Получите доступ к расширенным функциям и увеличьте лимиты использования.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li>Неограниченное количество проектов</li>
                <li>Приоритетная поддержка ИИ с улучшенным контекстным пониманием</li>
                <li>Доступ к эксклюзивным шаблонам и инструментам</li>
                <li>Расширенная история чатов и возможности экспорта</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild>
                <Link href="/pricing">Перейти на Премиум</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {user?.role === "premium" && (
          <Card className="bg-gradient-to-r from-violet-50 to-blue-50 border-violet-200">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CardTitle>Премиум возможности</CardTitle>
                <span className="inline-flex items-center rounded-full bg-violet-100 px-2.5 py-0.5 text-xs font-medium text-violet-800">
                  PRO
                </span>
              </div>
              <CardDescription>
                Эксклюзивные функции, доступные для вашего премиум-аккаунта
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-lg border p-4 flex flex-col">
                  <h3 className="font-medium mb-2">Расширенный AI-чат</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">
                    Улучшенные возможности чата с увеличенным контекстом и приоритетной обработкой
                  </p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/chat">Открыть</Link>
                  </Button>
                </div>
                <div className="rounded-lg border p-4 flex flex-col">
                  <h3 className="font-medium mb-2">AI Code Review</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">
                    Автоматический анализ кода для поиска ошибок и улучшения производительности
                  </p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/premium-features">Открыть</Link>
                  </Button>
                </div>
                <div className="rounded-lg border p-4 flex flex-col">
                  <h3 className="font-medium mb-2">Приоритетная поддержка</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">
                    Персональная поддержка от команды DualAI с ускоренным временем отклика
                  </p>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/premium-features">Открыть</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild>
                <Link href="/dashboard/premium-features">Все премиум функции</Link>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </ProtectedRoute>
  )
}
