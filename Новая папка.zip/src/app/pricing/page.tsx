import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Тарифы DualAI Code - Выберите подходящий план",
  description: "Ознакомьтесь с тарифными планами DualAI Code для коллаборативной разработки кода с использованием двух AI-моделей",
}

export default function PricingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-24 md:py-32 bg-gradient-to-br from-violet-900/10 via-background to-blue-900/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                Простые и понятные{" "}
                <span className="bg-gradient-to-r from-violet-600 to-blue-600 text-transparent bg-clip-text">
                  тарифы
                </span>
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Выберите план, который соответствует вашим потребностям, от индивидуальных разработчиков до крупных команд.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="w-full py-16 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 md:grid-cols-3">
            {/* Basic Plan */}
            <Card className="flex flex-col">
              <CardHeader className="flex-1">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">Базовый</CardTitle>
                  <div className="rounded-full bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                    Бесплатно
                  </div>
                </div>
                <CardDescription className="text-base pt-4">
                  Идеально для знакомства с возможностями сервиса и небольших проектов
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="mt-2 space-y-4">
                  <div className="text-4xl font-bold">₽0</div>
                  <p className="text-sm text-muted-foreground">Навсегда бесплатно</p>

                  <ul className="space-y-3 pt-4">
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>3 проекта</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>50 запросов к AI в месяц</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Базовые языки программирования</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Общественное сообщество поддержки</span>
                    </li>
                    <li className="flex items-start gap-2 text-muted-foreground">
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                      <span>Контроль версий (ограниченный)</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button size="lg" className="w-full" variant="outline" asChild>
                  <Link href="/register">Начать бесплатно</Link>
                </Button>
              </CardFooter>
            </Card>

            {/* Pro Plan */}
            <Card className="flex flex-col border-2 border-violet-600 dark:border-violet-400 shadow-lg relative overflow-hidden">
              <div className="absolute right-0 top-0 transform translate-x-1/2 -translate-y-1/2 bg-violet-600 text-white text-xs px-4 py-1 rotate-45">
                Популярный
              </div>
              <CardHeader className="flex-1">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">Продвинутый</CardTitle>
                  <div className="rounded-full bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                    Ежемесячно
                  </div>
                </div>
                <CardDescription className="text-base pt-4">
                  Для активных индивидуальных разработчиков и небольших команд
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="mt-2 space-y-4">
                  <div className="flex items-baseline">
                    <div className="text-4xl font-bold">₽1,499</div>
                    <div className="text-sm text-muted-foreground ml-2">/ месяц</div>
                  </div>
                  <p className="text-sm text-muted-foreground">Оплата ежемесячно, можно отменить в любое время</p>

                  <ul className="space-y-3 pt-4">
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>20 проектов</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>500 запросов к AI в месяц</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Все языки программирования</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Приоритетная техническая поддержка</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Полный контроль версий</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button size="lg" className="w-full" asChild>
                  <Link href="/register?plan=pro">Выбрать план</Link>
                </Button>
              </CardFooter>
            </Card>

            {/* Enterprise Plan */}
            <Card className="flex flex-col">
              <CardHeader className="flex-1">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">Профессиональный</CardTitle>
                  <div className="rounded-full bg-violet-100 px-3 py-1 text-sm text-violet-800 dark:bg-violet-800/20 dark:text-violet-500">
                    Ежемесячно
                  </div>
                </div>
                <CardDescription className="text-base pt-4">
                  Для команд разработчиков и профессиональных проектов
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="mt-2 space-y-4">
                  <div className="flex items-baseline">
                    <div className="text-4xl font-bold">₽3,999</div>
                    <div className="text-sm text-muted-foreground ml-2">/ месяц</div>
                  </div>
                  <p className="text-sm text-muted-foreground">Оплата ежемесячно, можно отменить в любое время</p>

                  <ul className="space-y-3 pt-4">
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Неограниченное количество проектов</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Безлимитные запросы к AI</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Все языки и фреймворки</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>Выделенный менеджер поддержки</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="h-5 w-5 text-green-600 dark:text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>API доступ и расширенные интеграции</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button size="lg" className="w-full" variant="outline" asChild>
                  <Link href="/register?plan=enterprise">Выбрать план</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section className="w-full py-16 md:py-24 bg-gradient-to-br from-background via-violet-900/10 to-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Часто задаваемые вопросы
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed dark:text-gray-400">
                Ответы на популярные вопросы о наших тарифных планах
              </p>
            </div>
          </div>

          <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Могу ли я сменить тарифный план?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Да, вы можете изменить свой тарифный план в любое время. При переходе на более дорогой план
                  изменения вступают в силу немедленно. При переходе на более дешевый план - с начала следующего
                  платежного периода.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Что происходит, если я исчерпаю лимит запросов?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Когда вы достигнете месячного лимита запросов, вы можете либо дождаться следующего платежного
                  периода, либо перейти на более высокий тарифный план для увеличения лимита, либо приобрести
                  дополнительные запросы.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Есть ли скидки для годовой оплаты?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Да, при оплате за год вы получаете скидку 20% от общей стоимости ежемесячных платежей. Эта опция
                  доступна для всех платных тарифных планов при переходе на годовой платеж в настройках аккаунта.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Как получить доступ к API?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  API доступен только на Профессиональном тарифном плане. После подписки вы получите API ключи
                  и документацию в разделе настроек вашего аккаунта, чтобы интегрировать возможности DualAI Code
                  в ваши собственные приложения.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col items-center justify-center mt-8 space-y-4 text-center">
            <p className="text-muted-foreground">Остались вопросы?</p>
            <Button variant="outline" asChild>
              <Link href="/contact">Свяжитесь с нами</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
