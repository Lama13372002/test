'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { format, parseISO } from 'date-fns';
import { ru } from 'date-fns/locale';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  CheckCircle,
  XCircle,
  Star,
  Search,
  UserCircle2,
  Calendar,
  MessageSquare,
  Loader2
} from 'lucide-react';

// Интерфейс для отзыва
interface Review {
  id: number;
  client_name: string;
  review_text: string;
  rating: number;
  avatar_url?: string;
  is_approved: boolean;
  created_at: string;
}

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filteredReviews, setFilteredReviews] = useState<Review[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<string>('all');
  const [selectedReview, setSelectedReview] = useState<Review | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  // Загрузка данных
  useEffect(() => {
    // Имитация загрузки данных с сервера
    const loadReviews = async () => {
      // В реальном приложении здесь будет API-запрос к /api/reviews
      setTimeout(() => {
        const mockReviews: Review[] = [
          {
            id: 1,
            client_name: 'Анна Иванова',
            review_text: 'Отличный мастер! Очень довольна результатом. Маникюр держится уже 3 недели без сколов. Обязательно приду снова.',
            rating: 5,
            avatar_url: 'https://i.pravatar.cc/150?img=1',
            is_approved: true,
            created_at: '2023-04-01'
          },
          {
            id: 2,
            client_name: 'Елена Петрова',
            review_text: 'Мне понравилось качество работы, но немного не понравилось время ожидания. В целом рекомендую этот салон.',
            rating: 4,
            avatar_url: 'https://i.pravatar.cc/150?img=2',
            is_approved: true,
            created_at: '2023-04-02'
          },
          {
            id: 3,
            client_name: 'Мария Сидорова',
            review_text: 'Супер! Всем рекомендую! Мастер настоящий профессионал своего дела!',
            rating: 5,
            avatar_url: 'https://i.pravatar.cc/150?img=3',
            is_approved: false,
            created_at: '2023-04-03'
          },
          {
            id: 4,
            client_name: 'Дарья Козлова',
            review_text: 'Хороший салон, но цены выше средних. Качество маникюра соответствует.',
            rating: 3,
            is_approved: false,
            created_at: '2023-04-04'
          },
          {
            id: 5,
            client_name: 'Ольга Николаева',
            review_text: 'Впечатления положительные. Цвет подобрали точно как я хотела. Единственное - было немного холодно в салоне.',
            rating: 4,
            avatar_url: 'https://i.pravatar.cc/150?img=5',
            is_approved: true,
            created_at: '2023-04-05'
          },
          {
            id: 6,
            client_name: 'Светлана Морозова',
            review_text: 'Не понравилось обслуживание. Мастер постоянно отвлекалась на телефон, но результат получился хороший.',
            rating: 3,
            is_approved: false,
            created_at: '2023-04-06'
          }
        ];
        setReviews(mockReviews);
        setFilteredReviews(mockReviews);
        setIsLoading(false);
      }, 1000);
    };

    loadReviews();
  }, []);

  // Фильтрация отзывов при изменении вкладки или поиска
  useEffect(() => {
    let result = [...reviews];

    // Фильтрация по вкладке
    if (activeTab === 'pending') {
      result = result.filter(review => !review.is_approved);
    } else if (activeTab === 'approved') {
      result = result.filter(review => review.is_approved);
    }

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(review =>
        review.client_name.toLowerCase().includes(query) ||
        review.review_text.toLowerCase().includes(query)
      );
    }

    setFilteredReviews(result);
  }, [reviews, activeTab, searchQuery]);

  // Функция для отображения звездного рейтинга
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          size={16}
          className={i < rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}
        />
      ));
  };

  // Функция для форматирования даты
  const formatDate = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, 'd MMMM yyyy', { locale: ru });
  };

  // Функция для открытия диалога с деталями отзыва
  const handleViewReview = (review: Review) => {
    setSelectedReview(review);
    setIsDialogOpen(true);
  };

  // Функция для обновления статуса отзыва (одобрение/отклонение)
  const handleUpdateApproval = async (id: number, approved: boolean) => {
    setIsUpdating(true);
    try {
      // Имитация запроса к API
      await new Promise(resolve => setTimeout(resolve, 800));

      // Обновляем статус в локальном состоянии
      const updatedReviews = reviews.map(review =>
        review.id === id ? { ...review, is_approved: approved } : review
      );

      setReviews(updatedReviews);

      if (selectedReview && selectedReview.id === id) {
        setSelectedReview({ ...selectedReview, is_approved: approved });
      }

      toast({
        title: approved ? 'Отзыв опубликован' : 'Отзыв скрыт',
        description: approved ? 'Отзыв будет отображаться на сайте' : 'Отзыв скрыт от посетителей сайта',
      });

      if (activeTab !== 'all') {
        // Если мы находимся на вкладке "На модерации" или "Опубликованные",
        // автоматически закрываем диалог, так как отзыв больше не соответствует фильтру
        setIsDialogOpen(false);
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось обновить статус отзыва',
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Функция для удаления отзыва
  const handleDeleteReview = async (id: number) => {
    if (!confirm('Вы уверены, что хотите удалить этот отзыв? Это действие нельзя отменить.')) {
      return;
    }

    setIsUpdating(true);
    try {
      // Имитация запроса к API
      await new Promise(resolve => setTimeout(resolve, 500));

      // Удаляем отзыв из локального состояния
      setReviews(reviews.filter(review => review.id !== id));

      toast({
        title: 'Отзыв удален',
        description: 'Отзыв был успешно удален',
      });

      // Закрываем диалог, если он открыт
      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось удалить отзыв',
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Анимация
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 24
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-rose-700">Отзывы клиентов</h1>
          <p className="text-gray-500 mt-1">Модерация и управление отзывами</p>
        </div>
      </div>

      {/* Поиск и фильтры */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Поиск по имени или тексту отзыва..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full sm:w-auto"
        >
          <TabsList className="grid grid-cols-3 w-full sm:w-[400px]">
            <TabsTrigger value="all">Все отзывы</TabsTrigger>
            <TabsTrigger value="pending">На модерации</TabsTrigger>
            <TabsTrigger value="approved">Опубликованные</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Список отзывов */}
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-rose-500" />
          <span className="ml-2 text-lg text-gray-600">Загрузка отзывов...</span>
        </div>
      ) : (
        <div>
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredReviews.length > 0 ? (
              filteredReviews.map(review => (
                <motion.div key={review.id} variants={item}>
                  <Card className={`h-full border ${review.is_approved ? 'border-green-200' : 'border-yellow-200'}`}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          {review.avatar_url ? (
                            <img
                              src={review.avatar_url}
                              alt={review.client_name}
                              className="w-10 h-10 rounded-full mr-3"
                            />
                          ) : (
                            <UserCircle2 className="w-10 h-10 text-gray-300 mr-3" />
                          )}
                          <div>
                            <CardTitle className="text-base font-medium">{review.client_name}</CardTitle>
                            <div className="flex items-center mt-1">
                              {renderStars(review.rating)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-1">
                          {review.is_approved ? (
                            <span className="flex items-center text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                              <CheckCircle className="w-3 h-3 mr-1" /> Опубликован
                            </span>
                          ) : (
                            <span className="flex items-center text-xs text-yellow-600 bg-yellow-50 px-2 py-1 rounded-full">
                              <Clock className="w-3 h-3 mr-1" /> На модерации
                            </span>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="py-2">
                      <p className="text-sm text-gray-600 line-clamp-3">{review.review_text}</p>
                    </CardContent>
                    <CardFooter className="flex justify-between items-center pt-2 text-xs text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {formatDate(review.created_at)}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewReview(review)}
                      >
                        Подробнее
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <MessageSquare className="mx-auto h-12 w-12 text-gray-300" />
                <h3 className="mt-4 text-lg font-medium">Отзывы не найдены</h3>
                <p className="mt-1 text-gray-500">
                  {searchQuery ? 'Попробуйте изменить параметры поиска' : 'В этой категории пока нет отзывов'}
                </p>
                {searchQuery && (
                  <Button
                    variant="outline"
                    className="mt-4"
                    onClick={() => setSearchQuery('')}
                  >
                    Сбросить поиск
                  </Button>
                )}
              </div>
            )}
          </motion.div>
        </div>
      )}

      {/* Диалог с деталями отзыва */}
      {selectedReview && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Отзыв клиента</DialogTitle>
              <DialogDescription>
                Подробная информация и управление отзывом
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="flex items-center">
                {selectedReview.avatar_url ? (
                  <img
                    src={selectedReview.avatar_url}
                    alt={selectedReview.client_name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                ) : (
                  <UserCircle2 className="w-12 h-12 text-gray-300 mr-4" />
                )}
                <div>
                  <h3 className="font-medium">{selectedReview.client_name}</h3>
                  <div className="flex items-center mt-1">
                    {renderStars(selectedReview.rating)}
                    <span className="ml-2 text-sm text-gray-500">{selectedReview.rating} из 5</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <Calendar className="w-3 h-3 mr-1" />
                    {formatDate(selectedReview.created_at)}
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-1">Текст отзыва:</p>
                <div className="bg-gray-50 p-3 rounded-md text-sm">
                  {selectedReview.review_text}
                </div>
              </div>

              <div className="border-t pt-4 flex justify-between">
                <div className="space-y-2">
                  <p className="text-sm font-medium">Статус отзыва:</p>
                  <div className="flex items-center">
                    {selectedReview.is_approved ? (
                      <span className="flex items-center text-sm text-green-600 bg-green-50 px-3 py-1 rounded-full">
                        <CheckCircle className="w-4 h-4 mr-1" /> Опубликован
                      </span>
                    ) : (
                      <span className="flex items-center text-sm text-yellow-600 bg-yellow-50 px-3 py-1 rounded-full">
                        <Clock className="w-4 h-4 mr-1" /> На модерации
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter className="flex flex-col-reverse sm:flex-row sm:justify-between sm:space-x-2">
              <Button
                variant="destructive"
                onClick={() => handleDeleteReview(selectedReview.id)}
                disabled={isUpdating}
              >
                {isUpdating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Удалить отзыв
              </Button>

              <div className="flex space-x-2 mb-3 sm:mb-0">
                {selectedReview.is_approved ? (
                  <Button
                    variant="outline"
                    onClick={() => handleUpdateApproval(selectedReview.id, false)}
                    disabled={isUpdating}
                    className="bg-yellow-50 hover:bg-yellow-100 text-yellow-800 border-yellow-200"
                  >
                    {isUpdating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <XCircle className="w-4 h-4 mr-2" />}
                    Скрыть отзыв
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => handleUpdateApproval(selectedReview.id, true)}
                    disabled={isUpdating}
                    className="bg-green-50 hover:bg-green-100 text-green-800 border-green-200"
                  >
                    {isUpdating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                    Опубликовать
                  </Button>
                )}

                <Button
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Закрыть
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
