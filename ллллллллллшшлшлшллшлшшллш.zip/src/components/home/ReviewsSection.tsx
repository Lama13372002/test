'use client';

import type React from 'react';
import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowRight, Star } from 'lucide-react';

// Временные данные для отзывов
const demoReviews = [
  {
    id: 1,
    name: 'Екатерина В.',
    rating: 5,
    text: 'Отличный сервис! Делала маникюр с дизайном, держится уже третью неделю. Мастер внимательный, учла все мои пожелания. Очень довольна результатом.',
    avatarUrl: '',
    date: '15.03.2025'
  },
  {
    id: 2,
    name: 'Анна К.',
    rating: 5,
    text: 'Регулярно хожу на маникюр и педикюр. Всегда все аккуратно и красиво. Хорошее обслуживание, приятная атмосфера. Рекомендую!',
    avatarUrl: '',
    date: '02.03.2025'
  },
  {
    id: 3,
    name: 'Мария Д.',
    rating: 4,
    text: 'Делала аппаратный маникюр с покрытием. Очень понравился подход мастера, все стерильно и профессионально. Единственное - немного задержались по времени.',
    avatarUrl: '',
    date: '24.02.2025'
  },
  {
    id: 4,
    name: 'Ольга Н.',
    rating: 5,
    text: 'Прекрасный салон! Делала сложный дизайн на ногтях, мастер воплотила все мои задумки. Буду обращаться еще!',
    avatarUrl: '',
    date: '15.02.2025'
  },
  {
    id: 5,
    name: 'Ирина П.',
    rating: 5,
    text: 'Постоянно хожу на маникюр к этому мастеру. Качество на высоте, приятное общение, индивидуальный подход. Очень рекомендую!',
    avatarUrl: '',
    date: '05.02.2025'
  }
];

// Функция для отображения звезд рейтинга
const RatingStars = ({ rating }: { rating: number }) => {
  return (
    <div className="flex">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
          }`}
        />
      ))}
    </div>
  );
};

export const ReviewsSection: React.FC = () => {
  const [visibleReviews, setVisibleReviews] = useState(demoReviews.slice(0, 3));
  const [currentIndex, setCurrentIndex] = useState(0);

  // Навигация по отзывам
  const handlePrev = () => {
    if (currentIndex > 0) {
      const newIndex = currentIndex - 1;
      setCurrentIndex(newIndex);
      setVisibleReviews(demoReviews.slice(newIndex, newIndex + 3));
    }
  };

  const handleNext = () => {
    if (currentIndex < demoReviews.length - 3) {
      const newIndex = currentIndex + 1;
      setCurrentIndex(newIndex);
      setVisibleReviews(demoReviews.slice(newIndex, newIndex + 3));
    }
  };

  // Варианты анимации
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const reviewVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-rose-900 mb-4">
            Отзывы клиентов
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Мнение наших клиентов - лучшее подтверждение качества работы
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {visibleReviews.map((review) => (
              <motion.div
                key={review.id}
                variants={reviewVariants}
                className="bg-rose-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center mb-4">
                  <Avatar className="h-10 w-10 mr-4">
                    <AvatarImage src={review.avatarUrl} alt={review.name} />
                    <AvatarFallback className="bg-rose-200 text-rose-600">
                      {review.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium text-rose-900">{review.name}</h4>
                    <div className="flex items-center">
                      <RatingStars rating={review.rating} />
                      <span className="text-gray-500 text-sm ml-2">{review.date}</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"{review.text}"</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Навигация по отзывам */}
        <div className="flex justify-center items-center space-x-4 mb-10">
          <button
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className={`p-2 rounded-full bg-rose-100 ${
              currentIndex === 0 ? 'text-gray-400 cursor-not-allowed' : 'text-rose-600 hover:bg-rose-200'
            }`}
            aria-label="Предыдущие отзывы"
          >
            <ArrowLeft size={20} />
          </button>

          <div className="text-sm text-gray-500">
            {currentIndex + 1}-{Math.min(currentIndex + 3, demoReviews.length)} из {demoReviews.length}
          </div>

          <button
            onClick={handleNext}
            disabled={currentIndex >= demoReviews.length - 3}
            className={`p-2 rounded-full bg-rose-100 ${
              currentIndex >= demoReviews.length - 3 ? 'text-gray-400 cursor-not-allowed' : 'text-rose-600 hover:bg-rose-200'
            }`}
            aria-label="Следующие отзывы"
          >
            <ArrowRight size={20} />
          </button>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center"
        >
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild className="bg-rose-500 hover:bg-rose-600">
              <Link href="/reviews">Все отзывы</Link>
            </Button>
            <Button asChild variant="outline" className="border-rose-300 text-rose-700 hover:bg-rose-100">
              <Link href="/reviews/new">Оставить отзыв</Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
