#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import time
import sys

def generate_totp_secret():
    """Generate a random secret for TOTP"""
    return base64.b32encode(secrets.token_bytes(20)).decode('utf-8')

def generate_current_totp(secret):
    """Generate the current TOTP code for a secret"""
    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    # Decode the base32 secret
    secret_bytes = base64.b32decode(secret.upper().encode('utf-8'))

    # Compute HMAC
    counter_bytes = intervals_no.to_bytes(8, byteorder='big')
    h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

    # Get offset
    offset = h[-1] & 0x0F

    # Get 4 bytes at the offset
    truncated_hash = h[offset:offset+4]

    # Convert to an integer and get only 6 digits
    code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
    code = code % 1000000

    # Zero pad to 6 digits
    code_str = str(code).zfill(6)

    return code_str

def verify_totp(secret, token):
    """Verify a TOTP token against a secret"""
    if not token:
        print("Token is empty")
        return False

    # Нормализуем токен: удаляем пробелы и убеждаемся, что это цифры
    token = token.strip()
    if not token.isdigit() or len(token) != 6:
        print(f"Token format invalid: '{token}'")
        return False

    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    print(f"Verifying token '{token}' against secret '{secret[:5]}...'")
    print(f"Current interval: {intervals_no}")

    # Увеличиваем диапазон проверки: проверяем текущий интервал и несколько в обе стороны
    # Это позволяет устройствам с сильной рассинхронизацией времени все еще проходить проверку
    for delta in range(-5, 6):  # -5 до +5 интервалов (±2.5 минуты)
        # Compute HMAC with the selected interval
        counter = intervals_no + delta
        print(f"Checking interval {counter} (delta {delta})")
        counter_bytes = counter.to_bytes(8, byteorder='big')

        try:
            # Decode the base32 secret
            try:
                # Убедимся, что секрет соответствует формату base32
                # Дополним секрет символами '=' для правильного размера, если необходимо
                secret_padded = secret.upper()
                padding = len(secret_padded) % 8
                if padding > 0:
                    secret_padded += '=' * (8 - padding)

                secret_bytes = base64.b32decode(secret_padded)
            except Exception as e:
                print(f"Error decoding secret: {e}")
                # Попробуем удалить все символы '=' из конца и декодировать снова
                secret_clean = secret.upper().rstrip('=')
                secret_padded = secret_clean + '=' * ((8 - len(secret_clean) % 8) % 8)
                secret_bytes = base64.b32decode(secret_padded)

            # Compute HMAC-SHA1
            h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

            # Get offset
            offset = h[-1] & 0x0F

            # Get 4 bytes at the offset
            truncated_hash = h[offset:offset+4]

            # Convert to an integer and get only 6 digits
            code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
            code = code % 1000000

            # Zero pad to 6 digits
            code_str = str(code).zfill(6)

            print(f"Generated code for interval {counter}: {code_str}")

            # Compare the generated code with the token
            if code_str == token:
                print(f"Token matched at interval {counter} (delta {delta})")
                return True
        except Exception as e:
            print(f"Error generating TOTP for interval {counter}: {e}")
            continue

    print(f"No matching code found for token '{token}'")
    return False

def test_totp_verification():
    # Тест 1: Проверить, что сгенерированный код проверяется успешно
    secret = generate_totp_secret()
    print(f"Тест 1: Сгенерированный секрет: {secret}")

    code = generate_current_totp(secret)
    print(f"Сгенерированный код: {code}")

    if verify_totp(secret, code):
        print("Тест 1 УСПЕШНО: Код верифицирован")
    else:
        print("Тест 1 ПРОВАЛ: Код не верифицирован")

    # Тест 2: Проверить, что неверный код отклоняется
    wrong_code = "000000"
    if not verify_totp(secret, wrong_code):
        print("Тест 2 УСПЕШНО: Неверный код отклонен")
    else:
        print("Тест 2 ПРОВАЛ: Неверный код принят")

    # Тест 3: Коды из соседних временных интервалов должны проходить верификацию
    future_timestamp = int(time.time()) + 60  # через 1 минуту
    time_step = 30
    future_interval = future_timestamp // time_step

    # Генерация кода для будущего интервала
    counter_bytes = future_interval.to_bytes(8, byteorder='big')
    secret_bytes = base64.b32decode(secret.upper().encode('utf-8'))
    h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    truncated_hash = h[offset:offset+4]
    future_code = str(int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF % 1000000).zfill(6)

    print(f"Код для будущего интервала {future_interval}: {future_code}")

    if verify_totp(secret, future_code):
        print("Тест 3 УСПЕШНО: Код из будущего интервала принят")
    else:
        print("Тест 3 ПРОВАЛ: Код из будущего интервала отклонен")

def validate_secret_from_app(secret, token):
    """Проверяет код из приложения-аутентификатора"""
    print(f"Проверка кода '{token}' для секрета '{secret}'")

    if verify_totp(secret, token):
        print("Код ВЕРНЫЙ!")
        return True
    else:
        print("Код НЕВЕРНЫЙ!")
        return False

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # Запуск тестов
        test_totp_verification()
    elif len(sys.argv) == 3:
        # Проверка конкретного кода для конкретного секрета
        secret = sys.argv[1]
        token = sys.argv[2]
        validate_secret_from_app(secret, token)
    else:
        print("Использование:")
        print("  python3 test_2fa.py                  # запуск тестов")
        print("  python3 test_2fa.py SECRET TOKEN    # проверка указанного кода для секрета")
