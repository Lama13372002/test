#!/usr/bin/env python3
import os
import re

# Обновленный импорт для новой реализации 2FA
updated_import_line = '''from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, send_from_directory
import re
import sqlite3
import os
import uuid
import time
import base64
import hashlib
import hmac
import secrets
from io import BytesIO
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import twofa  # Импортируем наш новый модуль для работы с 2FA'''

# Обновленная проверка TOTP с использованием модуля twofa
improved_verify_totp = '''# 2FA Functions
# These functions are now imported from twofa module
# Оставляем для совместимости, но используем функции из twofa.py
def generate_totp_secret():
    return twofa.generate_totp_secret()

def verify_totp(secret, token):
    return twofa.verify_totp(secret, token)'''

# Улучшенная обработка POST-запроса в setup_2fa
improved_setup_2fa_post = '''    elif request.method == 'POST':
        try:
            data = request.json
            if not data:
                return jsonify({'success': False, 'message': 'No data provided'}), 400

            token = data.get('token', '').strip()
            print(f"Received token: '{token}'")  # Логирование для отладки

            # Verify the token
            cursor.execute("SELECT twofa_secret, login FROM users WHERE id = ?", (user_id,))
            result = cursor.fetchone()

            if not result or not result[0]:
                conn.close()
                return jsonify({'success': False, 'message': 'No 2FA secret found'}), 400

            twofa_secret = result[0]
            username = result[1]

            print(f"User: {username}, Secret: {twofa_secret[:5]}...")  # Для отладки, показываем только начало секрета

            # Для отладки также сгенерируем ожидаемый код прямо здесь
            try:
                expected_code = twofa.generate_current_totp(twofa_secret)
                print(f"Expected code: {expected_code}")
            except Exception as e:
                print(f"Error generating expected code: {e}")

            # Проверяем TOTP
            if not twofa.verify_totp(twofa_secret, token):
                conn.close()
                return jsonify({'success': False, 'message': 'Invalid verification code'}), 400

            # Enable 2FA
            cursor.execute("UPDATE users SET twofa_enabled = 1 WHERE id = ?", (user_id,))
            conn.commit()
            conn.close()

            return jsonify({'success': True, 'message': '2FA setup complete'})

        except Exception as e:
            conn.close()
            error_msg = str(e)
            print(f"Error in setup_2fa POST: {error_msg}")
            return jsonify({'success': False, 'message': f'Server error: {error_msg}'}), 500'''

# Улучшенная обработка GET-запроса в setup_2fa
improved_setup_2fa_get = '''    if request.method == 'GET':
        # Check if 2FA is already enabled
        cursor.execute("SELECT twofa_enabled, twofa_secret FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()

        if not result:
            conn.close()
            return jsonify({'success': False, 'message': 'User not found'}), 404

        twofa_enabled, twofa_secret = result

        if twofa_enabled:
            conn.close()
            return jsonify({'success': True, 'twofa_enabled': True})

        # If no secret exists, generate one
        if not twofa_secret:
            twofa_secret = twofa.generate_totp_secret()

            cursor.execute("UPDATE users SET twofa_secret = ? WHERE id = ?", (twofa_secret, user_id))
            conn.commit()

        # Get username for URI
        cursor.execute("SELECT login FROM users WHERE id = ?", (user_id,))
        username = cursor.fetchone()[0]
        conn.close()

        # Create TOTP URI for apps
        totp_uri = twofa.generate_totp_uri(twofa_secret, username)

        # Try to generate QR code as base64
        try:
            qr_code_base64 = twofa.generate_qr_code_base64(twofa_secret, username)
        except:
            qr_code_base64 = None  # If we can't generate QR code, frontend will use an external service

        return jsonify({
            'success': True,
            'twofa_enabled': False,
            'twofa_secret': twofa_secret,
            'totp_uri': totp_uri,
            'qr_code_base64': qr_code_base64
        })'''

def update_main_py():
    # Чтение содержимого файла main.py
    with open('main.py', 'r') as f:
        content = f.read()

    # Заменяем импорты на обновленные
    old_import_line = re.search(r'from flask import.*?from datetime import datetime, timedelta', content, re.DOTALL).group(0)
    new_content = content.replace(old_import_line, updated_import_line)

    # Заменяем функцию verify_totp на улучшенную версию
    old_verify_totp = re.search(r'# 2FA Functions.*?def verify_totp.*?return False', new_content, re.DOTALL).group(0)
    new_content = new_content.replace(old_verify_totp, improved_verify_totp)

    # Заменяем обработку GET-запроса в setup_2fa
    old_setup_2fa_get = re.search(r'    if request\.method == \'GET\':(.*?)        return jsonify\(', new_content, re.DOTALL).group(0)
    new_setup_2fa_get = improved_setup_2fa_get + '\n        return jsonify('
    new_content = new_content.replace(old_setup_2fa_get, new_setup_2fa_get)

    # Заменяем обработку POST-запроса в setup_2fa
    old_setup_2fa_post = re.search(r'    elif request\.method == \'POST\':(.*?)            return jsonify\({\'success\': True, \'message\': \'2FA setup complete\'\}\)', new_content, re.DOTALL).group(0)
    new_content = new_content.replace(old_setup_2fa_post, improved_setup_2fa_post)

    # Записываем обновленное содержимое обратно в файл
    with open('main.py', 'w') as f:
        f.write(new_content)

    print("Файл main.py успешно обновлен для работы с новым модулем twofa.py.")

if __name__ == "__main__":
    # Проверяем, существует ли файл twofa.py, чтобы избежать ошибок
    if not os.path.exists('twofa.py'):
        print("Ошибка: Файл twofa.py не найден. Сначала создайте модуль twofa.py.")
        exit(1)

    update_main_py()
    print("Система 2FA успешно обновлена и теперь совместима с приложениями Google Authenticator и другими TOTP-аутентификаторами.")
