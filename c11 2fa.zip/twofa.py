#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import time
import qrcode
from io import BytesIO
import base64
import sqlite3

def generate_totp_secret():
    """Generate a random secret for TOTP"""
    return base64.b32encode(secrets.token_bytes(20)).decode('utf-8')

def generate_totp_uri(secret, username, issuer='FlaskApp'):
    """
    Generate a TOTP URI for authenticator apps
    Format: otpauth://totp/ISSUER:ACCOUNT?secret=SECRET&issuer=ISSUER
    """
    return f"otpauth://totp/{issuer}:{username}?secret={secret}&issuer={issuer}"

def generate_qr_code_base64(secret, username, issuer='FlaskApp'):
    """Generate a QR code for the TOTP URI and return it as a base64 string"""
    try:
        # Create TOTP URI
        totp_uri = generate_totp_uri(secret, username, issuer)

        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(totp_uri)
        qr.make(fit=True)

        # Create an image from the QR code
        img = qr.make_image(fill_color="black", back_color="white")

        # Save the image to a bytes buffer
        buffer = BytesIO()
        img.save(buffer, format='PNG')

        # Convert the bytes to a base64 string
        qr_code_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

        return qr_code_base64
    except ImportError:
        # Return a URL to a public QR code generation service if qrcode module is not available
        totp_uri = generate_totp_uri(secret, username, issuer)
        return f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={totp_uri}"

def generate_current_totp(secret):
    """Generate the current TOTP code for a secret"""
    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    # Decode the base32 secret
    secret_bytes = base64.b32decode(secret.upper().encode('utf-8'))

    # Compute HMAC
    counter_bytes = intervals_no.to_bytes(8, byteorder='big')
    h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

    # Get offset
    offset = h[-1] & 0x0F

    # Get 4 bytes at the offset
    truncated_hash = h[offset:offset+4]

    # Convert to an integer and get only 6 digits
    code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
    code = code % 1000000

    # Zero pad to 6 digits
    code_str = str(code).zfill(6)

    return code_str

def verify_totp(secret, token):
    """Verify a TOTP token against a secret"""
    if not token:
        print("Token is empty")
        return False

    # Нормализуем токен: удаляем пробелы и убеждаемся, что это цифры
    token = token.strip()
    if not token.isdigit() or len(token) != 6:
        print(f"Token format invalid: '{token}'")
        return False

    # Get current timestamp and convert to 30-second intervals
    now = int(time.time())
    time_step = 30
    intervals_no = now // time_step

    # Увеличиваем диапазон проверки: проверяем текущий интервал и несколько в обе стороны
    # Это позволяет устройствам с сильной рассинхронизацией времени все еще проходить проверку
    for delta in range(-1, 2):  # -1, 0, +1 интервалы (±30 секунд)
        # Compute HMAC with the selected interval
        counter = intervals_no + delta
        counter_bytes = counter.to_bytes(8, byteorder='big')

        try:
            # Decode the base32 secret
            try:
                # Убедимся, что секрет соответствует формату base32
                # Дополним секрет символами '=' для правильного размера, если необходимо
                secret_padded = secret.upper()
                padding = len(secret_padded) % 8
                if padding > 0:
                    secret_padded += '=' * (8 - padding)

                secret_bytes = base64.b32decode(secret_padded)
            except Exception as e:
                print(f"Error decoding secret: {e}")
                # Попробуем удалить все символы '=' из конца и декодировать снова
                secret_clean = secret.upper().rstrip('=')
                secret_padded = secret_clean + '=' * ((8 - len(secret_clean) % 8) % 8)
                secret_bytes = base64.b32decode(secret_padded)

            # Compute HMAC-SHA1
            h = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

            # Get offset
            offset = h[-1] & 0x0F

            # Get 4 bytes at the offset
            truncated_hash = h[offset:offset+4]

            # Convert to an integer and get only 6 digits
            code = int.from_bytes(truncated_hash, byteorder='big') & 0x7FFFFFFF
            code = code % 1000000

            # Zero pad to 6 digits
            code_str = str(code).zfill(6)

            # Compare the generated code with the token
            if code_str == token:
                return True
        except Exception as e:
            print(f"Error generating TOTP for interval {counter}: {e}")
            continue

    return False
