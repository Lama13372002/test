// Функция для отладки
function debugLog(message) {
    console.log("DEBUG: " + message);
}

// Функция для открытия модального окна с комментариями
function openCommentsModal(deviceId) {
    debugLog("openCommentsModal вызвана с deviceId: " + deviceId);

    // Создаем модальное окно
    const modal = document.createElement('div');
    modal.className = 'modal fade show';
    modal.style = 'background: rgb(0, 0, 0, 0.7); pointer-events: auto; display:block;';

    // Формируем HTML модального окна
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Комментарии к устройству</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="comments-container">
                        <p class="text-center">Загрузка комментариев...</p>
                    </div>
                    <form id="new-comment-form" class="mt-3">
                        <div class="form-group">
                            <label for="comment-text">Новый комментарий</label>
                            <textarea id="comment-text" class="form-control" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary mt-2">Добавить комментарий</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm text-capitalize-first">закрыть</button>
                </div>
            </div>
        </div>
    `;

    // Добавляем модальное окно в DOM
    document.body.appendChild(modal);

    // Обработчик закрытия модального окна
    const closeButtons = modal.querySelectorAll('.btn-close, .modal-footer .btn-outline-secondary');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });

    // Загружаем комментарии с сервера
    fetch(`/devices/${deviceId}/comments`)
        .then(response => response.json())
        .then(data => {
            const commentsContainer = modal.querySelector('#comments-container');
            const commentsHtml = data.success ? data.comments.map(comment => `
                <div class="comment mb-3 p-2 border-bottom">
                    <div class="d-flex justify-content-between">
                        <strong>${comment.username}</strong>
                        <small>${comment.created_at}</small>
                    </div>
                    <p class="mb-1">${comment.text}</p>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-comment" data-comment-id="${comment.id}">
                        <i class="fa fa-trash"></i> Удалить
                    </button>
                </div>
            `).join('') : '<p class="text-center text-danger">Ошибка загрузки комментариев</p>';

            commentsContainer.innerHTML = commentsHtml;

            // Обработчики удаления комментариев
            const deleteButtons = modal.querySelectorAll('.delete-comment');
            deleteButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const commentId = this.dataset.commentId;

                    if (confirm('Вы уверены, что хотите удалить этот комментарий?')) {
                        // Отправляем запрос на удаление
                        fetch(`/devices/${deviceId}/comments/${commentId}`, {
                            method: 'DELETE'
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Перезагружаем комментарии
                                this.closest('.comment').remove();
                            }
                        });
                    }
                });
            });
        })
        .catch(error => {
            console.error('Error loading comments:', error);
            const commentsContainer = modal.querySelector('#comments-container');
            commentsContainer.innerHTML = '<p class="text-center text-danger">Ошибка загрузки комментариев</p>';
        });

    // Обработчик отправки новых комментариев
    const form = modal.querySelector('#new-comment-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = form.querySelector('#comment-text').value;

        if (text.trim() === '') return;

        // Отправляем комментарий на сервер
        fetch(`/devices/${deviceId}/comments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Очищаем поле ввода и добавляем новый комментарий в список
                form.querySelector('#comment-text').value = '';

                const commentsContainer = modal.querySelector('#comments-container');
                const now = new Date().toLocaleString();

                // Если это первый комментарий, удаляем сообщение "Комментариев пока нет"
                if (commentsContainer.textContent.includes('Комментариев пока нет')) {
                    commentsContainer.innerHTML = '';
                }

                // Добавляем новый комментарий в начало списка
                const newComment = document.createElement('div');
                newComment.className = 'comment mb-3 p-2 border-bottom';
                newComment.innerHTML = `
                    <div class="d-flex justify-content-between">
                        <strong>Вы</strong>
                        <small>${now}</small>
                    </div>
                    <p class="mb-1">${text}</p>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-comment" data-comment-id="${data.comment_id}">
                        <i class="fa fa-trash"></i> Удалить
                    </button>
                `;

                commentsContainer.insertBefore(newComment, commentsContainer.firstChild);

                // Добавляем обработчик удаления для нового комментария
                const deleteButton = newComment.querySelector('.delete-comment');
                deleteButton.addEventListener('click', function() {
                    const commentId = this.dataset.commentId;

                    if (confirm('Вы уверены, что хотите удалить этот комментарий?')) {
                        // Отправляем запрос на удаление
                        fetch(`/devices/${deviceId}/comments/${commentId}`, {
                            method: 'DELETE'
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Удаляем комментарий из DOM
                                newComment.remove();
                            }
                        });
                    }
                });
            }
        });
    });
}

// Функция для отображения списка APK
function showDeviceApks(deviceId) {
    debugLog("showDeviceApks вызвана с deviceId: " + deviceId);

    // Создаем модальное окно
    const modal = document.createElement('div');
    modal.className = 'modal fade show';
    modal.style = 'background: rgb(0, 0, 0, 0.7); pointer-events: auto; display:block;';

    // Формируем HTML модального окна
    modal.innerHTML = `
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">APK файлы для устройства</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="apks-container">
                        <p class="text-center">Загрузка списка APK...</p>
                    </div>
                    <form id="upload-apk-form" class="mt-3" enctype="multipart/form-data" action="/upload_apk/${deviceId}" method="post">
                        <div class="form-group">
                            <label for="apk-file">Загрузить новый APK файл</label>
                            <input type="file" id="apk-file" name="file" class="form-control" accept=".apk" required>
                        </div>
                        <div class="form-group mt-2">
                            <label for="apk-version">Версия (опционально)</label>
                            <input type="text" id="apk-version" name="version" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary mt-2">Загрузить</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm text-capitalize-first">закрыть</button>
                </div>
            </div>
        </div>
    `;

    // Добавляем модальное окно в DOM
    document.body.appendChild(modal);

    // Обработчик закрытия модального окна
    const closeButtons = modal.querySelectorAll('.btn-close, .modal-footer .btn-outline-secondary');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });

    // Загружаем список APK с сервера
    fetch(`/devices/${deviceId}/apks`)
        .then(response => response.json())
        .then(data => {
            const apksContainer = modal.querySelector('#apks-container');

            if (data.success) {
                const apks = data.apks || [];

                // Формируем HTML списка APK
                let apksHtml = '';
                if (apks.length > 0) {
                    apksHtml = `
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Имя файла</th>
                                    <th>Версия</th>
                                    <th>Дата загрузки</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;

                    apks.forEach(apk => {
                        apksHtml += `
                            <tr>
                                <td>${apk.filename}</td>
                                <td>${apk.version || 'N/A'}</td>
                                <td>${apk.upload_date}</td>
                                <td>
                                    <a href="/download_apk/${apk.id}" class="btn btn-sm btn-outline-primary">
                                        <i class="fa fa-download"></i> Скачать
                                    </a>
                                </td>
                            </tr>
                        `;
                    });

                    apksHtml += `
                            </tbody>
                        </table>
                    `;
                } else {
                    apksHtml = '<p class="text-center">APK файлов не найдено</p>';
                }

                apksContainer.innerHTML = apksHtml;
            } else {
                apksContainer.innerHTML = '<p class="text-center text-danger">Ошибка загрузки списка APK</p>';
            }
        })
        .catch(error => {
            console.error('Error loading APKs:', error);
            const apksContainer = modal.querySelector('#apks-container');
            apksContainer.innerHTML = '<p class="text-center text-danger">Ошибка загрузки списка APK</p>';
        });

    // Обработчик загрузки APK
    const form = modal.querySelector('#upload-apk-form');
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        fetch(`/upload_apk/${deviceId}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Очищаем форму и обновляем список APK
                form.reset();

                // Получаем новый список APK
                fetch(`/devices/${deviceId}/apks`)
                    .then(response => response.json())
                    .then(data => {
                        const apksContainer = modal.querySelector('#apks-container');

                        if (data.success) {
                            const apks = data.apks || [];

                            // Формируем HTML списка APK
                            let apksHtml = '';
                            if (apks.length > 0) {
                                apksHtml = `
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Имя файла</th>
                                                <th>Версия</th>
                                                <th>Дата загрузки</th>
                                                <th>Действия</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                `;

                                apks.forEach(apk => {
                                    apksHtml += `
                                        <tr>
                                            <td>${apk.filename}</td>
                                            <td>${apk.version || 'N/A'}</td>
                                            <td>${apk.upload_date}</td>
                                            <td>
                                                <a href="/download_apk/${apk.id}" class="btn btn-sm btn-outline-primary">
                                                    <i class="fa fa-download"></i> Скачать
                                                </a>
                                            </td>
                                        </tr>
                                    `;
                                });

                                apksHtml += `
                                        </tbody>
                                    </table>
                                `;
                            } else {
                                apksHtml = '<p class="text-center">APK файлов не найдено</p>';
                            }

                            apksContainer.innerHTML = apksHtml;
                        }
                    });
            } else {
                alert(data.message || 'Ошибка при загрузке файла');
            }
        })
        .catch(error => {
            console.error('Error uploading APK:', error);
            alert('Ошибка при загрузке файла');
        });
    });
}

// Функция для редактирования устройства
function editDevice(deviceId) {
    debugLog("editDevice вызвана с deviceId: " + deviceId);

    // Поскольку GET-запрос к /devices/{id} может не работать,
    // создаем модальное окно с пустыми данными
    const modal = document.createElement('div');
    modal.className = 'modal fade show';
    modal.style = 'background: rgb(0, 0, 0, 0.7); pointer-events: auto; display:block;';

    // Формируем HTML модального окна
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Редактирование устройства</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="edit-device-form">
                        <div class="form-group">
                            <label for="device-name">Имя устройства</label>
                            <input type="text" id="device-name" class="form-control" value="" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm">Отмена</button>
                    <button type="button" class="btn btn-primary btn-sm save-device">Сохранить</button>
                </div>
            </div>
        </div>
    `;

    // Добавляем модальное окно в DOM
    document.body.appendChild(modal);

    // Получаем данные устройства после создания модального окна
    fetch(`/devices/${deviceId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.device) {
                const device = data.device;
                modal.querySelector('#device-name').value = device.name;
            }
        })
        .catch(error => {
            console.error('Error loading device:', error);
            // Не показываем alert, просто логируем ошибку
        });

    // Обработчик закрытия модального окна
    const closeButtons = modal.querySelectorAll('.btn-close, .btn-outline-secondary');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });

    // Обработчик сохранения устройства
    const saveButton = modal.querySelector('.save-device');
    saveButton.addEventListener('click', function() {
        const name = modal.querySelector('#device-name').value;

        if (!name.trim()) {
            alert('Имя устройства не может быть пустым');
            return;
        }

        // Отправляем данные на сервер
        fetch(`/devices/${deviceId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Закрываем модальное окно и обновляем список устройств
                modal.remove();
                // Перезагружаем страницу или обновляем список устройств
                window.location.reload();
            } else {
                alert(data.message || 'Ошибка при обновлении устройства');
            }
        })
        .catch(error => {
            console.error('Error updating device:', error);
            alert('Ошибка при обновлении устройства');
        });
    });
}

// Функция для удаления устройства
function deleteDevice(deviceId) {
    debugLog("deleteDevice вызвана с deviceId: " + deviceId);

    if (confirm(`Вы уверены, что хотите удалить устройство ${deviceId}?`)) {
        // Отправляем запрос на удаление
        fetch(`/devices/${deviceId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Обновляем список устройств
                window.location.reload();
            } else {
                alert(data.message || 'Ошибка при удалении устройства');
            }
        })
        .catch(error => {
            console.error('Error deleting device:', error);
            alert('Ошибка при удалении устройства');
        });
    }
}

// Функция для добавления нового устройства
function addDevice() {
    debugLog("addDevice вызвана");

    // Создаем модальное окно
    const modal = document.createElement('div');
    modal.className = 'modal fade show';
    modal.style = 'background: rgb(0, 0, 0, 0.7); pointer-events: auto; display:block;';

    // Формируем HTML модального окна
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Добавление нового устройства</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="add-device-form">
                        <div class="form-group">
                            <label for="new-device-name">Имя устройства</label>
                            <input type="text" id="new-device-name" class="form-control" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm">Отмена</button>
                    <button type="button" class="btn btn-primary btn-sm add-new-device">Добавить</button>
                </div>
            </div>
        </div>
    `;

    // Добавляем модальное окно в DOM
    document.body.appendChild(modal);

    // Обработчик закрытия модального окна
    const closeButtons = modal.querySelectorAll('.btn-close, .btn-outline-secondary');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });

    // Обработчик добавления устройства
    const addButton = modal.querySelector('.add-new-device');
    addButton.addEventListener('click', function() {
        const name = modal.querySelector('#new-device-name').value;

        if (!name.trim()) {
            alert('Имя устройства не может быть пустым');
            return;
        }

        debugLog("Отправка запроса на добавление устройства с именем: " + name);

        // Отправляем данные на сервер
        fetch('/devices', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        })
        .then(response => {
            debugLog("Получен ответ от сервера: " + response.status);
            return response.json();
        })
        .then(data => {
            debugLog("Данные ответа: " + JSON.stringify(data));
            if (data.success) {
                // Закрываем модальное окно и обновляем список устройств
                modal.remove();
                // Перезагружаем страницу или обновляем список устройств
                window.location.reload();
            } else {
                alert(data.message || 'Ошибка при добавлении устройства');
            }
        })
        .catch(error => {
            console.error('Error adding device:', error);
            alert('Ошибка при добавлении устройства');
        });
    });
}
