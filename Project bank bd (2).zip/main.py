from flask import Flask, render_template, request, jsonify
import re
import sqlite3

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/statistic.html')
def statistic():
    return render_template('statistic.html')


@app.route('/account-operations.html')
def account_operations():
    return render_template('account-operations.html')


@app.route('/deals.html')
def deals():
    return render_template('deals.html')


@app.route('/requisites.html')
def requisites():
    return render_template('requisites.html')


@app.route('/settings.html')
def settings():
    return render_template('settings.html')

@app.route('/admin')
def admin_panel():
    return render_template('adminPanel.html')

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404



# Функция для валидации данных и UUID
def validate_input(data, fields):
    """Проверяет, что в data есть все нужные поля."""
    if not all(field in data for field in fields):
        return False
    
    # Проверка, что user_id - это валидный UUID
    uuid_pattern = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$")
    if 'user_id' in data and not uuid_pattern.match(data['user_id']):
        return False

    return True


def fetch_data_from_table(table, user_id):
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Делаем запрос по user_id
        query = f"SELECT * FROM {table} WHERE user_id = ?"
        cursor.execute(query, (user_id,))
        row = cursor.fetchone()  # Мы получаем только одну строку

        if row:  # Если строка найдена
            # Получаем названия всех столбцов для удобства
            columns = [description[0] for description in cursor.description]
            # Преобразуем данные в удобный формат — словарь
            result = dict(zip(columns, row))
        else:
            result = None  # Если строка не найдена

    except sqlite3.Error as e:
        print(f"Ошибка: {e}")
        return None

    finally:
        conn.close()

    return result

@app.route(f"/view_data", methods=['POST'])
def view_data():
    data = request.json
    user_id = data.get('user_id')  # Получаем user_id из запроса
    table_name = data.get('table_name')  # Получаем название таблицы

    # Получаем данные из базы по user_id
    data_from_bd = fetch_data_from_table(table_name, user_id)

    if data_from_bd:
        print(data_from_bd)
    else:
        print("Данные не найдены или произошла ошибка.")
    
    return jsonify(data_from_bd), 200


# Шаблоны функций для работы с данными

def add_variable(variable_name, user_id, new_value):
    return jsonify({"message": f"Variable '{variable_name}' added for user {user_id}"}), 201


def edit_variable(variable_name, user_id, new_value):
    return jsonify({"message": f"Variable '{variable_name}' updated for user {user_id}"}), 200


def delete_variable(variable_name, user_id):
    return jsonify({"message": f"Variable '{variable_name}' deleted for user {user_id}"}), 200


# Генерация роутов для всех операций и таблиц
TABLES = ['statistics', 'operations', 'withdrawals', 'deals', 'requisites']

# Функция для создания маршрутов с сохранением таблицы

def create_add_route(table):
    @app.route(f"/add/{table}", methods=['POST'], endpoint=f"add_to_{table}")
    def add_to_table():
        data = request.json

        if not validate_input(data, ['variable_name', 'user_id', 'value']):
            return jsonify({"error": "Missing or invalid fields"}), 400

        variable_name = data['variable_name']
        user_id = data['user_id']
        value = data['value']

        try:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()

            # Проверяем, существует ли уже такая строка по user_id
            cursor.execute(f"SELECT 1 FROM {table} WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()

            if row:
                # Если строка есть — обновляем данные в указанном столбце
                query = f"UPDATE {table} SET {variable_name} = ? WHERE user_id = ?"
                cursor.execute(query, (value, user_id))
            else:
                # Если строки нет — создаём новую с user_id и нужным столбцом
                query = f"INSERT INTO {table} (user_id, {variable_name}) VALUES (?, ?)"
                cursor.execute(query, (user_id, value))

            conn.commit()

        except sqlite3.Error as e:
            return jsonify({"error": str(e)}), 500

        finally:
            conn.close()

        return jsonify({'status': f'Data added/updated in {table}', 'data': data}), 200


def create_delete_route(table):
    @app.route(f"/delete/{table}", methods=['POST'], endpoint=f"delete_to_{table}")
    def delete_from_table():
        data = request.json

        # Проверяем входные данные
        if not validate_input(data, ['variable_name', 'user_id']):
            return jsonify({"error": "Missing or invalid fields"}), 400

        variable_name = data['variable_name']
        user_id = data['user_id']

        try:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()

            # Проверяем, существует ли такая строка с user_id
            cursor.execute(f"SELECT {variable_name} FROM {table} WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()

            if row is None:
                return jsonify({"error": "User not found"}), 404

            # Если значение уже NULL — возвращаем сообщение
            if row[0] is None:
                return jsonify({"status": "Value is already NULL"}), 200

            # Обнуляем значение в указанном столбце
            query = f"UPDATE {table} SET {variable_name} = NULL WHERE user_id = ?"
            cursor.execute(query, (user_id,))
            conn.commit()

        except sqlite3.Error as e:
            return jsonify({"error": str(e)}), 500

        finally:
            conn.close()

        return jsonify({'status': f'Data deleted in {table}', 'data': data}), 200



# Генерируем маршруты для каждой таблицы
for table in TABLES:
    create_add_route(table)
    create_delete_route(table)


if __name__ == "__main__":
    app.run(debug=True)
