'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Car, Users, Briefcase, Wifi, Leaf, Coffee, Check } from 'lucide-react'
import BookingForm from '@/components/forms/BookingForm'

const vehicles = [
  {
    id: 'standard',
    name: 'Стандарт A класс',
    brand: 'Ford, Honda, Toyota',
    model: 'Focus, Civic, Corolla',
    year: 2022,
    seats: 4,
    description: 'Комфортабельные автомобили класса A. Идеальны для поездок небольших групп или пар.',
    price: 'от 250.00 EUR',
    image: '/images/vehicles/standard.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?q=80&w=1169&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    features: [
      'Кондиционер',
      'Комфортабельные сиденья',
      'Wi-Fi',
      'Зарядные устройства',
      'Бутилированная вода',
      'Удобный багажник'
    ]
  },
  {
    id: 'comfort',
    name: 'Комфорт C класс',
    brand: 'Toyota, Mercedes, BMW',
    model: 'Camry, C class, 2 Series',
    year: 2022,
    seats: 4,
    description: 'Комфортабельные автомобили C-класса для поездок по Европе. Просторный салон и большой багажник.',
    price: 'от 250.00 EUR',
    image: '/images/vehicles/comfort.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    features: [
      'Просторный салон',
      'Климат-контроль',
      'Wi-Fi',
      'Зарядные устройства',
      'Бутилированная вода',
      'Большой багажник'
    ]
  },
  {
    id: 'business',
    name: 'Бизнес E класс',
    brand: 'Mercedes, BMW, Audi, Lexus',
    model: 'E class, 5 Series, A6, ES',
    year: 2023,
    seats: 4,
    description: 'Представительский автомобиль бизнес-класса. Идеальный выбор для деловых поездок и VIP-трансферов.',
    price: 'от 350.00 EUR',
    image: '/images/vehicles/business.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1549399542-7e8f2e928464?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
    features: [
      'Кожаный салон',
      'Мультизонный климат-контроль',
      'Массаж сидений',
      'Wi-Fi',
      'Мини-бар',
      'Премиальная аудиосистема'
    ]
  },
  {
    id: 'premium',
    name: 'Премиум S класс',
    brand: 'Mercedes, BMW, Lexus',
    model: 'S class, 7 Series, LM 350h',
    year: 2023,
    seats: 4,
    description: 'Автомобили премиум класса для самых требовательных клиентов. Максимальный комфорт и роскошь.',
    price: 'от 500.00 EUR',
    image: '/images/vehicles/premium.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1553440569-bcc63803a83d?q=80&w=1025&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    features: [
      'Эксклюзивный кожаный салон',
      'Интеллектуальный климат-контроль',
      'Массаж и вентиляция сидений',
      'Wi-Fi высокоскоростной',
      'Персональный мини-бар',
      'Аудиосистема премиум-класса',
      'Шумоизоляция'
    ]
  },
  {
    id: 'minivan',
    name: 'Минивэн V class',
    brand: 'Mercedes-Benz',
    model: 'V class',
    year: 2022,
    seats: 7,
    description: 'Просторный минивэн для групповых поездок. Идеально подходит для семей или небольших групп.',
    price: 'от 500.00 EUR',
    image: '/images/vehicles/minivan.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1468818438311-4bab781ab9b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80',
    features: [
      'Просторный салон',
      'Комфортабельные сиденья',
      'Климат-контроль',
      'Wi-Fi',
      'Зарядные устройства',
      'Большое багажное отделение',
      'Складные столики'
    ]
  },
  {
    id: 'minivan_premium',
    name: 'Минивэн Premium',
    brand: 'Mercedes, Toyota',
    model: 'V class Premium, Alphard',
    year: 2023,
    seats: 7,
    description: 'Премиальный минивэн для комфортных групповых поездок. Высочайший уровень комфорта для всех пассажиров.',
    price: 'от 500.00 EUR',
    image: '/images/vehicles/minivan_premium.jpg',
    fallbackImage: 'https://images.unsplash.com/photo-1554222583-8b8cd4912161?q=80&w=1036&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    features: [
      'Роскошный салон с отделкой премиум-класса',
      'Индивидуальные капитанские кресла',
      'Автоматические сдвижные двери',
      'Мультимедийная система для пассажиров',
      'Wi-Fi высокой скорости',
      'Панорамная крыша',
      'Индивидуальный климат-контроль'
    ]
  }
]

// Иконки для особенностей автомобилей
const featureIcons: Record<string, React.ReactNode> = {
  'Wi-Fi': <Wifi className="w-4 h-4" />,
  'Просторный салон': <Users className="w-4 h-4" />,
  'Кожаный салон': <Briefcase className="w-4 h-4" />,
  'Климат-контроль': <Leaf className="w-4 h-4" />,
  'Мультизонный климат-контроль': <Leaf className="w-4 h-4" />,
  'Бутилированная вода': <Coffee className="w-4 h-4" />,
  'Мини-бар': <Coffee className="w-4 h-4" />,
}

export default function VehiclesSection() {
  const [activeVehicle, setActiveVehicle] = useState(vehicles[0].id)

  return (
    <section id="vehicles" className="py-20 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            className="text-3xl md:text-4xl font-bold mb-4 heading-underline inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Наш автопарк
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 dark:text-gray-300"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Мы предлагаем комфортабельные автомобили разных классов для ваших поездок.
            Выберите подходящий вариант и наслаждайтесь путешествием.
          </motion.p>
        </div>

        <div className="flex flex-col">
          {/* Отдельный блок для всего содержимого */}
          <div className="relative">
            <Tabs defaultValue={vehicles[0].id} onValueChange={setActiveVehicle} className="w-full">
              {/* Липкая навигация для мобильных устройств */}
              <div
                className="sticky top-0 z-30 bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm shadow-sm py-4 -mx-4 px-4 sm:mx-0 sm:px-0 sm:py-3"
              >
                <TabsList className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 w-full max-w-sm mx-auto lg:max-w-none lg:w-auto gap-2 p-2 lg:p-1">
                  {vehicles.map((vehicle) => (
                    <TabsTrigger
                      key={vehicle.id}
                      value={vehicle.id}
                      className="flex items-center justify-center gap-2 text-sm py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                    >
                      <Car className="w-4 h-4" />
                      <span className="whitespace-nowrap">{vehicle.name.split(' ')[0]}</span>
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              {/* Блок с содержимым с большим отступом от липкой навигации */}
              <div className="mt-32 sm:mt-12 md:mt-10">
                {vehicles.map((vehicle) => (
                  <TabsContent
                    key={vehicle.id}
                    value={vehicle.id}
                    className="focus-visible:outline-none focus-visible:ring-0 mt-0 pt-0"
                  >
                    <motion.div
                      className="grid md:grid-cols-2 gap-10 items-center"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5 }}
                    >
                      <div className="relative rounded-lg overflow-hidden shadow-xl">
                        <div
                          className="aspect-[16/9] bg-cover bg-center relative animate-pulse"
                          style={{
                            backgroundImage: `url(${vehicle.fallbackImage})`,
                            animationDuration: '3s'
                          }}
                        >
                        </div>
                        <div className="absolute top-4 right-4 bg-primary/90 text-white px-3 py-1 rounded-full text-sm font-medium">
                          {vehicle.price}
                        </div>
                      </div>

                      <div>
                        <div className="mb-6">
                          <h3 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white flex items-center">
                            <Car className="w-5 h-5 mr-2 text-primary" />
                            {vehicle.name} - {vehicle.brand} {vehicle.model}
                          </h3>
                          <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">
                            {vehicle.year} год · {vehicle.seats} места
                          </p>
                          <p className="text-gray-700 dark:text-gray-300 mb-6">
                            {vehicle.description}
                          </p>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                            {vehicle.features.map((feature, index) => (
                              <div
                                key={index}
                                className="flex items-center space-x-2 text-gray-700 dark:text-gray-300"
                              >
                                <div className="text-primary">
                                  {featureIcons[feature] ?? <Check className="w-4 h-4" />}
                                </div>
                                <span>{feature}</span>
                              </div>
                            ))}
                          </div>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button className="w-full sm:w-auto btn-gradient">
                                Заказать трансфер
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[625px] p-0 overflow-hidden">
                              <BookingForm />
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </motion.div>
                  </TabsContent>
                ))}
              </div>
            </Tabs>
          </div>
        </div>
      </div>
    </section>
  )
}
