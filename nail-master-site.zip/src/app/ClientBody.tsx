'use client';

import { Layout } from '@/components/layout/Layout';
import type { ReactNode } from 'react';

interface ClientBodyProps {
  children: ReactNode;
}

export const ClientBody = ({ children }: ClientBodyProps) => {
  return (
    <Layout>{children}</Layout>
  );
};
