'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

// Временные данные для галереи
const galleryItems = [
  {
    id: 1,
    title: 'Нежный градиент',
    imageUrl: '',
    category: 'gradient'
  },
  {
    id: 2,
    title: 'Геометрический дизайн',
    imageUrl: '',
    category: 'geometric'
  },
  {
    id: 3,
    title: 'Цветочный маникюр',
    imageUrl: '',
    category: 'flowers'
  },
  {
    id: 4,
    title: 'Матовые ногти',
    imageUrl: '',
    category: 'matte'
  },
  {
    id: 5,
    title: 'Свадебный маникюр',
    imageUrl: '',
    category: 'wedding'
  },
  {
    id: 6,
    title: 'Французский маникюр',
    imageUrl: '',
    category: 'french'
  },
  {
    id: 7,
    title: 'Абстрактный дизайн',
    imageUrl: '',
    category: 'abstract'
  },
  {
    id: 8,
    title: 'Сезонный дизайн',
    imageUrl: '',
    category: 'seasonal'
  }
];

const categories = [
  { id: 'all', name: 'Все работы' },
  { id: 'gradient', name: 'Градиент' },
  { id: 'geometric', name: 'Геометрия' },
  { id: 'flowers', name: 'Цветы' },
  { id: 'matte', name: 'Матовые' },
  { id: 'wedding', name: 'Свадебные' },
  { id: 'french', name: 'Френч' },
  { id: 'abstract', name: 'Абстракция' },
  { id: 'seasonal', name: 'Сезонные' }
];

export default function GalleryPage() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState<null | number>(null);

  // Фильтруем элементы по категории
  const filteredItems = activeCategory === 'all'
    ? galleryItems
    : galleryItems.filter(item => item.category === activeCategory);

  // Анимация для плитки
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <>
      <section className="py-20 bg-rose-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-rose-900 mb-4">
              Галерея работ
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Посмотрите коллекцию моих работ и выберите дизайн, который вам нравится.
              От классики до креативных решений - здесь вы найдете вдохновение для вашего маникюра.
            </p>
          </motion.div>

          <Tabs defaultValue={activeCategory} onValueChange={setActiveCategory} className="w-full">
            <TabsList className="flex flex-wrap justify-center mb-8 h-auto">
              {categories.map(category => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="m-1 data-[state=active]:bg-rose-500 data-[state=active]:text-white"
                >
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
            >
              {filteredItems.map((item) => (
                <motion.div
                  key={item.id}
                  variants={itemVariants}
                  whileHover={{ scale: 1.03 }}
                  className="cursor-pointer"
                  onClick={() => setSelectedImage(item.id)}
                >
                  <div className="bg-white rounded-lg overflow-hidden shadow-md">
                    <div className="relative aspect-square">
                      {item.imageUrl ? (
                        <Image
                          src={item.imageUrl}
                          alt={item.title}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-rose-100 flex items-center justify-center">
                          <span className="text-rose-500">Изображение маникюра</span>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="text-rose-900 font-medium">{item.title}</h3>
                      <p className="text-gray-500 text-sm mt-1 capitalize">{categories.find(c => c.id === item.category)?.name}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {filteredItems.length === 0 && (
              <div className="text-center py-10">
                <p className="text-gray-500">В этой категории пока нет работ</p>
              </div>
            )}
          </Tabs>
        </div>
      </section>

      {/* Модальное окно для просмотра увеличенного изображения */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg overflow-hidden max-w-4xl w-full max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative flex-grow">
                {galleryItems.find(item => item.id === selectedImage)?.imageUrl ? (
                  <div className="relative w-full h-full min-h-[300px]">
                    <Image
                      src={galleryItems.find(item => item.id === selectedImage)?.imageUrl || ''}
                      alt={galleryItems.find(item => item.id === selectedImage)?.title || ''}
                      fill
                      className="object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-full h-[50vh] bg-rose-100 flex items-center justify-center">
                    <span className="text-rose-500 text-lg">Увеличенное изображение маникюра</span>
                  </div>
                )}
              </div>

              <div className="p-4 bg-white">
                <h3 className="text-xl font-semibold text-rose-900 mb-2">
                  {galleryItems.find(item => item.id === selectedImage)?.title}
                </h3>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">
                    {categories.find(c =>
                      c.id === galleryItems.find(item => item.id === selectedImage)?.category
                    )?.name}
                  </span>
                  <Button
                    variant="outline"
                    className="border-rose-300 text-rose-600"
                    onClick={() => setSelectedImage(null)}
                  >
                    Закрыть
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
