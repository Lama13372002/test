import type React from 'react';
import { createContext, useContext, useState, useEffect } from 'react';
import { useCookies } from 'react-cookie';

interface User {
  id: number;
  username: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (token: string, userData: User) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cookies, setCookie, removeCookie] = useCookies(['auth-token']);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Проверяем авторизацию при загрузке страницы
  useEffect(() => {
    const verifyAuth = async () => {
      try {
        if (cookies['auth-token']) {
          // Проверка токена на сервере
          const response = await fetch('/api/auth/verify', {
            headers: {
              'Authorization': `Bearer ${cookies['auth-token']}`
            }
          });

          if (response.ok) {
            const userData = await response.json();
            setUser(userData.user);
          } else {
            removeCookie('auth-token');
            setUser(null);
          }
        }
      } catch (error) {
        console.error('Auth verification error:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    verifyAuth();
  }, [cookies, removeCookie]);

  // Функция входа
  const login = (token: string, userData: User) => {
    setCookie('auth-token', token, { path: '/', maxAge: 86400 }); // 24 часа
    setUser(userData);
  };

  // Функция выхода
  const logout = () => {
    removeCookie('auth-token', { path: '/' });
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      logout,
      isAuthenticated: !!user
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
